# Phimacs development

This is the private implementation candidate for the approved consolidation plan.
No source, branch or artifact is approved for public publication yet. The complete
symmetric runtime and acceptance matrix must pass before requesting publication.

## Rules

- Preserve source licenses, attribution and recorded import revisions.
- Keep credentials, sessions, profiles, personal paths, device policy and private
  Claude/native-token integrations out of source and artifacts, including history.
- Keep active source checkouts and user services untouched. Develop Pilish/Tau in
  the separate private candidate worktrees recorded in provenance.
- Read complete relevant documents/source before edits. Use strict TypeScript;
  use public package exports and exact dependencies. No compatibility shims.
- Pi host peers remain `*`; the release pins and validates the exact host.
- Install dependencies with scripts disabled. Do not run lifecycle scripts without
  review. Use focused tests, faux providers and isolated runtime namespaces; no
  paid calls or the user's running Emacs/Tau/browser/device services.
- Do not edit the read-only Pi reference checkout. The stronger universal Pi
  storage guarantee is blocked pending an owning upstream API; Phimacs protects
  managed launch paths and must describe its boundary honestly.
- Stage explicit owned paths only. No force push, broad reset/clean/stash, or
  publication. Do not commit another worker's changes.

## Target

One detached pimux per RPC agent, symmetric socket clients, explicit agent stop,
no automatic paid-work replay. Workers remain parent-task-owned; native panels
remain host-owned. Installation is a self-contained immutable release with its
own exact Pi, optional reference Emacs setup and an existing-Emacs package path.

Implementation gates and current evidence belong in `docs/execution.md`.
