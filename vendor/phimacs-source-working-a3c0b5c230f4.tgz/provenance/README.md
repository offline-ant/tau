# Source provenance

Imports are reviewed source snapshots, not merged histories. `generic-imports.json`
records exact source commits, per-file original hashes/modes, destinations and
exclusions for extensions/orchestration/pimux/deck. `ant-transformations.json`
records contract moves and compilation boundaries. `browser-imports.json` records
the browser snapshot and its excluded prototype packaging helper. Pagent is an
independent published throwaway prototype, excluded from the source, workspace,
release and acceptance graph; its independent repository/history remain intact.
Sound retains its own package-level provenance and Apache sound notices.

Original repositories/history remain available. Existing MIT grants are preserved
in every independently distributed extraction. The user confirmed ownership of
original reference-configuration code and selected MIT; third-party notices
are not replaced. Root MIT covers new original tooling only. External GPL sources
retain complete corresponding archives alongside their installed artifacts.
`forks.json` records the rebased candidate/source identities and final graph policy;
`emacs/inputs.json` owns the complete public Lisp/native/grammar acquisition lock.
Native prebuilt/source correspondence and Tau's missing upstream license grant
remain explicit release gates, not inferred from a declared SPDX string.

Do not place raw private audits, source-machine paths, credentials, device policy,
user settings or runtime state here. Private provider/native-token adapters and
personal configuration remain excluded. References/experiments/artworks/archives
are not imported. No private histories or cached generated assets are imported.

Phimacs is the development source of truth for selected imports, but installed
legacy paths remain active until approved cutover. Reconcile `port-queue.json` at
every phase gate: new old-tree fixes need a source revision, destination decision
and verification before inclusion. Preserve source revisions; never silently
substitute a dirty working tree or update a pin to a moving branch.
