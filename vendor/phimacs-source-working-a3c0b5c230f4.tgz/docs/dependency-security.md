# Pi host dependency security review

## Decision

**Candidate external-dependency overrides: `undici@8.12.2` and
`minimatch@11.0.3`, scoped to `@earendil-works/pi-coding-agent@1.4.0`.**
They are API-compatible with the inspected unbundled Pi consumers, subject to the
behavioral gates below. Do not apply a global minimatch major-version override to
uninspected consumers.

**These overrides do not remediate the official Pi 1.4.0 CLI/RPC bundle.** That
artifact embeds both libraries. A clean npm audit after overriding external
packages is insufficient release evidence. The complete shipped-host security
gate remains blocked until an owning Pi release/rebuilt artifact includes the
fixes, its acquisition is approved and its actual runtime bytes are tested. Do
not rewrite minified bundles or quietly substitute an unbundled entry point.
Private Phimacs implementation can proceed without asserting this gate passed.

This review changed only this document. It did not install dependencies, change a
lockfile, execute package lifecycle scripts, edit Pi source/reference files or
change the global/live CLI. Target-version runtime tests remain the parent's work.

## Inspected baseline and actual reachability

The inspected candidate tree contains:

| Component | Observed version | Proposed exact target |
|---|---|---|
| Pi coding-agent | 1.4.0 | Owning patched runtime artifact still required |
| undici external dependency | **8.10.2**, not 8.12.1 | 8.12.2 |
| minimatch external dependency | 10.2.6 | 11.0.3 |

The task's 8.12.1 shorthand is also vulnerable; the actual inspected package
manifest and root lock resolve 8.10.2. Consequently this review read all undici
release notes from 8.10.2 through 8.12.2, not only the final security patch.
Both targets support the selected Node 24 runtime: undici requires >=22.19.0;
minimatch supports Node 18, 20 and >=22.

### Unbundled HTTP consumer

`@earendil-works/pi-coding-agent/dist/core/http-dispatcher.js` imports `* as
undici`. Its complete implementation uses:

- `Client(origin, options)` and `Pool(origin, { ...options, factory })`;
- `EnvHttpProxyAgent`, with `allowH2:false`, `proxyTunnel:true`, configurable
  `bodyTimeout`/`headersTimeout`, custom client/origin factories and
  `connect.autoSelectFamilyAttemptTimeout:2000`;
- `setGlobalDispatcher` and optional `install()` to keep global fetch and its
  dispatcher on one implementation;
- EventEmitter `error` listeners, while preserving a deliberately replaced global
  fetch rather than overwriting it on repeated configuration.

CLI setup configures this dispatcher before provider requests. Management,
provider and extension requests using the installed global fetch therefore share
this transport boundary. Pi does not directly configure a shared-cache/redirect
interceptor, custom certificate callback, EventSource or undici WebSocket in this
module. That reduces direct reachability of some advisories; it does not justify
redistributing the affected library or asserting arbitrary extensions cannot use
those APIs. No Phimacs package directly imports undici/minimatch at this boundary.

### Unbundled glob consumers

Only named `minimatch(path, pattern, options?)` is imported by the inspected Pi
consumers. No use of removed regex/AST APIs was found there.

- `dist/core/model-resolver.js`: model scoping tests both `provider/id` and bare id
  with `{ nocase:true }`, after exact-id handling and thinking-suffix parsing.
- `dist/core/package-manager.js`: `matchesAnyPattern` tests normalized relative
  path, basename and absolute POSIX path; `SKILL.md` also matches its parent
  directory. Calls use default matcher options. Pi interprets include, `!`
  exclude, exact `+` include and exact `-` exclude itself; the force rules do not
  call minimatch. These functions drive manifest/user filters and autoload policy.
- Package glob expansion additionally uses Node's `fs.globSync`; overriding npm
  minimatch does **not** update or alter that distinct Node implementation.

The complete package-manager implementation was read, not merely its imports.
The consumers do not depend on minimatch's internal `set` representation,
`makeRe`, `AST`, `regexp`, `matchOne`, `slashSplit` or other removed APIs.

### Embedded runtime copies: release blocker

The package's `bin.pi` points to `dist/bundle/cli.js`; its exported `rpc-entry`
points to `dist/bundle/rpc-entry.js`. Their runtime graph includes
`dist/bundle/chunks/chunk-MM3LKT73.js`, which contains embedded
`node_modules/undici/...` implementations, `require_undici`, the dispatcher
configuration and the old minimatch regex/AST implementation plus Pi's calls.
These are not external package imports whose resolution npm overrides can change.

The owning `scripts/build-coding-agent-bundle.mjs` confirms the mechanism:
`bundle:true`, with an external allowlist that does not include either dependency.
Its builds consume the dependency graph present at build time. The bundled
minimatch still has `makeRe`/`AST`; this is not the v11 matcher. The inspected
embedded undici retains the affected Agent cloning/transport implementation.
Fixes must reach the owning build, not only the adjacent `node_modules` tree.

SDK/package consumers using `dist/index.js` and these external imports can benefit
from overrides immediately after testing. The bundled CLI and bundled RPC path
must be tested independently against a rebuilt, source-identified host. A version
string alone cannot demonstrate that its embedded dependencies changed.

## Release-note review and compatibility assessment

### undici 8.12.2

The [complete 8.12.2 release notes](https://github.com/nodejs/undici/releases/tag/v8.12.2)
and [security-patch comparison](https://github.com/nodejs/undici/compare/v8.12.1...v8.12.2)
were read. They address eight issues:

1. TLS 1.2 certificate-changing renegotiation process crash
   ([GHSA-qrxm-fqhp-jwvm](https://github.com/advisories/GHSA-qrxm-fqhp-jwvm)).
2. `Agent` dropping function-valued TLS options during JSON cloning
   ([GHSA-2m5v-pch6-74hx](https://github.com/advisories/GHSA-2m5v-pch6-74hx)).
3. Cross-origin redirect/shared-cache confusion
   ([GHSA-4w7w-5xrc-9h26](https://github.com/advisories/GHSA-4w7w-5xrc-9h26)).
4. Excessive content-encoding chains causing unhandled internal stream errors
   ([GHSA-xjj6-f33q-929c](https://github.com/advisories/GHSA-xjj6-f33q-929c)).
5. Decompression callback exceptions escaping per-request error handling
   ([GHSA-55wc-3pg8-jfw6](https://github.com/advisories/GHSA-55wc-3pg8-jfw6)).
6. Mixed-case SRI algorithm bypass
   ([GHSA-f72v-6w45-q472](https://github.com/advisories/GHSA-f72v-6w45-q472)).
7. Unbounded retained SSE parser state
   ([GHSA-4qv8-2p9j-2685](https://github.com/advisories/GHSA-4qv8-2p9j-2685)).
8. Unbounded WebSocket automatic PONG buffering
   ([GHSA-9fm3-97px-rjf6](https://github.com/advisories/GHSA-9fm3-97px-rjf6)).

Public dispatcher construction/methods used by Pi remain present. The patch
preserves top-level `tls` options separately from JSON-cloned options. Its public
type/documentation change clarifies that EventSource `maxEventSize` now limits
retained metadata, unfinished lines, data-field count and buffered chunk count;
`0` explicitly disables these limits. Workloads relying on previously unbounded
SSE events can now fail, intentionally. Do not disable the limits as a workaround.

The complete intervening release notes were also read:
[8.11.0](https://github.com/nodejs/undici/releases/tag/v8.11.0),
[8.11.1](https://github.com/nodejs/undici/releases/tag/v8.11.1),
[8.11.2](https://github.com/nodejs/undici/releases/tag/v8.11.2),
[8.12.0](https://github.com/nodejs/undici/releases/tag/v8.12.0) and
[8.12.1](https://github.com/nodejs/undici/releases/tag/v8.12.1).
Relevant behavioral changes include NO_PROXY wildcard matching, proxy Host-header
handling, repeated content-encoding/header handling, native-fetch compression
bridging, redirect large-body completion, retry/abort/connection-close settlement,
204/304 connection handling and stricter unsupported FormData body validation.
HTTP/2 fixes mostly lie outside Pi's explicit `allowH2:false` configuration, but
independent SDK/extension callers still require normal regression coverage.
The experimental HTTP parser is not a requested configuration change.

### minimatch 11.0.3

No GitHub release body is published for this tag. The authoritative
[complete v11.0.3 changelog](https://github.com/isaacs/minimatch/blob/v11.0.3/changelog.md)
and [v10.2.6-to-v11.0.3 comparison](https://github.com/isaacs/minimatch/compare/v10.2.6...v11.0.3)
were reviewed. Version 11 is a real major change, not a blind security patch:

- Path segments use `@isaacs/nonrecursive-glob-match` rather than RegExp.
- Regex/AST APIs and several previously exposed internal methods/options are
  removed; `Minimatch.set` contains matcher objects instead of regexes.
- Empty final path portions no longer match empty-producing extglobs; e.g.
  `a/b/` does not match `a/b/?(x)` or `a/b/*(x)`.
- Multiple-globstar and partial matching bugs are fixed; Windows root/UNC handling
  changes (outside initial Linux support) and Unicode normalization becomes an
  explicit option.
- v11.0.1 bounds globparts amplification and quadratic preprocessing
  ([GHSA-g3hv-75wg-m249](https://github.com/advisories/GHSA-g3hv-75wg-m249)).
  v11.0.2 updates the matcher to correct POSIX `[:print:]`
  ([upstream #309](https://github.com/isaacs/minimatch/pull/309)).
  v11.0.3 adds bounded matcher caching/performance corrections.

Choose **11.0.3**, rather than stopping at the first non-advised 11.0.1. Its named
boolean matcher and `nocase` option match Pi's inspected surface; changes to actual
pattern results still need the matrix below. Lock and retain notices for the new
`@isaacs/nonrecursive-glob-match` dependency (required range `^1.0.3`) and
`brace-expansion` (`^5.0.12`). Both minimatch and the new matcher use BlueOak-1.0.0;
preserve those grants rather than relabel them as Phimacs MIT code.

## Proposed root policy, not applied

Merge the following scoped object with existing host overrides, without dropping
other exact Pi host entries:

```json
{
  "overrides": {
    "@earendil-works/pi-coding-agent": {
      ".": "1.4.0",
      "undici": "8.12.2",
      "minimatch": "11.0.3"
    }
  }
}
```

Regenerate the root lock with scripts disabled. Confirm all actual consumers
resolve the intended targets and no nested affected external copy remains.
Preserve the exact resolved transitive versions/integrities in the lock and copy
this policy into isolated release hydration: workspace-only overrides do not
propagate automatically into a separately generated release prefix.

Registry integrity evidence for checking acquired bytes:

- undici 8.12.2:
  `sha512-XtuDWVdqTLr3NAxm2ly9/hU6kUsJOgGh1RASzMBbsw6aWCOaQzHdW+QQDfdERjfJ2V5vL5pRPa4RetO9UfivDg==`
- minimatch 11.0.3:
  `sha512-iny/40PEGkNJQ5/Pv6z3nm6FbRAby32GeZRjCUJk2WnNDbgPSTcdI+DDvLqsgBdD4cD5sMtMheqPPnehCCa8Nw==`

## Required acceptance tests

Run in disposable child processes with cleared proxy/auth variables, synthetic
HOME/agent directories and a private network namespace with loopback only. Use
local HTTP/TLS/CONNECT fixtures and faux models; no real provider/login requests.
Test the **unbundled SDK and actual shipped bundled CLI/RPC independently**.

1. **Resolution/artifact contract:** assert exact external versions from Pi's
   resolution context, no nested old copies, lock integrity and retained licenses.
   For bundled hosts, require rebuilt-source/bundle dependency evidence; a zero
   npm-audit result cannot stand in for this check.
2. **Pi dispatcher:** exercise Client and Pool factory paths, configure/reconfigure
   timeout settings (including disabled), retain a caller-replaced fetch, and prove
   normal installed global fetch decodes a local gzip JSON/chunked response.
   Cancel mid-stream and close a fixture connection abruptly: requests must settle
   without an uncaught dispatcher error or a process left running.
3. **Proxy policy:** local CONNECT proxy records that explicit HTTP_PROXY and
   HTTPS_PROXY routes still tunnel with Pi's `proxyTunnel:true`; test NO_PROXY exact
   host, suffix/wildcard and port matches/nonmatches, including `*`. Assert the
   intended target/Host header and no accidentally direct or external request.
   Changed wildcard results need explicit expected assertions, not snapshot waiver.
4. **Request lifecycle:** delayed headers and stalled body hit their configured
   idle timeouts; periodically arriving body chunks do not turn idle timeout into
   an absolute deadline. Abort and redirect-with-large-body requests settle exactly
   once. Verify local 204/304 responses do not poison the next pooled request.
5. **Security regressions:** use local fixtures for an excessive content-encoding
   chain, a custom TLS certificate-check callback that deliberately rejects, and
   wrong-host TLS certificate/renegotiation failures. Expected outcomes are bounded
   per-request errors, never process crashes or disabled certificate checks.
   Reuse upstream tests for SSE retained-state limits, PONG backpressure, mixed-case
   SRI, redirect-cache origin isolation and decompression callback throws if those
   APIs enter the selected artifact; adapting a test is not proof before execution.
6. **Model matching:** call `resolveModelScopeFromModels` with fake models only.
   Cover provider-qualified and bare patterns, nocase, `*`, `?`, character classes,
   braces, literal bracketed IDs, thinking suffixes, ambiguity and no-match warnings.
   Assert chosen IDs/order/diagnostics, not just that minimatch imports successfully.
7. **Package filters:** resolve a synthetic local package/manifest through
   `DefaultPackageManager` with only local resources and PI_OFFLINE. Cover nested
   extensions, basename/relative/absolute patterns, `SKILL.md` parent matches,
   include/exclude and exact `+`/`-` precedence, disabled autoload and dot paths.
   Assert which resources are enabled so a major matcher change cannot silently
   activate an excluded extension. Node `globSync` and npm minimatch are separate
   test cases.
8. **Matcher boundary:** assert intentional empty-segment extglob behavior and
   POSIX printable character classes. Run the upstream preprocessing-amplification
   reproducer in a memory/time-bounded child, not the main test runner; test the
   nonrecursive matcher on deep/repeated patterns without freezing the suite.
9. Run root typechecks, focused relevant existing tests and final dependency audit
   after the exact changes. An unrelated upstream/embedded limitation is an explicit
   blocked gate, not an excuse to suppress warnings or claim a fixed host.

None of these target-version runtime tests were executed in this review: the
candidate dependencies were deliberately not installed. The inspected APIs and
release notes support the proposed overrides for external consumers, **not** an
unqualified compatibility or vulnerability-clearance claim for Pi's embedded CLI.
