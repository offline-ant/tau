# Development

The root lock owns the complete npm workspace graph. Use `npm ci --ignore-scripts`,
`npm run compile` and `npm run check` from the root. Direct requirements are exact;
Pi host peers remain `*`. Root tooling resolves declared local SDK/compiler inputs,
never a sibling reference checkout or globally installed package.

Use focused tests with `node scripts/test.mjs <explicit .test.ts paths>`. Native
integration tests require explicit acquired candidate inputs and isolated homes,
agent directories, discovery/socket/claim registries and displays. Never use user
services, real profiles, authentication state or paid providers in normal tests.
No fixture may assume the old checkout layout or borrow personal grammar/module
caches. The root installed-release harness replaces personal-config smoke inputs;
legacy broad upstream harnesses remain separately classified, not clean-install proof.

Imported features are developed here. Do not merge private source history. Keep
old source repositories intact for attribution/rollback. Reconcile upstream source
revisions against `provenance/port-queue.json` at each phase gate; record urgent
old-tree fixes by full commit and either port or explicitly exclude them. Never
silently diverge or switch installed source paths during development.

Pilish/Tau changes belong in isolated private candidate worktrees. Public pushes,
registry publication, active cutover/restarts and old-repository retirement require
separate approval. The same applies to a Pi fork; none is approved.
