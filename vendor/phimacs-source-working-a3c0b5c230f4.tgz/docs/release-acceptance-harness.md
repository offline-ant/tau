# Installed-release symmetric acceptance

Run only against a complete privately staged protocol-2 release:

```sh
PHIMACS_RUNTIME_PREFIX=/absolute/installed/release \
  node --test --test-concurrency=1 test/integration/release-sharing.test.mjs
node --test test/integration/release-harness.test.mjs
```

`PHIMACS_RUNTIME_PREFIX` has no source-tree or old phase-B fallback. An omitted
prefix skips the native tests; **a skip is not acceptance**. An invalid/incomplete
prefix fails. Do not wrap this command in a short process-killing timeout: cleanup
must reconcile detached roots even when UI initialization fails.

## Inputs

The installed manifest must advertise `runtime.pimuxProtocol:2` and
`runtime.detachedTargetImplemented:true`, plus the exact host executable/hash.
Required installed assets are:

- The hydrated Node graph, including compiled `@phimacs/pimux`, generic
  `pi-browser`, `pi-sound`, `pi-orchestration`, its exact
  `node_modules/.bin/phimacs-task-status`, and selected `pi-tau-web-server`.
- Complete retained Pilish source at `forks/pilish`, including its storage helper.
  `externalForks.pilish.directory` can name another **internal relative** path.
- Unpacked `lisp/pi-deck` and fresh locked Lisp/native/essential grammar assets with
  `provision.json` at `assets/emacs`. `reference.assets` can name another internal
  relative path. No personal cache or generated workspace links qualify.
- Node 24, Linux, Emacs 31.1+, `emacsclient`, Chromium and Tau's TLS prerequisites.
  `PHIMACS_TEST_EMACS`, `PHIMACS_TEST_EMACSCLIENT` and `CHROMIUM_BINARY` explicitly
  select executables. `PHIMACS_TEST_XVFB=/absolute/Xvfb` gives the disposable
  daemon its own persistent graphical connection when required by PGTK snapshots;
  it never connects to the user's display. A sandbox-restricted container may explicitly opt into
  `PHIMACS_TEST_CHROMIUM_NO_SANDBOX=1`; this is never a product default.

The harness owns a dependency-free, faux-only fixture copied into its synthetic
root. Real inference is refused. It loads product modules only from the selected
installed prefix; test fixture source is not a product/sibling-source fallback.
The Emacs peer uses `-Q` and installed pinned load paths, not the user's init.
It exercises Pilish/deck's public APIs, not private `pilish--` state.

## Coverage and boundaries

The real phone-sized Chromium exercises Tau composer and dialog controls. The
first lane starts in real Pilish, attaches Tau, verifies same mux/Pi identity and
single prompt delivery, streaming/steering, first-answer dialog closure, model
changes, authoritative flat snapshot generations, global queue confirmation and
requester-only recovery, branch/file draft quarantine, zero-client active
completion, Emacs/Tau restart and frontend copy-prefix reconnect/rollback. Missing
and unsupported identities remain unavailable without new writers. Close requires
no confirmation and returns an identity-bound idempotent receipt. Authoritatively
closed identities are omitted from saved desktop restoration, not resurrected as
stopped placeholders.

The second lane starts in Tau and attaches real Pilish during a tool, disconnects
the creating Tau view, continues in Emacs, reattaches Tau and closes through deck.
A third lane closes idle, busy and dialog-blocked agents from each frontend,
asserting actual Pi exit, removal of chat/input/sidebar/Tau tabs everywhere,
offline saved-identity omission and zero browser/Emacs confirmation dialogs.
A copied frontend prefix is the **same tested release bytes**, not evidence that
an arbitrary future frontend is compatible or that runtime/schema downgrade is
safe. It proves reconnect/rollback does not replace the surviving runtime.

This lane supplements, rather than substitutes for, unit/native runtime stress
coverage of forced overflow/gaps/truncation, slow clients, provisional launcher
failure, ownership races, mux/Pi crash and worker cancellation. Reference GUI/TTY
style/mouse, fresh provisioning and package-only setup have separate tests. It
does not certify universal raw-Pi storage safety, ambiguous individual dialog
abandonment, Tau licensing, bundled-host security or publication approval.

## Explicit source-only Close regression

Source changes can exercise the same lanes without claiming installed acceptance.
Compile all three candidate trees first, then stage a **new mutable test prefix**:

```sh
node test/support/close-source-prefix.mjs --destination /new/source-test-prefix \
  --pilish /absolute/pilish-candidate --tau /absolute/tau-candidate \
  --assets /retained/release/assets/emacs
PHIMACS_CLOSE_SOURCE_PREFIX=/new/source-test-prefix \
  node --test --test-concurrency=1 test/integration/release-sharing.test.mjs
```

The builder copies the root dependency graph, candidate compiled packages,
Pilish/deck sources and explicitly retained Emacs assets. It runs no installer,
changes no installed bytes and invents no fork archive/revision pins. Its manifest
and diagnostics say `source-only-close-regression`. This input is refused by the
installed mode; source mode likewise refuses an installed manifest. The two prefix
variables cannot be combined. Neither a source-only pass nor a run on a newer
Emacs snapshot establishes final archived-release or Emacs 31.1 acceptance.

## Isolation and cleanup

Each lane obtains the owning marked `PHIMACS_TEST_ROOT` and constrained synthetic
session tree, and sets private discovery, HOME, TMPDIR, XDG, Emacs sockets, Tau
state and Chromium profile. Provider tokens, inherited orchestration identity,
production endpoints and desktop environment are not propagated. No fixed
production take namespace is used or enumerated.

Cleanup closes the owned frontends, lists **only its synthetic mux directory**,
and identity-stops every owned runtime, including one committed before a view
reported readiness. It verifies recorded Pi/mux identities are dead before
removing evidence. Uncertain cleanup fails and retains the namespace, rather than
deleting its claims or signaling an unowned PID. Test output names that namespace.
