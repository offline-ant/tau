# Runtime lifecycle

Protocol-2 pimux owns each detached RPC Pi independently of its frontends. Pilish
and Tau are equal socket clients. Agent Close, including sidebar/header/tab ×,
is one identity-bound operation without confirmation, even while busy. It stops
the agent and removes active views across frontends after authoritative exit.
Close space closes its agents and owned descendants before forgetting its layout.
Failed or uncertain Close retains a recoverable view and reports the error.

Frontend shutdown, restart, browser/window loss and generic transport disposal
only disconnect; accepted work can continue and incur provider usage. No local
Disconnect versus Stop-everywhere choice is exposed in the ordinary Close UI.
Hide is an explicitly named layout action. Stop turn remains Pi's abort, not agent
Close. Neither Close nor frontend loss deletes the persisted conversation.

Reconnect uses an existing runtime identity and authoritative snapshot/live boundary.
It never reopens a stale session path, relaunches a missing agent or resends input.
Known terminal identities are omitted from active desktops. Reconnect/restore can
read an existing retained stop receipt without performing a stop. Missing or
unsupported identities without terminal evidence remain unavailable; absence or
a refused socket is not closure. Explicit Resume starts a new owned runtime only
after exclusion checks. Desktop state stores views, layout and quarantined local
input separately from runtime ownership. Closed-view input and crash diagnostics
remain recoverable outside the active-agent list.

Session/file/branch adoption quarantines old local drafts and automatic follow-ups.
Clearing Pi's queue is global/destructive; only its requester receives acknowledged
recovery of all cleared text. There is no per-client removal/provenance guarantee or
automatic resend after uncertain delivery. Dialogs use first-answer-wins; aggregate
Pi dialog abandonment remains an upstream limitation.

Workers belong to a parent's actual process identity and task lease, not an Emacs
buffer or network PID. Frontend loss does not end a request; task cancellation or
verified parent death performs owned cleanup. Worker Close requires the advertised
extension cancellation command and an exact mux/task binding. Runtime exit alone
is not final task completion: orchestration publishes terminal task evidence only
after exit, host cleanup, registry removal and name release. Failed or missing
evidence is not successful Close; no ambiguous cancellation input is replayed.

Native panels retain their host lifetimes. Creator death triggers native cleanup
through the original host only when the exact target can still be established;
uncertainty retains the target and diagnostics. A root's stop receipt does not
acknowledge asynchronous native-panel cleanup. Deck can await explicitly listed
native descendants. Native-host limitations belong in the orchestration README.
Independent forks are not subordinate tasks. Emacs restart can lose native
shells/panels; desktop restore never reruns their saved shell commands.

Canonical-path/inode claims precede managed opens and survive uncertain teardown
while either wrapper or Pi may write. Production claims are release/TMPDIR-independent;
test namespaces cannot access production sessions. Old/provisional claims remain
conservatively retained during uncertain transitions. Refused sockets are not death.

The guarantee is cooperative, not universal raw-Pi safety. Pi 1.4 has unguarded
storage paths and no safe general writer-freeze/handoff API. Shared `/switch`
attaches compatible RPC views; unsafe native `/switch`, RPC-to-Herdr and `/take`
refuse without touching another writer. Live Pilish tree-label/navigation storage
mutations likewise refuse when no owning RPC exists. No Pi fork is authorized.

Frontend release selection/rollback does not replace running runtime code or stop
agents. Old release bytes must remain until their runtimes and saved worker paths
are retired. Agent-runtime/schema migration and live cutover need separate approval.
