# Execution gates

This is private implementation and acceptance work. Public release, live cutover,
service changes, remote deployment and old-repository retirement remain unapproved.
The active installation is unchanged; candidate success never authorizes cutover.
The user explicitly excludes Pagent: its independent prototype and history remain
outside Phimacs source, dependencies, releases, launchers and acceptance.

Acceptance is bound to the complete archived/offline-installed artifact and its
SHA-256, not an earlier candidate or development checkout. The owning startup,
worker-claim, contextual-input, saved-view, snapshot-readiness and host-identity
fixes require the practical installed matrix below on each changed release.
Private acceptance does not clear the external public-release gates.

Unified Close and final worker-task acknowledgement are worktree-source changes.
The recorded fork revision/archive hashes still select the preceding candidate;
they are not evidence for these uncommitted sources. New retained fork archives,
matching pins and final installed acceptance are required before distributing this
behavior. No existing immutable release or live installation is modified.

| Gate | Current evidence | Status |
|---|---|---|
| A inventory | Immutable import selections/hashes/exclusions, source-port queue; original config MIT ownership confirmed | Complete for selected private imports |
| B package graph | Five root workspaces plus exact external Tau, one canonical host tree, complete hydrated local-tarball graph; no symlinks | Implemented and installed-pack verified |
| B assets | Complete licenses/templates/helpers/shell assets, independent Lisp archives and unpacked sources | Implemented and archive/installed verified |
| C deck lifecycle | Empty owner save, idempotent enable/disable, real callback restoration, verified restart handoff | Regression/native tests pass |
| C managed ownership | Path/inode claims, process-start identities, durable pre-execution ownership gate, serialized worker-name claims and task leases | Implemented; source stress/native and installed worker evidence are separate requirements |
| C universal Pi storage | Pi 1.4 has unguarded storage and no general writer-freeze/transfer API; no Pi fork authorized | Upstream API blocker; unsafe paths refuse |
| C shared input/control | Captured file/branch input anchors, atomic mutation admission, authoritative snapshot/live readiness, quarantine and confirmed shared queue controls | Implemented; each frontend and packed caller must exercise the same required context contract |
| D detached symmetry | Equal sockets, both creator directions, zero-client life, stop and frontend restore; saved-view and host-attachment fixes included in pinned forks | Two real cross-frontend lanes required against every final archive |
| E reference/package-only setup | Fresh verified Lisp/native/source closure and pinned public essential grammar build; no startup downloads | Eight actual batch/TTY/GUI startup lanes required against final installed bytes |
| F forks | Rebased full Pilish/Tau candidate revisions, retained complete hashed source, versioned owning API | Candidate pins/archives integrated; no public push |
| G local edges | Tau stale-response/project refresh races, Ghostel pinned private boundary, disposable displays | Focused regressions pass; upstream limitations retained |
| Host security | Official Pi 1.4 bundles vulnerable undici/minimatch; overrides cannot repair embedded bytes | Fixed owning host artifact required before release |
| Native correspondence | Eleven native source archives/notices retained; upstream release digest verified | Independent prebuilt/source correspondence not established |
| Tau licensing | Upstream declares MIT without a supplied license grant/file | Upstream clarification required before redistribution |
| P publication | Complete anonymous acquisition can run only after approval and cleared blockers | Not approved or performed |
| H active cutover | Original setup/checkouts remain active and first rollback target | Not approved or performed |

## Repeatable private acceptance

From the repository root, use explicit fresh destinations and acquired hashed
sources. Full packaging/install commands are in [installation](install.md).

```sh
npm ci --ignore-scripts
npm run compile
npm run check
node --test test/install/release-tools.test.mjs
PHIMACS_RUNTIME_PREFIX=/installed/release \
  node --test test/install/installed-packs.test.ts test/install/lisp-archives.test.ts
PHIMACS_INSTALLED_RELEASE=1 PHIMACS_RUNTIME_PREFIX=/installed/release \
  node --test test/install/immutable-release.test.mjs
PHIMACS_REFERENCE_STARTUP=1 PHIMACS_RELEASE_DIR=/installed/release \
  PHIMACS_EMACS_ASSETS=/installed/release/assets/emacs \
  PHIMACS_PILISH_DIR=/installed/release/lisp/pilish \
  node --test --test-concurrency=1 test/reference-startup.test.mjs
PHIMACS_RUNTIME_PREFIX=/installed/release \
  node --test --test-concurrency=1 test/integration/release-sharing.test.mjs
```

The complete artifact carries per-file integrity, source/archive digests and its
actual host identity. Offline installation verifies bytes before reserving a new
version, seals them read-only and changes only an explicitly requested selector.
Tests against development copies are classified separately from the same lanes
against final archived/offline-installed bytes. Missing-prefix skips are not passes.

Native startup covers package-only and reference configuration in batch, 256-colour
TTY, truecolour TTY and isolated GUI, with actual module/grammar/API checks. The
symmetric lane exercises installed Emacs-first and Tau-first roots, phone Chromium,
streaming/steering/dialog/model/file/branch/queue/draft controls, zero-client active
completion, both frontend restarts, identical-byte frontend relocation/rollback,
missing/protocol-refused views and explicit idempotent stop. See its coverage
boundaries; these are not a substitute for runtime fault-injection/ownership tests.

## Remaining boundaries and classified failures

- Universal raw Pi storage, safe native transfers and live tree mutation need owning
  Pi APIs; native `/switch`, RPC-to-Herdr and `/take` refuse rather than bypass claims.
- Exact individual dialog abandonment is not reported by Pi; aggregate closure has
  a documented ambiguity, not a fabricated lifecycle guarantee.
- The shipped Pi host remains dependency-security blocked. Actual npm audit reports
  one high and eight moderate dependency paths; no advisory is suppressed. The
  underlying affected libraries are undici and minimatch, including embedded copies.
- Ghostel prebuilt/source correspondence and Tau's upstream license need resolution.
  Retaining source/notices is not a blanket legal or reproducibility clearance.
- Pagent is an excluded independent prototype: no release package, launcher,
  portable artifact or acceptance work belongs to Phimacs.
- Upstream Pilish GUI/fontification/scroll/terminal-image limitations remain
  known-fail/environmental; Chromium acceptance does not silently certify Firefox. Broad mutable-cache upstream harnesses are not
  accepted as clean-install evidence.
- Runtime-version/schema downgrade is not proven by frontend reconnect to identical
  release bytes. The original setup is still the first rollback target; migration
  must stop candidate writers before handback and must not overwrite newer sessions.

No paid inference, private adapter/token/device discovery, production runtime
namespace enumeration, public publication or live service operation is part of
these acceptance lanes. Every synthetic runtime is identity-stopped in cleanup;
uncertain cleanup retains its namespace instead of deleting claims.

## Source ownership

Selected imported features develop in Phimacs. Old installed checkouts remain
intact for attribution/rollback; their recorded source revisions remain unchanged.
Reconcile `provenance/port-queue.json` at each gate. Forks retain separate upstream
workflows and complete source archives, not divergent vendored implementations.
Private provider/device adapters and histories remain outside the public graph.
