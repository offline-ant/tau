# Migration boundary

No active settings, source paths, services or conversations are switched by the
candidate build. The original installation remains the first rollback target.

Before a separately approved cutover: finish isolated runtime/Emacs/Tau acceptance,
produce an exact path/settings/process preview, rehearse on synthetic copied
sessions, back up private state with private permissions and verify writer exit
before handing files to a different runtime. Preserve original release/source
paths referenced by saved worker-resume arguments until they are safely migrated.

## Required read-only preview

Before requesting approval, record the exact candidate archive digest, new immutable
prefix and optional selector; the original executable/config/state paths to retain;
the selected frontend-only environment/load forms; and every proposed settings or
service change (an empty list for private acceptance). List conversation copies and
their exclusive writer/stop receipts without opening production files through Pi.
Keep credentials out of this preview. A preview is not a migration command.

The isolated rehearsal installs into a new prefix, selects it explicitly, rolls the
owned selector back without overwriting either version, and reconnects copied
frontends to the same surviving runtime. It never changes user settings/services or
hands a live conversation to a second writer. Actual cutover still requires separate
approval, private backups and an exact writer-exit/compatibility check.

Desktop reconnect and runtime upgrade are separate actions. Never reopen a stale
session path while its runtime survives under a new identity, replay paid work,
overwrite newer conversation files or assume session-schema downgrade safety.
No remote deployments, credential sync or old-repository archival is implicit.
