# pi-deck — development guide

Emacs package: project spaces (one window layout each) and an agent sidebar
for Pi sessions via Pilish. User documentation: `README.md`.

## Files

| File | Purpose |
|---|---|
| `pi-deck.el` | `pi-deck-mode` (hides the tab bar), `pi-deck-command-map`, hooks and timers |
| `pi-deck-core.el` | agent registry, state derivation (including workers waiting for the user), seen/done, priority, terminal prompt marks |
| `pi-deck-spaces.el` | space registry, hidden per-space layout tabs and remembered layouts (`pi-deck--layouts`, `pi-deck--last-space`), agent locations, space/pane commands, reveal |
| `pi-deck-workers.el` | orchestration panels beside their parent, forks assigned to the parent's space, closed-worker records, read-only views and resuming them as independent sessions |
| `pi-deck-runtime.el` | public Pilish runtime/view API, attach/discovery, reconnect, explicit Resume, stopped native-terminal views |
| `pi-deck-close.el` | unconfirmed global Close, layout-only Hide, acknowledged parent cancellation, space and peer-view cleanup |
| `pi-deck-headers.el` | pane title bars (header lines with optional prefix, status, model/context or exit, `[↑]` `[↓]` `[⑂]` (Pi) `[⤢]` `[✕]`) |
| `pi-deck-sidebar.el` | sidebar space tree (clickable rows and buttons), its header line (status summary, `pi-deck-sidebar-header-items`), shared width and narrow-frame hiding, preferences file |
| `pi-deck-menus.el` | popup menus: right-click menus for agents, closed workers and spaces; forking (`pi-deck-fork`) |
| `pi-deck-goto.el` | agent picker, jump, show alone, next attention/agent, dialog answering |
| `pi-deck-notify.el` | blocked/finished notifications; `pi-deck-notify-functions` hook for other deliveries (pi-sound) |
| `pi-deck-layout.el` | grid of the space's agents |
| `pi-deck-persist.el` | schema-3 runtime/draft/parent/layout persistence, view-only restore, retained failures, explicit safe v2 migration |
| `pi-deck-restart.el` | explicit manual/supervised replacement policy, identity-checked acknowledged helper |
| `pi-deck-daemon.el` | server info (`pi-deck-daemon-info`), config reload, guarded daemon restart |
| `pi-deck-menu.el` | transient menu |
| `test/pi-deck-test.el` | ERT suite (fake Pilish sessions, real ghostel terminals) |
| `test/smoke.sh`, `test/smoke.el`, `test/support/faux.ts` | real Pi smoke in a disposable daemon |

Dependency order: core → spaces → runtime → workers → close → headers → sidebar → menus →
goto/notify/layout/persist → restart/daemon/menu → pi-deck. No cycles; forward
references use `declare-function`.

## Rules

- Pilish integration goes through public APIs and hooks
  (`pilish-activity-phase-functions`, `pilish-extension-dialog-functions`,
  `pilish-extension-status-functions`, `pilish-session-identity-functions`,
  `pilish-session-pending-dialogs`,
  `pilish-session-extension-status`, `pilish-start-session`). Needed Pilish
  changes belong in the separately pinned, isolated Pilish candidate with tests,
  not in workarounds or edits to a live-loaded checkout.
- `pi-deck-agents` returns agents in creation order (`pi-deck-agent-number`);
  keep it the one stable order (saved state lists agents in it and restore
  re-tracks them in it). `pi-deck-agent-space` is the fixed home space
  (assigned, parent, directory, displaying layout only as a last resort); use
  `pi-deck--agent-tab` when you need which layout displays an agent.
- A space's layout in a frame is one hidden `tab-bar` tab whose group is the
  space name; `tab-bar-show` stays nil while `pi-deck-mode` is on. Switch
  spaces only with `pi-deck-select-space` (it remembers the layout being
  left); set tab groups with `pi-deck--set-tab-group`
  (`tab-bar-change-tab-group`'s default hook moves tabs). Remembered layouts
  are `window-state-get` of `window-main-window`, so side windows (the
  sidebar) are never part of them.
- Never write the user's init files; preferences and state live under
  `user-emacs-directory`/var/pi-deck/.
- Tests never call paid models: ERT uses fake sessions, smoke uses Pi's faux
  provider with a private agent directory and server socket.
- Evil: the sidebar's keys live in its normal-state auxiliary map (built
  from `pi-deck-sidebar-mode-map`), which beats evil-collection's
  `special-mode` bindings; refresh is `gr` there so the `g` prefix survives.
- A chat window plus its input window is one Pilish pair (`pilish-window-pair`)
  and one pane (`pi-deck--pane-of`). Pane code uses Pilish's pair API
  (`pilish-split-input-window`, `pilish-dissolve-window-pair`,
  `pilish-repair-window-pairs`) and never pairs windows itself; split and zoom
  panes, never their halves. `pi-deck-mode` turns on `pilish-window-pairing-mode`.
- Read Pilish sessions only through its public `pilish-session-*` accessors,
  `pilish-session-exists-p` and `pilish-view-session-file`; ask Pilish for a new
  accessor instead of reading `pilish--` state.
- Pilish never guesses pairs from restored window shapes; pi-deck re-pairs
  explicitly after `window-state-put` restores and space switches
  (`pilish-repair-window-pairs`).
- Never split, display in or delete the selected window when it may be a side window
  (the sidebar). Commands act on `pi-deck--main-window` / `pi-deck--pane-window` (the
  most recently used chat pair, else other non-side window, when a side window is
  selected) and `pi-deck--split-pane` (splits with the pane selected, so the new window
  never shows the sidebar). `get-largest-window`/`get-mru-window` skip dedicated pair
  windows unless asked; use these helpers instead. Select a non-side window
  (`pi-deck--select-ordinary-window`) before `delete-other-windows`;
  `pi-deck--single-window` reduces a layout to one plain window.
- The sidebar has one width for all frames and spaces: `pi-deck--sidebar-sync`
  enforces `pi-deck-sidebar-width`, and `pi-deck--on-window-size-change` adopts
  and saves a dragged width (a sidebar resized within an unchanged frame).
  Frames without `pi-deck-sidebar-min-pane-width` columns beside it hide it.
- Popup menus open on release (`mouse-3`, never `down-mouse-3`): a text
  terminal menu opened on press picks its first item at the release.
- Sidebar/header ✕, menus and keys use one unconfirmed global Close
  (`pi-deck-close-agent`). Hide (`pi-deck-hide-pane`) changes layout only.
  Close space closes agents and owned descendants before forgetting its layout.
  Independent interactive forks remain peers. Never remove views on dispatch,
  socket loss or timeout: wait for the owning runtime/task acknowledgement.
  `pilish-session-closed-functions` removes peer views/layouts idempotently without
  another stop; Pilish owns terminal buffer disposal. Frontend teardown still
  disconnects only. Failure/uncertainty retains recoverable local state.
- Header line buttons use `local-map` (header lines ignore `keymap`).
- The pseudo-space for agents without a space is labelled "other"; a real
  space may have that name, so test registration (`pi-deck-space-names`),
  never the label.
- Tab switches (space switches) can drop the pairs' atoms;
  `pi-deck--on-tab-select` repairs pairs at once so commands right after a
  space switch see them.
- State saves are event-driven (`pi-deck-schedule-save`): never add
  periodic saving. Preferences changed by commands (sidebar toggle) are
  saved with `pi-deck-save-preference`.
- The state file has one owner, the server socket it records. Automatic
  saves (`pi-deck--save-now`, also used by restart and `kill-emacs-hook`) need
  `pi-deck--state-owner`, and none run during a staggered restore
  (`pi-deck--restoring`). `pi-deck-claim-state` decides ownership and
  restores once per Emacs, in a daemon only from `emacs-startup-hook` (the
  server starts after the init file; sessions spawned earlier miss the
  orchestration environment). Tests bind a fake owner in
  `pi-deck-test--with-deck`; disposable daemons never own the user's file.
- Orchestration targets are identified by `pi-orchestration-targets`
  (`:kind`), not by terminal major mode.
- A worker waiting for the user is read only from pi-ant's `worker-frame`
  extension status starting with `worker:waiting`
  (`pi-deck--waiting-status-key`, `pi-deck--waiting-status-prefix`); it changes
  when a new run starts. Waiting is `blocked`, so attention, notifications and
  sounds need nothing of their own.
- A terminal whose command ended stays an agent (panels retain their buffers for
  `panel-read`); the sidebar folds it into its space's finished shells row
  (`pi-deck-agent-finished-shell-p`), whose ✕ closes those agents. Managed panels
  use public `pi-orchestration-panel-command-state`, never persistent-wrapper
  liveness; unknown managed state is not completion. Unmanaged terminals keep
  process/prompt-mark behavior. Finished workers
  are records of buffers already gone, so their ✕ only forgets the records. The
  state file keeps them with parents as buffer names; restore remaps parent
  names and reconnects task-owned views without promoting or restarting workers.
- Resuming a closed worker (`pi-deck-resume-finished-worker`) starts an ordinary
  session on its file: no orchestration target, no result to the parent.
- `*.elc` files are build output (`make compile`), not tracked; the config
  loads this checkout with `load-prefer-newer`, so stale ones never shadow
  sources.

## Checks

Use explicit fresh asset and candidate source inputs; see `RUNTIME.md`:

```sh
PHIMACS_TEST_ASSETS=/absolute/fresh-assets/emacs \
PHIMACS_TEST_PILISH=/absolute/candidate-pilish \
  node scripts/emacs-deck-tests.mjs
PHIMACS_TEST_ASSETS=/absolute/fresh-assets/emacs \
PHIMACS_TEST_PILISH=/absolute/candidate-pilish \
  node scripts/emacs-deck-tests.mjs --compile
```

Run those from the Phimacs root for the original lifecycle lane. From this
package, make test/test-legacy use the owned Node harness with the same explicit
asset receipts. Compilation treats warnings as errors. No floating dependency
installer/global stamp remains. Native smoke additionally needs
PHIMACS_TEST_RUNTIME and verified grammars; see RUNTIME.md.
Never use the real daemon, home grammars, installed package/native caches or live
runtime discovery to make a test pass.

## Lifecycle and runtime capability

- Only actual mode transitions install/remove resources or capture/restore previous
  settings. Disable removes owned side windows from all saved tabs, pane headers,
  terminal observers, hooks and all timers, without stopping processes.
- Save empty owned registries. An incomplete staggered restore keeps its original
  file; do not cancel a restore then overwrite its still-pending records.
- A failed save/helper preparation cannot exit Emacs. Supervised replacement needs
  its explicit command and never falls back to manual startup. Acknowledgement is
  preparation, not proof of a successor that can start only after the old owner exits.
- `pi-deck-integration-capabilities` checks complete owning Pilish API 1/protocol 2
  and its `:authoritative-close` capability before reporting detached desktop support. Schema 3 restores views only, retains
  failed records, and never replays saved input or commands. Use the public APIs
  in API.md; no private-state detection or automatic fresh-Pi fallback.
- `pilish-session-process` is a transport; use `pilish-session-runtime` for actual
  Pi identity. Parent-owned task cancellation never falls back to root stop/start.
- Save opaque public desktop state, including drafts/images/quarantine/follow-ups.
  Observe public desktop/identity hooks and local public input changes; never
  reconstruct queue ownership or silently reuse a draft for a changed branch.
- Re-run native acceptance against final fork/grammar/release bytes. Mocked API
  tests and environmental skips do not certify the socket implementation.

## Known issues

- Layouts are per frame while open: two frames showing one space keep separate
  layouts, and `pi-deck--layouts` keeps whichever was remembered last.
- Evil's `SPC w r` (`evil-window-rotate-downwards`) with the sidebar open can leave
  two pairs showing the same session (Evil's side-window save/restore fails to put
  chat states into input-sized windows); the pairs stay consistent.
- Terminal status hooks `ghostel--osc133-marker` (ghostel internal); ghostel upgrades
  can break it.
