# pi-deck

Spaces, pane layouts and an agent sidebar for Pi inside Emacs. Pilish owns chats,
input, dialogs and rendering; Ghostel owns terminals; pi-deck owns workspace UI.
The optional orchestration companion adds managed workers, forks and panels.

This is a **private Phimacs implementation candidate**, not a completed public
release. Lifecycle and detached desktop contracts have focused regression tests;
native cross-frontend/release acceptance remains distinct. See [runtime/view
contracts](RUNTIME.md).

## Installation boundary

Use the coordinated Phimacs [installation](../../docs/install.md) and optional
[reference configuration](../config/README.md), not moving package archives,
personal checkouts or implicit first-start downloads. Existing Emacs users can
install the selected Lisp source archives without adopting the reference UI.

The supported candidate requires Linux, Node 24+, Emacs 31.1+ with tree-sitter and
native modules, the exact tested Pi, and the compatible separately pinned Pilish
fork. A `pilish >= 3.1.0` package header alone does not identify its integration API.
Ghostel 0.59.0+, Transient 0.9.0+ and Pilish's rendering dependencies are selected
through the locked Lisp inputs, not independent floating installation instructions.
Both Markdown grammars and the matching Ghostel module are explicitly provisioned
before startup. Authentication is explicit and never copied by setup.

Installing optional libraries does not enable their Pi tools or grant audio/device
access. Load the orchestration companion before managed sessions when selected.
The reference configuration uses its own init/state directories and a separate
user override file; it never replaces an existing `~/.emacs.d`.

## Spaces, agents and panes

- A **space** is a project directory with one window layout, stored in a hidden
  tab-bar tab. Switching spaces switches the layout; the tab bar stays hidden.
- An **agent** is a Pilish session or Ghostel terminal. It can remain tracked while
  no window shows it. Agents have a fixed home space and stable creation order;
  displaying one elsewhere does not move or reorder it.
- A **pane** is one terminal or an atomic Pilish chat/input pair. Pane commands
  split, hide and zoom pairs as a unit, never by guessing adjacent window shapes.

Create a space with `S`, switch with `s` or click its name. A new space offers Pi,
shell or Dired (`pi-deck-new-space-action`). A frame opening a space starts with its
last remembered layout, else the directory. Layouts remain frame-local while open;
the most recently remembered layout seeds another frame.

## Sidebar and attention

The sidebar is shown in frames with room for its width plus
`pi-deck-sidebar-min-pane-width`. Narrow frames hide it. `b` toggles it everywhere;
dragging its edge updates the shared saved width. Preferences never rewrite init.

Its header summarizes blocked, unseen-finished and working agents; click it for
next attention. `pi-deck-sidebar-header-items` can append optional buttons.
Each space lists its agents in creation order, with workers/panels under their
parent, folded finished workers and finished shells. Unassigned agents appear
under “other”. Highlighted rows are visible in the current frame.

| State | Meaning |
|---|---|
| blocked | Pending dialog or worker waiting for human guidance |
| done | Work finished while unseen; cleared when visible |
| working | Sending, inference, tools, compaction or a running shell command |
| idle | Awaiting input, shell prompt or exited terminal |
| unknown | Missing process/connection or unmarked terminal state |

Priority is blocked, done, working, idle, unknown. Terminal status uses OSC 133
marks; exited terminals keep their text and status. Managed panels use their public
command state: a completed command folds into finished shells while its persistent
wrapper retains the output until Close. Unknown command state is not completion.
Ghostel's private marker boundary is version-coupled and covered by integration tests.

Notifications report blocked/finished transitions while invisible. Workers and
panels do not emit ordinary finished notifications because their result belongs to
the parent. D-Bus falls back to the echo area; `pi-deck-notify-functions` supports
optional explicitly configured sound/notification integrations.

## Keyboard

Bind `pi-deck-command-map` to a prefix such as `C-c d`; the reference UI also uses
`SPC d` and `M-m d`.

| Key | Action |
|---|---|
| `b` | Toggle sidebar |
| `g` | Agent picker; prefix argument filters status |
| `n` | Next attention |
| `N` / `P` | Next/previous agent in stable sidebar order |
| `a` / `e` | New Pi agent / shell in the current space |
| `C` | Attach an existing detached runtime (no new agent) |
| `u` / `U` | Reconnect the existing runtime / explicitly Resume a stopped view |
| `f` | Fork current Pi session |
| `A` | Answer the current agent's pending dialog |
| `S` / `s` | Create/switch space |
| `R` / `K` | Rename/close space |
| `\|` / `-` | Split pane right/below |
| `z` | Zoom pane; again restores layout |
| `X` | Close agent everywhere, without confirmation |
| `x` | Hide pane without stopping its agent |
| `=` | Repair chat/input pairs |
| `l` | Grid of agents; shells optional |
| `m` / `?` | Transient menu, including state and daemon actions |

In the sidebar, `RET` visits a row, `o` shows an agent beside the current pane,
`TAB` folds, `j`/`k` or `n`/`p` move, `K` closes, `N`/`E` create an agent/shell,
and `q` hides the sidebar. Under Evil it stays in normal state and refresh is `gr`,
so leader keys, `gg` and search continue to work.

## Mouse, dialogs and title bars

A row click jumps to its agent; double-click shows it alone; middle-click shows it
beside the current pane without leaving the sidebar. Right-click opens contextual
menus on release. A current unfolded space's name opens its directory beside the
pane. Space counts fold their agents; `+` offers new agent/shell actions.

Title bars display name, status and model/context or terminal exit details.
`[↑]` toggles jump-to-final-answer, `[↓]` follows latest output, `[⑂]` forks,
`[⤢]` zooms and `[✕]` **closes the agent**, just like sidebar ✕. Optional
`pi-deck-pane-header-prefix-function` supplies a window-number prefix.

Inline dialogs wait in chat rather than interrupting another draft. Jumping to a
blocked agent focuses its question; click, Return or a choice digit answers, Tab
moves, and `C-c C-k` cancels. First-answer-wins and cross-frontend dialog closure
belong to the shared runtime/frontend contract, not a guessed local UI state.

## Workers, panels and closing

A panel opens beside its visible parent without taking focus. Workers, forks and
panels with hidden parents remain listed until revealed. Finished workers retain
session links; Open transcript is read-only and Resume explicitly opens an
independent session, returning no result to the old parent. Forgetting a finished
worker row leaves its session on disk. Closing finished shells loses their output.

Close stops the agent everywhere, without confirmation, whether idle, working or
blocked. Sidebar ✕, title-bar ✕, menu Close and keyboard Close use the same action.
Owned workers and panels close before their parent; independent forks remain peers.
Close space closes its agents and owned descendants before forgetting its layout.
The owning runtime/task must acknowledge termination before views disappear; failed
or uncertain closure retains local state. Another frontend's authoritative closure
removes panes, sidebar entries and saved active views here too. Retained terminal
receipts prevent a closed agent returning as an active view after desktop restore.
Transcripts remain on disk; Pilish retains unsent local work outside the active list.

Hide changes layout only and never stops an agent. Closing Emacs or losing a socket
also leaves detached agents running; neither is agent Close. Reconnect never creates
an agent; Resume is explicit.

## State ownership and Emacs restart

Only the server whose socket owns `pi-deck-state-file` automatically restores or
saves it. Disposable/other Emacs instances do neither. Explicit Save can take over;
an owned but unrestored file is backed up before replacement. Saves are event-driven,
including the empty state after deleting the final space, never periodic.

Enable/disable is idempotent. Disable restores the actual previous dialog/pairing/
tab/callback settings and removes owned sidebar windows, pane headers, hooks and
all pending timers without stopping processes or changing unrelated panes.

Restart has separate `manual` and `supervised` modes. A validated, acknowledged
helper must be ready before Emacs exits, and a failed save prevents exit. The helper
waits for commitment and old PID/start-identity exit, then invokes only the selected
command. Supervised mode requires an explicit supervisor command and never starts
a manual fallback. A frontend restart may lose host-native panels/shells, but must
not send Stop Agent to detached RPC roots. See [the exact boundary](RUNTIME.md).

Schema 3 saves runtime identities, local drafts/images/recoverable queued work,
parent links and layout separately. Restore attaches an existing runtime and adopts
its authoritative current session; it never reopens a stale file for writing.
Missing runtimes become stopped views with explicit Resume. Native terminals become
stopped placeholders, with no shell-command replay. Failed records remain recoverable
for explicit restore retry. Version-2 state requires `pi-deck-migrate-state`, which
keeps its original backup and converts records only into stopped views.

`pi-deck-integration-capabilities` enables detached restoration only with the complete
compatible public Pilish API; an incompatible loaded fork fails before deck enable.
Capability checks and mocked contract tests do not replace native release acceptance.

## Development and limitations

Use the explicitly fresh inputs and focused commands in [RUNTIME.md](RUNTIME.md).
The reference configuration's tests cover fresh locked Lisp/native acquisition,
read-only doctor, private state, GUI and 256-/truecolour terminal UI. UI-only tests
do not certify full Pi/Pilish/runtime reconnect or clean end-to-end installation.
The owned harness and smoke use explicit fresh asset/candidate/release paths, never
personal caches, implicit package installation or sibling/global Pi fallbacks.
The native lane must be rerun against the final compiled release and fork inputs.

Known external boundaries remain: per-frame layouts can differ, Emacs rendering is
single-threaded, Ghostel's private terminal APIs need version-pinned tests, and
upstream Markdown/fontification/image/scrolling limitations are not fixed merely
by consolidating the repository. Third-party code retains its original licenses.
