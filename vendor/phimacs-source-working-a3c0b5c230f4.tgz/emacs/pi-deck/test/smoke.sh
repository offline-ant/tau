#!/bin/sh
# Native faux-only smoke from explicit fresh assets and an installed release.
set -eu
exec node "$(dirname "$0")/smoke.mjs" "$@"
