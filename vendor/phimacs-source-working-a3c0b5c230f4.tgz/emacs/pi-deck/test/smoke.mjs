#!/usr/bin/env node
/** Native deck/Pilish/protocol-2 smoke. All sessions and IPC are synthetic. */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import { createClaimTestEnvironment } from '@phimacs/pimux/ownership';
import { testGrammars } from '../scripts/grammars.mjs';

const deck = fileURLToPath(new URL('../', import.meta.url));
const assets = process.env.PHIMACS_TEST_ASSETS;
const pilish = process.env.PHIMACS_TEST_PILISH;
const runtime = process.env.PHIMACS_TEST_RUNTIME;
for (const [name, value] of Object.entries({ PHIMACS_TEST_ASSETS: assets, PHIMACS_TEST_PILISH: pilish, PHIMACS_TEST_RUNTIME: runtime })) {
  if (!value || !path.isAbsolute(value)) throw new Error(`Set absolute ${name}; no source sibling/global/home fallback is supported`);
}
const receipt = JSON.parse(await fs.readFile(path.join(assets, 'provision.json'), 'utf8'));
const grammars = await testGrammars(assets, receipt, { required: true });
const pi = path.join(runtime, 'node_modules/.bin/pi');
const pimux = path.join(runtime, 'node_modules/.bin/pimux');
await fs.access(pi); await fs.access(pimux);
const piPackage = JSON.parse(await fs.readFile(path.join(runtime, 'node_modules/@earendil-works/pi-coding-agent/package.json'), 'utf8'));
const piHash = crypto.createHash('sha256').update(await fs.readFile(await fs.realpath(pi))).digest('hex');
const test = createClaimTestEnvironment();
const home = path.join(test.root, 'home');
const tmp = path.join(test.root, 'tmp');
const project = path.join(test.root, 'project');
const server = path.join(test.root, 'emacs');
const init = path.join(test.root, 'init.el');
const tmuxSocket = path.join(test.root, 'tmux');
const emacs = process.env.EMACS ?? 'emacs';
const client = process.env.EMACSCLIENT ?? 'emacsclient';
const orchestration = path.join(runtime, 'node_modules/pi-orchestration');
const extensions = path.join(runtime, 'node_modules/pi-ant');
const withOrchestration = process.env.PHIMACS_SMOKE_ORCHESTRATION === '1';
const env = { ...process.env, ...test.env, HOME: home, TMPDIR: tmp, SHELL: '/bin/bash',
  XDG_CONFIG_HOME: path.join(home, 'config'), XDG_CACHE_HOME: path.join(home, 'cache'), XDG_DATA_HOME: path.join(home, 'data'),
  EMACSLOADPATH: '', DISPLAY: '', WAYLAND_DISPLAY: '', GDK_BACKEND: 'x11',
  PI_CODING_AGENT_DIR: path.join(home, 'agent'), PI_CODING_AGENT_SESSION_DIR: test.sessions,
  PIMUX_DIR: path.join(test.root, 'mux'), PHIMACS_PI_VERSION: piPackage.version, PHIMACS_PI_SHA256: piHash };
for (const key of Object.keys(env)) if (/^(PI_ORCHESTRATION_|PI_WORKER_|PHIMACS_PARENT_TASK(?:_|$)|PHIMACS_MANAGED_CLAIM$|PIMUX_(?!DIR$)|PI_REMOTE$|HERDR_|TMUX|ANTHROPIC_API_KEY|OPENAI_API_KEY|GOOGLE_API_KEY)/.test(key)) delete env[key];
for (const directory of [home, tmp, project, env.PI_CODING_AGENT_DIR]) await fs.mkdir(directory, { mode: 0o700 });
await fs.writeFile(path.join(env.PI_CODING_AGENT_DIR, 'settings.json'), '{}\n', { mode: 0o600 });
const loads = [...receipt.packages.flatMap(pkg => pkg.loadPaths.map(directory => path.resolve(assets, directory))),
  pilish, deck, path.join(deck, 'test'), ...(withOrchestration ? [path.join(orchestration, 'emacs')] : [])];
const args = ['--no-extensions', '--no-skills', '--no-prompt-templates', '--no-context-files',
  '-e', path.join(deck, 'test/support/faux.ts'), '-e', path.join(extensions, 'extensions/error-prompt.ts'),
  ...(withOrchestration ? ['-e', orchestration] : []), '--provider', 'pi-deck-faux', '--model', 'one'];
const lisp = value => JSON.stringify(value);
const list = values => `(${values.map(lisp).join(' ')})`;
await fs.writeFile(init, `;;; -*- lexical-binding: t; -*-\n
(setq load-prefer-newer t native-comp-jit-compilation nil
      treesit-extra-load-path '( ${lisp(grammars)} )
      ghostel-module-directory ${lisp(path.join(assets, 'ghostel/'))}
      pilish-essential-grammar-action 'warn)
(dolist (directory '${list(loads)}) (add-to-list 'load-path directory t))
(require 'pilish)
(pilish-configure-runtime :pi-executable ${lisp(pi)} :pimux-executable ${lisp(pimux)} :protocol 2)
(setq pilish-extra-args '${list(args)} pilish-chat-style 'pi pilish-input-window-height 'fit
      pi-deck-new-space-action 'dired
      pi-deck-state-file ${lisp(path.join(test.root, 'desktop.eld'))}
      pi-deck-preferences-file ${lisp(path.join(test.root, 'preferences.eld'))}
      pi-deck-restart-command '${list([emacs, '-Q', '--daemon=%s', '-l', init])})
${withOrchestration ? "(require 'pi-orchestration)" : ''}
(require 'smoke)
(advice-add 'pi-deck--restart-script :filter-return
            (lambda (script)
              (with-temp-file ${lisp(path.join(test.root, 'restart-handoff.sh'))} (insert script))
              script))
(pi-deck-mode 1)
`, { mode: 0o600 });

function run(command, arguments_, { allowFailure = false, timeout = 90_000 } = {}) {
  const result = spawnSync(command, arguments_, { env, encoding: 'utf8', timeout, maxBuffer: 8 * 1024 * 1024 });
  if (!allowFailure && (result.error || result.status !== 0)) throw new Error(`${command}: ${result.error?.message ?? result.stderr ?? result.stdout}`);
  return result;
}
function evaluate(expression, options) { return run(client, ['-s', server, '--eval', expression], options).stdout.trim(); }
async function until(description, predicate, seconds = 60) {
  const deadline = Date.now() + seconds * 1000;
  while (Date.now() < deadline) { if (await predicate()) return; await delay(50); }
  throw new Error(`Timed out waiting for ${description}`);
}
function daemonPid() {
  const result = run(client, ['-s', server, '--eval', '(emacs-pid)'], { allowFailure: true, timeout: 1000 });
  return result.status === 0 ? Number(result.stdout.trim()) : null;
}
function identity() {
  return JSON.parse(JSON.parse(evaluate('(json-serialize (pi-deck-smoke-runtime))')));
}
function assertIdentity(before, after) {
  for (const key of ['mux-id', 'pid', 'pi-pid', 'pi-start-time', 'pi-boot-id']) {
    if (!before[key] || before[key] !== after[key]) throw new Error(`Frontend restart replaced runtime ${key}`);
  }
}
const shellQuote = value => `'${value.replaceAll("'", "'\\''")}'`;
let passed = false;
try {
  run(emacs, ['-Q', `--daemon=${server}`, '-l', init]);
  await until('disposable daemon', () => daemonPid());
  run('tmux', ['-S', tmuxSocket, '-f', '/dev/null', 'new-session', '-d', '-x', '160', '-y', '50',
    `${shellQuote(client)} -s ${shellQuote(server)} -t`]);
  await until('test client frame', () => evaluate('(length (pi-deck--client-frames))') !== '0');
  const first = JSON.parse(evaluate(`(pi-deck-smoke-phase1 ${lisp(`${project}/`)})`));
  if (!first.startsWith('PASS1 ')) throw new Error(first);
  const session = first.slice(6);
  const original = identity();
  if (original.protocol !== 2) throw new Error('Native smoke requires detached protocol 2');
  if (withOrchestration) {
    evaluate(`(pi-deck-smoke-start-panels ${lisp(path.basename(test.root))})`);
    await until('panels/workers', () => evaluate('pi-deck-smoke-panels-result') !== 'nil', 180);
    if (JSON.parse(evaluate('pi-deck-smoke-panels-result')) !== 'PASS-PANELS') throw new Error('Panel/worker integration failed');
  }
  const old = daemonPid();
  evaluate('(run-at-time 0.1 nil (lambda () (pi-deck-restart-daemon t)))');
  await until('manual successor', () => { const pid = daemonPid(); return pid && pid !== old; });
  const second = JSON.parse(evaluate(`(pi-deck-smoke-phase2 ${lisp(session)})`));
  if (!second.startsWith('PASS2 ')) throw new Error(second);
  assertIdentity(original, identity());
  const successor = daemonPid();
  evaluate('(run-at-time 0.1 nil (function kill-emacs))');
  await until('frontend exit', () => !daemonPid());
  // Zero-client runtime remains alive. Ordinary Emacs startup restores a view,
  // never an agent launch, even after a non-restart-helper exit.
  run(emacs, ['-Q', `--daemon=${server}`, '-l', init]);
  await until('fresh frontend', () => { const pid = daemonPid(); return pid && pid !== successor; });
  const third = JSON.parse(evaluate(`(pi-deck-smoke-phase3 ${lisp(session)})`));
  if (!third.startsWith('PASS3 ')) throw new Error(third);
  assertIdentity(original, identity());
  console.log('PASS: detached deck manual restart and ordinary frontend reconnect; same mux/Pi identity, no paid provider');
  if (!withOrchestration) console.log('Separate orchestration lane not selected (PHIMACS_SMOKE_ORCHESTRATION=1 enables panels/workers)');
  passed = true;
} catch (error) {
  const messages = run(client, ['-s', server, '--eval', '(with-current-buffer "*Messages*" (buffer-substring-no-properties (max (point-min) (- (point-max) 12000)) (point-max)))'], { allowFailure: true, timeout: 5000 });
  await fs.writeFile(path.join(test.root, 'frontend-messages.log'), messages.stdout ?? '', { mode: 0o600 });
  if (messages.stdout) console.error(messages.stdout);
  throw error;
} finally {
  run('tmux', ['-S', tmuxSocket, 'kill-server'], { allowFailure: true, timeout: 5000 });
  const discovered = run(pimux, ['list', '--json'], { allowFailure: true, timeout: 5000 });
  if (discovered.status === 0) {
    try {
      const records = JSON.parse(discovered.stdout);
      if (!Array.isArray(records)) throw new Error('Invalid synthetic discovery response');
      for (const record of records) {
        if (!record.socket?.startsWith(`${test.root}/mux/`)) throw new Error('Refusing foreign runtime cleanup target');
        const stopped = run(pimux, ['stop', '--json', '--id', record.muxId], { allowFailure: true, timeout: 30_000 });
        if (stopped.status !== 0) { console.error(`Owned runtime cleanup uncertain: ${record.muxId}`); passed = false; }
      }
    } catch (error) { console.error(error.message); passed = false; }
  } else {
    console.error('Could not reconcile synthetic discovery; retaining its namespace');
    passed = false;
  }
  const frontendPid = daemonPid();
  run(client, ['-s', server, '--eval', '(kill-emacs)'], { allowFailure: true, timeout: 5000 });
  if (frontendPid) {
    await until('owned frontend shutdown', async () => {
      const stat = await fs.readFile(`/proc/${frontendPid}/stat`, 'utf8').catch(() => null);
      return !stat || stat.slice(stat.lastIndexOf(')') + 2).startsWith('Z ');
    }, 15).catch(error => { console.error(error.message); passed = false; });
  }
  if (!passed) console.error(`Synthetic evidence retained at ${test.root}; inspect owned processes before removing it`);
  else await fs.rm(test.root, { recursive: true, force: true });
}
if (!passed) process.exitCode = 1;
