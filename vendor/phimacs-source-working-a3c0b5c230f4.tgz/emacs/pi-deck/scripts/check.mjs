#!/usr/bin/env node
/** Explicit fresh inputs only; no package installation or home-cache fallback. */
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createClaimTestEnvironment } from '@phimacs/pimux/ownership';
import { testGrammars } from './grammars.mjs';

const deck = fileURLToPath(new URL('../', import.meta.url));
const assets = process.env.PHIMACS_TEST_ASSETS;
const pilish = process.env.PHIMACS_TEST_PILISH;
if (!assets || !pilish || !path.isAbsolute(assets) || !path.isAbsolute(pilish)) {
  throw new Error('Set absolute PHIMACS_TEST_ASSETS (fresh provisioned emacs/) and PHIMACS_TEST_PILISH (pinned candidate); run the release provisioner explicitly first');
}
const orchestration = process.env.PHIMACS_TEST_ORCHESTRATION;
if (process.argv.includes('--legacy') && (!orchestration || !path.isAbsolute(orchestration))) {
  throw new Error('The complete legacy suite includes optional orchestration contracts; supply absolute PHIMACS_TEST_ORCHESTRATION (candidate Lisp directory), or use the core-only desktop contract suite');
}
const receipt = JSON.parse(await fs.readFile(path.join(assets, 'provision.json'), 'utf8'));
if (receipt.schemaVersion !== 1 || !Array.isArray(receipt.packages)) throw new Error('Invalid fresh asset receipt');
const grammars = await testGrammars(assets, receipt);
const environment = createClaimTestEnvironment();
const root = environment.root;
const home = path.join(root, 'home');
const temporary = path.join(root, 'tmp');
await fs.mkdir(home, { mode: 0o700 });
await fs.mkdir(temporary, { mode: 0o700 });
const env = { ...process.env, ...environment.env, HOME: home, TMPDIR: temporary,
  XDG_CONFIG_HOME: path.join(home, 'config'), XDG_DATA_HOME: path.join(home, 'data'), XDG_CACHE_HOME: path.join(home, 'cache'),
  EMACSLOADPATH: '', DISPLAY: '', WAYLAND_DISPLAY: '', GDK_BACKEND: 'x11',
  PI_CODING_AGENT_DIR: path.join(home, 'agent'), PI_CODING_AGENT_SESSION_DIR: environment.sessions,
  PIMUX_DIR: path.join(root, 'mux'), PHIMACS_TEST_DECK: deck };
for (const key of Object.keys(env)) {
  if (/^(PI_ORCHESTRATION_|PI_WORKER_|PHIMACS_PARENT_TASK(?:_|$)|PHIMACS_MANAGED_CLAIM$|PIMUX_(?!DIR$)|PI_REMOTE$|HERDR_|TMUX)/.test(key)) delete env[key];
}
const loads = receipt.packages.flatMap(pkg => pkg.loadPaths.map(directory => path.resolve(assets, directory)));
const args = ['-Q', '--batch', ...loads.flatMap(directory => ['-L', directory]), '-L', pilish,
  '-L', deck, '-L', path.join(deck, 'test'), ...(orchestration ? ['-L', orchestration] : []),
  '--eval', `(setq load-prefer-newer t native-comp-jit-compilation nil pilish-essential-grammar-action (quote warn) ghostel-module-directory ${JSON.stringify(path.join(assets, 'ghostel/'))} treesit-extra-load-path (list ${JSON.stringify(grammars)}))`];
try {
  if (process.argv.includes('--preflight')) {
    args.push('--eval', '(progn (require (quote pi-deck)) (unless (plist-get (pi-deck-integration-capabilities) :detached-desktop-restore) (error "Acquire the pinned protocol-2 Pilish candidate")) (princ "Deck public API preflight passed\\n"))');
  } else if (process.argv.includes('--compile')) {
    args.push('--eval', '(setq byte-compile-error-on-warn t)', '-f', 'batch-byte-compile',
      ...(await fs.readdir(deck)).filter(file => file.endsWith('.el')).map(file => path.join(deck, file)),
      path.join(deck, 'test/smoke.el'), path.join(deck, 'test/pi-deck-native-test.el'));
  } else {
    const selected = process.argv.includes('--legacy') ? 'pi-deck-test' : 'pi-deck-detached-test';
    args.push('-l', selected);
    const index = process.argv.indexOf('--selector');
    const selector = index < 0 ? 't' : JSON.stringify(process.argv[index + 1] ?? '');
    args.push('--eval', `(ert-run-tests-batch-and-exit ${selector})`);
  }
  const result = spawnSync(process.env.EMACS ?? 'emacs', args, {
    encoding: 'utf8', env, timeout: 180_000, maxBuffer: 16 * 1024 * 1024,
  });
  process.stdout.write(result.stdout ?? '');
  process.stderr.write(result.stderr ?? '');
  if (result.error) throw result.error;
  process.exitCode = result.status ?? 1;
} finally { await fs.rm(root, { recursive: true, force: true }); }
