/** Select only explicit provisioned grammar bytes; never inspect home caches. */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

export async function testGrammars(assets, receipt, { required = false } = {}) {
  const reportPath = process.env.PHIMACS_TEST_GRAMMAR_REPORT;
  if (!reportPath) {
    const directory = path.join(assets, 'tree-sitter');
    if (required && receipt.grammars?.status !== 'verified') {
      throw new Error('Explicitly provision Markdown grammars in the release or supply PHIMACS_TEST_GRAMMAR_REPORT from the owning Pilish installer');
    }
    if (required) {
      for (const artifact of receipt.grammars.artifacts) {
        const bytes = await fs.readFile(path.join(assets, artifact.path));
        if (crypto.createHash('sha256').update(bytes).digest('hex') !== artifact.sha256) throw new Error('Provisioned grammar hash mismatch');
      }
    }
    return directory;
  }
  if (!path.isAbsolute(reportPath)) throw new Error('PHIMACS_TEST_GRAMMAR_REPORT must be absolute');
  const report = JSON.parse(await fs.readFile(reportPath, 'utf8'));
  if (report['api-version'] !== 1 || !path.isAbsolute(report.directory ?? '') || !Array.isArray(report.grammars)) {
    throw new Error('Invalid owning Pilish grammar build report');
  }
  const directory = await fs.realpath(report.directory);
  for (const language of ['markdown', 'markdown-inline']) {
    const matches = report.grammars.filter(item => item.language === language);
    if (matches.length !== 1) throw new Error(`Missing/duplicate essential grammar ${language}`);
    const grammar = matches[0];
    const library = path.join(directory, `libtree-sitter-${language}.so`);
    if (path.resolve(grammar.library) !== library || (await fs.lstat(library)).isSymbolicLink()
        || !/^[a-f0-9]{40}$/.test(grammar.revision) || !/^[a-f0-9]{64}$/.test(grammar.sha256)
        || !Number.isInteger(grammar.abi)) throw new Error(`Invalid essential grammar identity ${language}`);
    const bytes = await fs.readFile(library);
    if (crypto.createHash('sha256').update(bytes).digest('hex') !== grammar.sha256) throw new Error(`Essential grammar hash mismatch: ${language}`);
  }
  return directory;
}
