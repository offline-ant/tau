import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import test from 'node:test';

for (const harness of ['native', 'check', 'smoke']) {
  test(`${harness} harness clears inherited parent-task authority before launching its fixture`, { timeout: 15_000 }, t => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'deck-native-env-'));
    const receipt = path.join(directory, 'child.json');
    t.after(() => {
      if (fs.existsSync(receipt)) {
        // Smoke intentionally stops at the fake frontend boundary and retains
        // its namespace. Every executable in this test is a no-process stub.
        const child = JSON.parse(fs.readFileSync(receipt, 'utf8'));
        assert.ok(child.root.startsWith('/tmp/phimacs-test-'));
        fs.rmSync(child.root, { recursive: true, force: true });
      }
      fs.rmSync(directory, { recursive: true, force: true });
    });
    const assets = path.join(directory, 'assets');
    const orchestration = path.join(directory, 'orchestration');
    fs.mkdirSync(assets);
    fs.mkdirSync(orchestration);
    // These harness-boundary tests launch no Emacs, Pi, panel or provider.
    fs.writeFileSync(path.join(assets, 'provision.json'), JSON.stringify({
      schemaVersion: 1, packages: [], grammars: { status: 'verified', artifacts: [] },
    }));
    fs.writeFileSync(path.join(orchestration, 'pi-orchestration.el'), '');
    const removed = ['PHIMACS_PARENT_TASK', 'PHIMACS_PARENT_TASK_FILE', 'PHIMACS_MANAGED_CLAIM',
      'PI_ORCHESTRATION_HOST', 'PI_ORCHESTRATION_ENDPOINT', 'PI_ORCHESTRATION_TARGET',
      'PI_ORCHESTRATION_PLACEMENT', 'PI_WORKER_PARENT_PI_PID', 'PI_WORKER_ARTIFACT_DIR', 'PIMUX_DISCOVERY'];
    const emacs = path.join(directory, 'fixture');
    fs.writeFileSync(emacs, `#!${process.execPath}
const assert = require('node:assert/strict');
const fs = require('node:fs');
for (const key of ${JSON.stringify(removed)}) assert.equal(process.env[key], undefined, key);
assert.ok(process.env.PHIMACS_TEST_ROOT.startsWith('/tmp/phimacs-test-'));
assert.equal(process.env.PI_CODING_AGENT_SESSION_DIR, process.env.PHIMACS_TEST_ROOT + '/sessions');
fs.writeFileSync(${JSON.stringify(receipt)}, JSON.stringify({ root: process.env.PHIMACS_TEST_ROOT }));
${harness === 'smoke' ? "process.stderr.write('ISOLATION_PROBE_COMPLETE\\n'); process.exit(73);" : ''}
`, { mode: 0o700 });
    const cli = path.join(directory, 'owned-cli');
    fs.writeFileSync(cli, `#!${process.execPath}
const assert = require('node:assert/strict');
assert.deepEqual(process.argv.slice(2), ['list', '--json']);
process.stdout.write('[]\\n');
`, { mode: 0o700 });
    const client = path.join(directory, 'client');
    fs.writeFileSync(client, `#!${process.execPath}\nprocess.exit(1);\n`, { mode: 0o700 });
    fs.writeFileSync(path.join(directory, 'tmux'), `#!${process.execPath}\nprocess.exit(0);\n`, { mode: 0o700 });
    const runtime = path.join(directory, 'release');
    const binaries = path.join(runtime, 'node_modules/.bin');
    const piPackage = path.join(runtime, 'node_modules/@earendil-works/pi-coding-agent');
    fs.mkdirSync(binaries, { recursive: true });
    fs.mkdirSync(piPackage, { recursive: true });
    fs.writeFileSync(path.join(piPackage, 'package.json'), JSON.stringify({ version: '1.4.0' }));
    for (const name of ['pi', 'pimux']) fs.copyFileSync(cli, path.join(binaries, name));
    const script = harness === 'smoke' ? '../test/smoke.mjs' : `./${harness}.mjs`;
    const result = spawnSync(process.execPath, [fileURLToPath(new URL(script, import.meta.url))], {
      encoding: 'utf8', timeout: 10_000,
      env: { ...process.env, ...Object.fromEntries(removed.map(key => [key, 'synthetic-parent-authority'])),
        PATH: directory + path.delimiter + process.env.PATH, EMACS: emacs, EMACSCLIENT: client,
        PHIMACS_TEST_ASSETS: assets, PHIMACS_TEST_PILISH: directory,
        PHIMACS_TEST_ORCHESTRATION: orchestration, PHIMACS_PI_EXECUTABLE: cli,
        PHIMACS_PIMUX_EXECUTABLE: cli, PHIMACS_TEST_RUNTIME: runtime },
    });
    assert.equal(result.error, undefined);
    assert.equal(result.status, harness === 'smoke' ? 1 : 0, result.stdout + result.stderr);
    if (harness === 'smoke') assert.match(result.stderr, /ISOLATION_PROBE_COMPLETE/);
    const child = JSON.parse(fs.readFileSync(receipt, 'utf8'));
    if (harness !== 'smoke') {
      assert.equal(fs.existsSync(child.root), false, 'acknowledged synthetic cleanup removes its namespace');
    }
  });
}
