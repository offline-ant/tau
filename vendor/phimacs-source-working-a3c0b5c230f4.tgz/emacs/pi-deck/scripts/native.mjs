#!/usr/bin/env node
/** Real candidate Pi/faux + detached socket desktop; not packed-release proof. */
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createClaimTestEnvironment } from '@phimacs/pimux/ownership';
import { testGrammars } from './grammars.mjs';

const deck = fileURLToPath(new URL('../', import.meta.url));
const assets = process.env.PHIMACS_TEST_ASSETS;
const pilish = process.env.PHIMACS_TEST_PILISH;
const prefix = process.env.PHIMACS_TEST_RUNTIME;
const orchestration = process.env.PHIMACS_TEST_ORCHESTRATION;
const pi = process.env.PHIMACS_PI_EXECUTABLE ?? (prefix && path.join(prefix, 'node_modules/.bin/pi'));
const pimux = process.env.PHIMACS_PIMUX_EXECUTABLE ?? (prefix && path.join(prefix, 'node_modules/.bin/pimux'));
for (const [name, value] of Object.entries({ PHIMACS_TEST_ASSETS: assets, PHIMACS_TEST_PILISH: pilish, PHIMACS_TEST_ORCHESTRATION: orchestration, PHIMACS_PI_EXECUTABLE: pi, PHIMACS_PIMUX_EXECUTABLE: pimux })) {
  if (!value || !path.isAbsolute(value)) throw new Error(`Provide absolute ${name}; no home/global/sibling fallback`);
}
await fs.access(pi); await fs.access(pimux);
await fs.access(path.join(orchestration, 'pi-orchestration.el'));
const receipt = JSON.parse(await fs.readFile(path.join(assets, 'provision.json'), 'utf8'));
const grammars = await testGrammars(assets, receipt, { required: true });
const fixture = createClaimTestEnvironment();
const home = path.join(fixture.root, 'home');
const temporary = path.join(fixture.root, 'tmp');
for (const directory of [home, temporary, path.join(fixture.root, 'agent')]) await fs.mkdir(directory, { mode: 0o700 });
await fs.writeFile(path.join(fixture.root, 'agent/settings.json'), '{}\n', { mode: 0o600 });
const env = { ...process.env, ...fixture.env, HOME: home, TMPDIR: temporary, SHELL: '/bin/bash',
  XDG_CONFIG_HOME: path.join(home, 'config'), XDG_DATA_HOME: path.join(home, 'data'), XDG_CACHE_HOME: path.join(home, 'cache'),
  EMACSLOADPATH: '', DISPLAY: '', WAYLAND_DISPLAY: '', GDK_BACKEND: 'x11',
  PI_CODING_AGENT_DIR: path.join(fixture.root, 'agent'), PI_CODING_AGENT_SESSION_DIR: fixture.sessions,
  PIMUX_DIR: path.join(fixture.root, 'mux'), PHIMACS_NATIVE_DECK: '1', PHIMACS_TEST_NODE: process.execPath,
  PHIMACS_TEST_PILISH: pilish, PHIMACS_TEST_DECK: deck, PHIMACS_PI_EXECUTABLE: pi, PHIMACS_PIMUX_EXECUTABLE: pimux,
  PHIMACS_FAUX_EXTENSION: path.join(deck, 'test/support/faux.ts') };
for (const key of Object.keys(env)) {
  if (/^(PI_ORCHESTRATION_|PI_WORKER_|PHIMACS_PARENT_TASK(?:_|$)|PHIMACS_MANAGED_CLAIM$|PIMUX_(?!DIR$)|PI_REMOTE$|HERDR_|TMUX|ANTHROPIC_API_KEY|OPENAI_API_KEY|GOOGLE_API_KEY)/.test(key)) delete env[key];
}
const loads = receipt.packages.flatMap(pkg => pkg.loadPaths.map(directory => path.resolve(assets, directory)));
const args = ['-Q', '--batch', ...loads.flatMap(directory => ['-L', directory]), '-L', pilish,
  '-L', deck, '-L', path.join(deck, 'test'), '-L', orchestration,
  '--eval', `(setq load-prefer-newer t native-comp-jit-compilation nil native-comp-enable-subr-trampolines nil pilish-essential-grammar-action (quote warn) ghostel-module-directory ${JSON.stringify(path.join(assets, 'ghostel/'))} treesit-extra-load-path (list ${JSON.stringify(grammars)}))`,
  '-l', 'pi-deck-native-test', '--eval', '(ert-run-tests-batch-and-exit "^pi-deck-native-")'];
let clean = false;
try {
  const result = spawnSync(process.env.EMACS ?? 'emacs', args, { env, encoding: 'utf8', timeout: 240_000, maxBuffer: 12 * 1024 * 1024 });
  process.stdout.write(result.stdout ?? ''); process.stderr.write(result.stderr ?? '');
  if (result.error) throw result.error;
  process.exitCode = result.status ?? 1;
} finally {
  const list = () => {
    const result = spawnSync(pimux, ['list', '--json'], { env, encoding: 'utf8', timeout: 10_000 });
    if (result.error || result.status !== 0) throw new Error('Cannot reconcile synthetic discovery');
    const records = JSON.parse(result.stdout);
    if (!Array.isArray(records)) throw new Error('Invalid synthetic discovery response');
    return records;
  };
  try {
    for (const runtime of list()) {
      if (!runtime.socket?.startsWith(`${fixture.root}/mux/`)) throw new Error('Refusing foreign cleanup target');
      const result = spawnSync(pimux, ['stop', '--json', '--id', runtime.muxId], { env, encoding: 'utf8', timeout: 30_000 });
      if (result.error || result.status !== 0) throw new Error(`Owned cleanup uncertain for ${runtime.muxId}`);
    }
    clean = list().length === 0;
    try {
      await fs.access(path.join(fixture.root, 'deck-panels-pending'));
      console.error('Managed panel cleanup has unacknowledged evidence');
      clean = false;
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
  } catch (error) { console.error(error.message); }
  if (clean) await fs.rm(fixture.root, { recursive: true, force: true });
  else { console.error(`Synthetic evidence retained: ${fixture.root}`); process.exitCode = 1; }
}
