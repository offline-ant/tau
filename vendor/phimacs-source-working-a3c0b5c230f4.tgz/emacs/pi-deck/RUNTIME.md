# Runtime/view integration boundary

## Desktop, not process persistence

Deck schema 3 stores opaque public Pilish desktop state (runtime identity, current
session/branch, local draft/images, suspended follow-ups and quarantine) separately
from spaces, window layouts and stable target/parent links. Restoration calls
`pilish-restore-session-state`, never `pilish-start-session` or a shell launcher.
The frontend validates the exact live runtime and adopts its authoritative snapshot,
including a session file moved by another frontend. A missing runtime yields a
stopped/unavailable view with explicit Resume; reconnect never means restart.

Saved buffer names are remapped to restored names in layouts and parent links.
Runtime discovery attaches by mux identity, not a stale filename; an already
tracked runtime is revealed rather than attached twice. A same-named view serving
a different runtime is never adopted. Failed restore records remain serialized in
`:unrestored`, preserving their drafts and identities for explicit retry.

Native terminals/panels restore as stopped placeholders. No saved shell command is
reexecuted. Explicit Resume of an ordinary shell confirms its command; managed
workers/panels require their parent's recovery protocol. Worker identity and parent
metadata survive absence of a local orchestration registry; a disconnected worker
is not promoted into an independent root or falsely recorded as finished.

Version-2 files require explicit `pi-deck-migrate-state`. It retains a private
`.v2.bak` and converts old records into stopped views without runtime identities.
It does not read or rewrite conversation storage. Unknown schemas refuse.

## Local and global actions

- Hide changes layout only.
- Close stops an agent everywhere without confirmation, including busy agents.
  Sidebar/title-bar ✕ and menu/keyboard Close have the same meaning.
- Close space closes its agents and owned descendants before forgetting layouts.
  Independent forks are peers, not owned children.
- Reconnect attaches the same existing runtime, without starting Pi or replaying
  accepted/uncertain input.
- Resume explicitly requests a managed start for a stopped conversation, without
  submitting a prompt. Parent-owned workers cannot use root Resume.
- Close uses Pilish's identity-bound acknowledged stop or the owning orchestration
  cancellation protocol. Dispatch is not acknowledgement. Views/layouts are removed
  only after authoritative termination; failure/uncertainty retains local state.
  No bare Pi PID is signalled. Terminal notifications clean peer views idempotently
  without sending another stop. Retained terminal evidence also omits closed saved
  views from restoration; unknown owners remain recoverable unavailable views.
- Frontend teardown and transport loss disconnect only. They never mean agent Close.

The public frontend contract and callback shape are in [API.md](API.md).
`pi-deck-integration-capabilities` reports API 1/schema 3 and enables
`:detached-desktop-restore` only with the complete compatible Pilish API 1/protocol 2.
A capability check is not a substitute for native/end-to-end release acceptance.

## Enable/disable and frontend restart

Repeated enable/disable does not overwrite previous settings. Disable restores
the actual previous dialog/pairing/tab/callback settings, removes owned windows,
headers, draft observers and hooks, and cancels timers without stopping agents.
Owned empty state is saved; incomplete staggered restoration cannot overwrite its
remaining records. State writes use private temporary files and atomic rename.

Manual and supervised restart retain their separate verified helper handoff.
Commands and the helper's Linux identity are checked before Emacs exits. The helper
waits for commitment and old owner exit; supervised mode has no manual fallback.
Failed save/helper preparation keeps Emacs running. Post-exit successor failure is
recorded, not hidden behind an automatic retry. Socket clients are not Emacs-owned
Pi children; warnings distinguish host-native panels/shells that will be lost.

## Focused verification

Provision locked public inputs explicitly first; normal startup/tests never install
packages, fetch moving archives or borrow home caches. Run from this directory:

```sh
export PHIMACS_TEST_ASSETS=/absolute/fresh-assets/emacs
export PHIMACS_TEST_PILISH=/absolute/pinned-pilish
export PHIMACS_TEST_ORCHESTRATION=/absolute/candidate-orchestration/emacs
make test                       # deck public-API desktop contract regressions
PHIMACS_TEST_ORCHESTRATION=/absolute/candidate-orchestration/emacs \
  make test-legacy              # imported UI/terminal and optional host contracts
make compile                    # warnings are errors
node --test scripts/native.test.mjs  # parent-task isolation; no native processes
# Development-only alternative: verified report from the owning grammar API.
export PHIMACS_TEST_GRAMMAR_REPORT=/absolute/fresh-grammar-build/report.json
PHIMACS_PI_EXECUTABLE=/absolute/candidate/pi \
PHIMACS_PIMUX_EXECUTABLE=/absolute/compiled/pimux make native
export PHIMACS_TEST_RUNTIME=/absolute/complete-installed-release
make smoke                      # real faux-only Pi, socket clients, private daemon/TTY
PHIMACS_SMOKE_ORCHESTRATION=1 make smoke  # additional panels/worker-result lane
```

`make deps` is a read-only API preflight, not a downloader. No global cache stamp
certifies another Emacs or asset directory. Native smoke requires the provision
receipt's two verified Markdown grammars, matching Ghostel module and an installed
release's absolute Pi/pimux; it refuses missing inputs rather than silently
selecting a sibling/global executable. An explicit owning grammar-build report
can select freshly built candidate grammars instead: its two exact library paths
and SHA-256 hashes are checked before Emacs starts. This does not substitute for
final release pinning/installation evidence. All IPC and synthetic session claims use a
marked isolated test namespace. Cleanup signals no unowned process; uncertain
cleanup retains evidence instead of deleting its namespace.

The mocked desktop tests establish deck's public contract, not the owning socket
implementation. The native regressions additionally exercise real Pi/faux,
independent socket input, moved-session desktop adoption and draft quarantine,
zero-client survival, missing-owner stopped views, explicit Resume, acknowledged
unconfirmed idle/busy Close, omission of authoritatively closed saved views and
no native-shell command replay. Real persistent-wrapper panel tests also verify
finished commands stay listed with live wrappers, sidebar Close acknowledges
wrapper exit, and space Close settles owned children before their parent/layout.
The daemon/TTY smoke verifies
manual Emacs replacement and ordinary exit/start reconnect to the same mux/Pi.
Both lanes use the actual owning public APIs, not stubs. Full Tau/reference/
orchestration and packed-release acceptance remain separate gates and must be
rerun against the final graph.
Known upstream rendering/image/scrolling/platform limitations remain separately
classified; environmental skips are never reported as passing tests.
