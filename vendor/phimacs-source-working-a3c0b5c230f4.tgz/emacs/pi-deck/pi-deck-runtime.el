;;; pi-deck-runtime.el --- Detached runtime and stopped view actions -*- lexical-binding: t; -*-

;; SPDX-License-Identifier: MIT

;;; Commentary:

;; Deck owns views, never the lifetime of a socket transport's Pi process.
;; Pilish owns runtime validation, snapshot adoption, draft quarantine and the
;; identity-bound launch/control protocol.  All callbacks below follow its public
;; convention: one argument, nil on acknowledged success or an error string.

;;; Code:

(require 'pi-deck-core)
(require 'pi-deck-spaces)

(declare-function pilish-session-runtime "pilish" (buffer))
(declare-function pilish-session-desktop-state "pilish" (buffer))
(declare-function pilish-restore-session-state "pilish" (state))
(declare-function pilish-list-runtimes "pilish" ())
(declare-function pilish-attach-runtime "pilish" (runtime &optional name))
(declare-function pilish-reconnect-runtime "pilish" (buffer &optional callback))
(declare-function pilish-resume-stopped-session "pilish" (buffer &optional callback))
(declare-function pilish-stop-runtime "pilish" (buffer &optional callback))
(declare-function pilish-disconnect-session "pilish" (buffer))
(declare-function pi-deck--remap-layout-buffers "pi-deck-persist" (mapping))
(declare-function pi-deck--current-agent "pi-deck-goto" ())
(declare-function pi-deck-reveal "pi-deck-spaces" (agent))
(declare-function pi-deck-schedule-save "pi-deck-persist" (&rest ignored))

(defvar-local pi-deck--stopped-shell nil
  "Saved host-native terminal record, never an automatically replayed command.")

(define-derived-mode pi-deck-stopped-shell-mode special-mode "Stopped terminal"
  "A saved host-native terminal whose process was not restarted.")

(defun pi-deck-runtime-api-p ()
  "Return non-nil when the loaded Pilish has the complete desktop API."
  (and (boundp 'pilish-session-closed-functions)
       (cl-every #'fboundp '(pilish-session-runtime pilish-session-desktop-state
                       pilish-restore-session-state pilish-list-runtimes
                       pilish-attach-runtime pilish-reconnect-runtime
                       pilish-resume-stopped-session pilish-stop-runtime
                       pilish-disconnect-session))))

(defun pi-deck-agent-runtime (agent)
  "Return the Pi AGENT's public runtime identity, not its transport process."
  (when (eq (pi-deck-agent-kind agent) 'pi)
    (pilish-session-runtime (pi-deck-agent-buffer agent))))

(defun pi-deck--runtime-agent (runtime)
  "Return a tracked view of RUNTIME, irrespective of its current session file."
  (when-let* ((id (plist-get runtime :mux-id)))
    (cl-find-if (lambda (agent)
                  (equal id (plist-get (pi-deck-agent-runtime agent) :mux-id)))
                (pi-deck-agents))))

(defun pi-deck-attach-runtime (runtime)
  "Attach to existing RUNTIME, or reveal its already attached view.
Never start Pi or reopen the discovery entry's saved session file."
  (interactive
   (let* ((runtimes (pilish-list-runtimes))
          (choices (mapcar (lambda (runtime)
                             (cons (format "%s  %s" (plist-get runtime :mux-id)
                                           (or (plist-get runtime :session-file) "starting"))
                                   runtime))
                           runtimes)))
     (unless choices (user-error "No detached runtimes are discoverable"))
     (list (cdr (assoc (completing-read "Attach runtime: " choices nil t) choices)))))
  (pi-deck-refresh)
  (let* ((existing (pi-deck--runtime-agent runtime))
         (agent (or existing
                    (pi-deck--track (pilish-attach-runtime runtime) 'pi))))
    (unless existing
      (setf (pi-deck-agent-assigned-space agent)
            (or (pi-deck--space-for-dir (pi-deck-agent-directory agent))
                (pi-deck-current-space))))
    (pi-deck-reveal agent)
    (pi-deck--schedule-update)
    agent))

(defun pi-deck--action-agent (agent)
  "Return AGENT or the selected pane's agent, otherwise signal a user error."
  (or agent (pi-deck--current-agent) (user-error "No agent in this pane")))

(defun pi-deck--runtime-action (agent action)
  "Run public Pilish ACTION on AGENT without discarding its view on failure."
  (let ((buffer (pi-deck-agent-buffer agent)))
    (funcall action buffer
             (lambda (error)
               (when (buffer-live-p buffer)
                 (pi-deck-refresh-agent buffer)
                 (pi-deck--schedule-update)
                 (pi-deck-schedule-save))
               (when error (message "pi-deck: %s" error))))))

(defun pi-deck-reconnect-agent (&optional agent)
  "Reconnect AGENT's existing runtime; never create a missing runtime."
  (interactive)
  (let* ((agent (pi-deck--action-agent agent))
         (runtime (pi-deck-agent-runtime agent)))
    (unless (and (eq (pi-deck-agent-kind agent) 'pi)
                 (equal (plist-get runtime :protocol) 2)
                 (plist-get runtime :mux-id)
                 (not (equal (plist-get runtime :state) "stopped")))
      (user-error "This stopped view has no runtime to reconnect; use Resume"))
    (pi-deck--runtime-action agent #'pilish-reconnect-runtime)))

(defun pi-deck--restore-shell-view (record)
  "Create a stopped host-native terminal view from RECORD without spawning."
  (let ((buffer (generate-new-buffer (plist-get record :buffer)))
        (dir (plist-get record :dir)))
    (with-current-buffer buffer
      (pi-deck-stopped-shell-mode)
      (setq pi-deck--stopped-shell (copy-tree record))
      (when (and (stringp dir) (file-directory-p dir))
        (setq default-directory (file-name-as-directory dir)))
      (let ((inhibit-read-only t))
        (insert "This host-native terminal did not survive the frontend.\n\n"
                "No saved command was executed. Use Resume explicitly to start\n"
                "a new ordinary shell. Managed panels must be recreated by their owner.\n\n"
                (format "Directory: %s\nCommand: %S\n" dir (plist-get record :command)))))
    buffer))

(defun pi-deck-resume-agent (&optional agent)
  "Explicitly start AGENT's stopped conversation or ordinary terminal.
No prompt, queue, worker request or shell command is replayed by restoration."
  (interactive)
  (let* ((agent (pi-deck--action-agent agent))
         (buffer (pi-deck-agent-buffer agent)))
    (when (or (pi-deck-agent-worker-p agent)
              (equal (pi-deck-agent-placement agent) "worker"))
      (user-error "This worker/panel belongs to its parent; use the parent's recovery protocol"))
    (if (eq (pi-deck-agent-kind agent) 'pi)
        (pi-deck--runtime-action agent #'pilish-resume-stopped-session)
      (let* ((record (buffer-local-value 'pi-deck--stopped-shell buffer))
             (dir (plist-get record :dir)))
        (unless record (user-error "This shell is not a stopped restored view"))
        (unless (and (stringp dir) (file-directory-p dir))
          (user-error "The saved shell directory is unavailable"))
        (when (yes-or-no-p "Start a new shell and execute its saved command? ")
          ;; Create first: a failed spawn must leave the saved view intact.
          (let* ((new (pi-deck-start-shell dir (string-trim (buffer-name buffer) "\\*" "\\*")
                                          (plist-get record :command)))
                 (replacement (pi-deck--track new 'shell)))
            (setf (pi-deck-agent-assigned-space replacement) (pi-deck-agent-assigned-space agent))
            (pi-deck--remap-layout-buffers (list (cons (buffer-name buffer) (buffer-name new))))
            (dolist (window (get-buffer-window-list buffer nil t))
              (set-window-buffer window new))
            (kill-buffer buffer)
            (pi-deck-reveal replacement)))))))

(provide 'pi-deck-runtime)
;;; pi-deck-runtime.el ends here
