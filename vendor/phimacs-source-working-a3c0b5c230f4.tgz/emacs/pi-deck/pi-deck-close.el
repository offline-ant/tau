;;; pi-deck-close.el --- Closing agents and hiding panes -*- lexical-binding: t; -*-

;; SPDX-License-Identifier: MIT

;;; Commentary:

;; Close stops an agent through its owner, without confirmation, and removes
;; acknowledged terminal views from every local layout.  Hide changes layout
;; only.  Closing a space closes its agents and owned descendants before
;; forgetting its layouts.  Failed or uncertain closure retains local state.

;;; Code:

(require 'tab-bar)
(require 'pi-deck-core)
(require 'pi-deck-spaces)
(require 'pi-deck-runtime)

(declare-function pi-deck--client-frames "pi-deck-daemon" ())
(declare-function pi-orchestration-stop-target "pi-orchestration" (id &optional callback))
(declare-function pilish-stop-runtime "pilish" (buffer &optional callback))
(declare-function pilish-disconnect-session "pilish" (buffer))
(declare-function pi-deck--remember-worker "pi-deck-workers" (agent))
(declare-function pi-deck-clear-finished-workers "pi-deck-workers" (parent))
(declare-function pi-deck-schedule-save "pi-deck-persist" (&rest ignored))

(defvar pi-deck--pending-reveal)

;;;; Views

(defun pi-deck--shown-by-p (agent buffers)
  "Return non-nil when one of BUFFERS shows AGENT."
  (cl-some (lambda (buffer) (memq buffer buffers)) (pi-deck-agent-windows-buffers agent)))

(defun pi-deck--agents-shown-by (buffers)
  "Return the agents shown by BUFFERS."
  (cl-remove-if-not (lambda (agent) (pi-deck--shown-by-p agent buffers)) (pi-deck-agents)))

(defun pi-deck--hide-window-pane (window)
  "Remove WINDOW's pane from its layout.
The layout's only pane shows the space's directory instead."
  (let ((pane (pi-deck--pane-of window))
        (frame (window-frame window)))
    (if (eq pane (window-main-window frame))
        (with-selected-window (pilish-dissolve-window-pair window)
          (delete-other-windows)
          (switch-to-buffer (pi-deck--space-start-buffer
                             (pi-deck-current-space frame))
                            t t))
      (delete-window pane))))

(defun pi-deck--remove-views-here (buffers)
  "Remove the panes showing BUFFERS from the selected frame's layout."
  (dolist (window (window-list nil 'no-minibuf))
    (when (and (window-live-p window)
               (memq (window-buffer window) buffers)
               (not (window-parameter window 'window-side)))
      (pi-deck--hide-window-pane window))))

(defun pi-deck--remove-views (buffers)
  "Remove the panes showing BUFFERS from every layout of every client frame.
Layouts of spaces not on screen are shown briefly to change them."
  (dolist (frame (pi-deck--client-frames))
    (with-selected-frame frame
      (pi-deck--remove-views-here buffers)
      (let ((current (1+ (tab-bar--current-tab-index))) (number 0))
        (dolist (tab (pi-deck--tabs))
          (cl-incf number)
          (when (and (not (eq (car tab) 'current-tab))
                     (cl-some (lambda (buffer) (memq buffer buffers))
                              (pi-deck--tab-buffers tab frame)))
            (tab-bar-select-tab number)
            (pi-deck--remove-views-here buffers)
            (tab-bar-select-tab current))))))
  ;; Remembered layouts of spaces no frame shows keep the buffers too.
  (pi-deck--forget-layout-buffers (delq nil (mapcar #'buffer-name buffers))))

(defun pi-deck--forget-layout-buffers (names)
  "Forget remembered layouts retaining any of the closed buffer NAMES."
  (setq pi-deck--layouts
        (cl-remove-if (lambda (cell)
                        (seq-intersection names (ignore-errors (window-state-buffers (cdr cell)))))
                      pi-deck--layouts)))

(defun pi-deck-hide-pane (&optional window)
  "Hide WINDOW's pane (default the selected pane); its agent keeps running.
A chat hides with its input.  The layout's only pane shows the space's
directory instead."
  (interactive)
  (pi-deck--hide-window-pane (or window (pi-deck--pane-window))))

(defun pi-deck--remove-agent-view (agent)
  "Remove acknowledged terminal AGENT's local UI once, without another stop.
Pilish owns buffer disposal; this also runs before remote terminal disposal."
  (let ((buffer (pi-deck-agent-buffer agent)))
    (when (eq agent (pi-deck-agent buffer))
      (pi-deck--remove-views (pi-deck-agent-windows-buffers agent))
      (when (and (pi-deck-agent-worker-p agent) (eq (pi-deck-agent-kind agent) 'pi))
        (pi-deck--remember-worker agent))
      (remhash buffer pi-deck--agents)
      (pi-deck-clear-finished-workers buffer)
      (when (eq pi-deck--pending-reveal buffer) (setq pi-deck--pending-reveal nil))
      (pi-deck--schedule-update)
      (pi-deck-schedule-save))))

(defun pi-deck--on-session-terminated (buffer)
  "Remove BUFFER's active views after authoritative Pilish termination.
Socket loss and identity-free saved conversations are not terminal evidence."
  (when-let* ((agent (and (buffer-live-p buffer) (pi-deck-agent buffer))))
    (pi-deck--remove-agent-view agent)))

;;;; Closing

(defun pi-deck-stop-agent (agent &optional callback)
  "Close AGENT without asking; discard views only after acknowledged success.
CALLBACK receives nil on success or an error string. Parent-owned targets
must use their orchestration cancellation protocol, never a root promotion."
  (let ((buffer (pi-deck-agent-buffer agent)) done)
    (cl-labels
        ((finish (error)
           (unless done
             (setq done t)
             (unless error
               (condition-case failure
                   (progn
                     (when (buffer-live-p buffer)
                       (pi-deck--remove-agent-view agent)
                       (if (eq (pi-deck-agent-kind agent) 'pi)
                           (pilish-disconnect-session buffer)
                         (let ((kill-buffer-query-functions nil)) (kill-buffer buffer)))))
                 (error (setq error (error-message-string failure)))))
             (when error
               (message "pi-deck: close/view cleanup not confirmed: %s" error))
             (when callback (funcall callback error)))))
      (condition-case error
          (cond
           ((not (buffer-live-p buffer)) (finish nil))
           ((or (pi-deck-agent-target agent)
                (equal (pi-deck-agent-placement agent) "worker"))
            (unless (and (pi-deck-agent-target agent)
                         (fboundp 'pi-orchestration-stop-target))
              (user-error "The parent task's cancellation control is unavailable"))
            ;; Dispatch is not an exit acknowledgement.  The owning API calls
            ;; finish only after terminal evidence or a failure/uncertainty.
            (pi-orchestration-stop-target (pi-deck-agent-target agent) #'finish))
           ((pi-deck-agent-runtime agent)
            (pilish-stop-runtime buffer #'finish))
           (t
            (when-let* ((process (pi-deck-agent-process agent)))
              (set-process-query-on-exit-flag process nil))
            (finish nil)))
        (error (finish (error-message-string error)))))))

(defun pi-deck-stop-agents (agents &optional callback)
  "Close AGENTS sequentially; retain remaining views on failed/uncertain stop.
CALLBACK receives nil only when all closures were acknowledged, else an error."
  (if (null agents)
      (when callback (funcall callback nil))
    (pi-deck-stop-agent
     (car agents)
     (lambda (error)
       (if error (when callback (funcall callback error))
         (pi-deck-stop-agents (cdr agents) callback))))))

(defun pi-deck--with-descendants (agents)
  "Return AGENTS and their owned workers/panels, children before parents.
Closing children first preserves their parent's cancellation control until
it is no longer needed. Independent interactive forks are not owned children."
  (let (result)
    (dolist (agent agents)
      (dolist (child (reverse (pi-deck-agent-descendants agent)))
        (unless (memq child result) (setq result (append result (list child)))))
      (unless (memq agent result) (setq result (append result (list agent)))))
    result))

(defun pi-deck-close-agent (&optional agent)
  "Close AGENT and its owned workers/panels everywhere, without confirmation.
AGENT defaults to the selected pane's agent."
  (interactive)
  (pi-deck-stop-agents (pi-deck--with-descendants (list (pi-deck--action-agent agent)))))

;;;; Spaces

(defun pi-deck--drop-space-tab (space frame)
  "Remove SPACE's layout tab from FRAME.
A frame showing SPACE shows its most recent other space instead, else
nothing: its tab leaves the space and shows *scratch*."
  (with-selected-frame frame
    (when-let* ((number (pi-deck--space-tab-number space)))
      (if (and (equal (pi-deck-current-space) space)
               (null (cdr (pi-deck--tabs))))
          (progn
            (pi-deck--set-tab-group nil)
            (pi-deck--single-window)
            (switch-to-buffer (get-scratch-buffer-create) t t))
        (let ((tab-bar-tab-prevent-close-functions nil)
              (tab-bar-close-tab-select 'recent))
          (tab-bar-close-tab number))))))

(defun pi-deck--forget-space (space)
  "Forget SPACE and its local layouts after its agents have closed."
  (dolist (frame (pi-deck--client-frames)) (pi-deck--drop-space-tab space frame))
  (setq pi-deck-spaces
        (cl-remove space pi-deck-spaces :key (lambda (s) (plist-get s :name)) :test #'equal)
        pi-deck--layouts (assoc-delete-all space pi-deck--layouts))
  (when (equal pi-deck--last-space space)
    (setq pi-deck--last-space (pi-deck-current-space)))
  (pi-deck--schedule-update)
  (pi-deck-schedule-save))

(defun pi-deck-close-space (space)
  "Close SPACE's agents and owned descendants, then forget its layouts.
No confirmation is requested. Failed or uncertain closure retains the space."
  (interactive (list (pi-deck--read-space "Close space: ")))
  (pi-deck-stop-agents
   (pi-deck--with-descendants (pi-deck--space-agents space))
   (lambda (error) (unless error (pi-deck--forget-space space)))))

(provide 'pi-deck-close)
;;; pi-deck-close.el ends here
