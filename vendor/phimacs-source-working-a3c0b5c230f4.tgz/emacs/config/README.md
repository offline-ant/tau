# Reference Emacs environment

This configuration is optional. It uses a dedicated `--init-directory`, private
state, explicit pinned dependencies and a separate user override file. It never
replaces `~/.emacs.d`, installs packages on startup or loads personal dotfiles.
Package-only users can continue to use their own Emacs configuration.

The reference experience includes Dracula/dark terminal colours, Evil (`fd` to
leave insert mode), `SPC`/`M-m` leaders, numbered windows, Vertico/Orderless/
Marginalia/Consult/Embark, Corfu/Cape, a calm mode line and Messages/Help bottom
panel. Pilish uses Pi-style chat blocks, inline dialogs, fitted paired input,
steering, final-answer jumping and queue controls. The input status is below the
draft; a blank chat-coloured row separates it from history. Pi-deck provides the
spaces/sidebar workflow. Sound, browser tools and private integrations are off
unless explicitly selected.

## Current integration boundary

The reference environment uses the completed detached protocol-2 candidate,
matching versioned fork APIs and both explicitly provisioned Markdown grammars.
It refuses the old primary-stdio baseline, mismatched source/host bytes and
missing capabilities instead of emulating them or falling back to plain Pi.

The privately staged Pilish fork must provide these owning public APIs:

- `pilish-integration-capabilities` includes `:api-version 1`, `:pimux-protocol 2`
  and `:authoritative-close t`.
- `pilish-configure-runtime` accepts `:pi-executable`, `:pimux-executable`,
  `:task-status-executable` and `:protocol`; these are exact release-owned
  executable paths, not `PATH` lookups. The task reader is
  `node_modules/.bin/phimacs-task-status` from the same release.
- `pilish-install-essential-grammars(directory)` explicitly provisions the two
  essential grammars using Pilish's own pinned recipe selection.
- Existing public session accessors/pairing/identity hooks remain available.

Pi-deck exposes `pi-deck-restart-mode` (`manual` or `supervised`) and a separate
`pi-deck-supervisor-restart-command` without manual fallback. Its versioned
`pi-deck-integration-capabilities` must report `:detached-desktop-restore t` before
this configuration enables it. The candidate reports that capability only after
implementing identity-bound reconnect and safe desktop restoration. Agent Close
is unconfirmed and global; authoritative termination removes active views from
layouts and saved desktops. Frontend loss and desktop restart do not stop detached
roots. Unknown or unavailable views never submit prompts, restart workers or
replay shell commands. The task reader acknowledges worker Close only after the
owning task's final cleanup, not merely socket loss or Pi exit. Cross-frontend
packed-release acceptance remains distinct from the UI-only display tests.

## Explicit setup

Install Node 24+, Linux and Emacs 31.1+ with tree-sitter/native-module support.
`emacs/inputs.json` pins Lisp/native inputs and their licenses/checksums. A new
provisioning destination must not already exist:

```sh
node scripts/emacs-provision.mjs --destination /absolute/new-assets
node scripts/emacs-provision.mjs --grammars --destination /absolute/new-assets \
  --pilish /absolute/pinned-pilish
```

The second operation requires the exact clean Pilish revision in the input lock
and its public essential-only API. A missing/wrong API refuses actionably rather
than copying recipes or invoking a private helper. Generated assets belong to that
versioned candidate; rebuilding requires a new destination. The native module is
not downloaded on first terminal use. Ghostel's source/native notices and complete
Lisp source archives remain in the assets. Eleven audited native build-graph and
preferred-source archives retain Ghostel, Ghostty, Unicode tables, SIMD/decoder
sources and build/toolchain support, with their per-file notices. The prebuilt is
for Linux x86-64 **glibc 2.34+**, not musl. Exact upstream-prebuilt correspondence
still requires accepted attestation or an independently reviewed reproducible
build; source retention and a matching hash alone do not clear that release gate.
Essential grammar source and licenses are retained separately, and the public
owning installer report records v0.5.4, ABI 15 and generated hashes.

Select an already packed and tested runtime prefix, the matching fork and assets:

```sh
export PHIMACS_RELEASE_DIR=/absolute/versioned-runtime
export PHIMACS_EMACS_ASSETS=/absolute/new-assets/emacs
export PHIMACS_PILISH_DIR=/absolute/pinned-pilish
export PHIMACS_STATE_DIR=/absolute/private-state
node scripts/emacs-doctor.mjs --json
node scripts/emacs-setup.mjs
node scripts/emacs-launch.mjs --no-frame
node scripts/emacs-launch.mjs          # terminal frame
node scripts/emacs-launch.mjs --gui    # graphical client on the caller's display
```

The runtime release contains `release-manifest.json`, its exact Pi/pimux packages,
`node_modules/.bin/phimacs-task-status` and `lisp/pi-deck`. The manifest includes host bytes/hash, protocol/lifetime and an
exact retained-source Pilish pin. Startup refuses changed host/native/grammar bytes.
The initial package selection enables orchestration and only `/tools`/error-dialog
extensions, not the entire extension bundle. Setup writes new 0600 settings with
exclusive creation and refuses existing settings instead of replacing them.
Authentication remains an explicit action using the selected release's Pi; setup
never copies credentials or makes an inference request.

For an existing Emacs configuration, request the package-only load-path/config
form instead of reference activation:

```sh
node scripts/emacs-setup.mjs --package-only
```

This is read-only output. It does not write agent settings, enable deck, load
orchestration/sound, adopt this reference UI or start an agent. Review and evaluate
the emitted `lisp` form in your own configuration; `pi-deck-mode` remains explicit.

The reference agent directory defaults to `PHIMACS_STATE_DIR/agent`, so launching
from another Pi does not inherit that process's packages, accounts, remote target
or session directory. `--agent-dir /absolute/path` (or `PHIMACS_AGENT_DIR`) selects
an existing explicitly reviewed configuration; setup will not overwrite it.
Do not select the active installation as a test namespace.

## User overrides and optional features

`$XDG_CONFIG_HOME/phimacs/user.el` (default `~/.config/phimacs/user.el`) loads before
the reference features. `PHIMACS_USER_FILE` selects another explicit file. It is
never generated or replaced by upgrades. For example:

```elisp
(setq phimacs-enable-osc52 t)       ; explicit terminal clipboard permission
(setq phimacs-enable-sound t)       ; requires an explicitly configured backend/capture
```

Sound must also be selected in the agent's Pi package settings if its Pi extension
is wanted. Browser tools use Pi's existing package resource filters in that same
private settings file. Installing their libraries does not enable them. Claude or
native-token/private device adapters are separate private configuration, not part
of this reference setup. User customizations generated by Customize stay under the
private state directory, never the immutable config.

## Emacs lifetime and supervision

Manual mode starts one foreground daemon detached from the caller. Supervised mode
never also starts an unmanaged daemon: select `--daemon-mode supervised` and an
explicit `--supervisor-command` plus repeated `--supervisor-arg` values. That command
is responsible for starting the configured endpoint. No supervisor or service is
installed/enabled implicitly. Failed supervisor startup leaves the old system alone.
The deck's restart action first prepares and verifies a helper, saves state without
swallowing errors, then commits replacement and exits. The helper waits for the
old PID/start identity to exit; supervised replacement invokes only the configured
supervisor launcher. A later replacement-command failure cannot resurrect the old
process and is reported through its private startup log, without an automatic retry.

The endpoint is the dedicated private `STATE/sockets/SERVER` (`--server`, default
`phimacs`). Existing unresponsive sockets fail closed; neither doctor nor launcher
unlinks them or assumes a timeout proves the owner died. A manual startup timeout
cleans up only the new owned uncommitted child; uncertain cleanup retains its lock.
`--restart-after PID --restart-start STARTTIME` can defer a manual successor until
the recorded old process identity exits. It never kills the old process.

Agent Close stops it everywhere without a prompt. Closing or restarting the
Emacs frontend only disconnects; a desktop restart reconnects compatible runtimes
rather than recreating conversations. Host-native shells/panels may be lost
and require an explicit restart; the setup does not automatically replay commands.
Graphical PGTK daemons can terminate if a display they used disappears. Persistent
remote displays/compositors are optional deployment recipes, not imposed services.
Terminal clients are independent of that desktop-display limitation.

## Read-only diagnosis and tests

`emacs-doctor.mjs` checks host hash/version, locked asset paths/hashes, native and
grammar ABI/native-module loadability, exact clean Pilish source/API (including
managed storage helper bytes), authoritative Close/configuration support and the
release-contained task-status executable, Emacs capabilities, selected lifetime
mode and the configured endpoint's health. It reads no account files, refreshes no
credentials, installs nothing, sends no prompts and never starts/reclaims a peer.
All `emacsclient` probes explicitly disable alternate-editor fallback.

```sh
PHIMACS_TEST_ASSETS=/absolute/fresh-assets/emacs \
  node --test test/reference-config.test.mjs test/reference-provision.test.mjs
PHIMACS_TEST_ASSETS=/absolute/fresh-assets/emacs PHIMACS_REFERENCE_DISPLAY=1 \
  node --test test/reference-display.test.mjs
```

Display lanes use private homes, a disposable Xvfb GUI and independent PTYs in
256-colour/truecolour mode. They test the real reference UI, not full Pi/Pilish
runtime integration. Fresh source packages currently emit upstream lexical-binding,
obsolete-macro or winum declaration warnings on Emacs 31.1; those remain visible and
owned upstream, not suppressed by this configuration.

The original configuration's owner authorized MIT for original reference code.
Third-party sources retain their own MIT/GPL/other licenses and source obligations;
the MIT config license does not relicense the aggregate dependency distribution.
