;;; phimacs-environment.el --- Release/state boundary -*- lexical-binding: t; -*-
;; SPDX-License-Identifier: MIT
(require 'json)
(require 'subr-x)

(defgroup phimacs nil "The supported Phimacs reference environment." :group 'applications)
(defcustom phimacs-enable-orchestration t
  "Enable the generic Emacs orchestration companion."
  :type 'boolean :group 'phimacs)
(defcustom phimacs-enable-sound nil
  "Enable explicitly configured public sound integration."
  :type 'boolean :group 'phimacs)
(defcustom phimacs-enable-osc52 nil
  "Allow clipboard writes through the outer terminal's OSC 52 capability."
  :type 'boolean :group 'phimacs)
(defvar phimacs-release-directory nil)
(defvar phimacs-assets-directory nil)
(defvar phimacs-pilish-directory nil)
(defvar phimacs-pi-executable nil)
(defvar phimacs-pimux-executable nil)
(defvar phimacs-task-status-executable nil)
(defvar phimacs-release-manifest nil)
(defvar phimacs-user-file
  (expand-file-name "user.el" (expand-file-name "phimacs" (or (getenv "XDG_CONFIG_HOME") "~/.config"))))
(defvar phimacs--environment-loaded nil)

(defun phimacs--json (file)
  "Read FILE as JSON without evaluating source."
  (with-temp-buffer
    (insert-file-contents file)
    (json-parse-buffer :object-type 'alist :array-type 'list :null-object nil :false-object nil)))

(defun phimacs--required-directory (variable)
  "Return the existing absolute directory named by environment VARIABLE."
  (let ((value (getenv variable)))
    (unless (and value (file-name-absolute-p value) (file-directory-p value))
      (error "%s must name an existing absolute directory; run emacs-doctor.mjs" variable))
    (file-name-as-directory (file-truename value))))

(defun phimacs--asset-path (relative)
  "Resolve RELATIVE within the explicitly provisioned asset directory."
  (let ((file (expand-file-name relative phimacs-assets-directory)))
    (unless (and (not (file-name-absolute-p relative))
                 (not (member ".." (split-string relative "/")))
                 (file-in-directory-p file phimacs-assets-directory))
      (error "Invalid provisioned asset path"))
    file))

(defun phimacs-load-environment ()
  "Load locked paths and validate host identity without downloads or inference."
  (unless phimacs--environment-loaded
    (unless (version<= "31.1" emacs-version) (error "Phimacs requires Emacs 31.1 or later"))
    (setq phimacs-release-directory (phimacs--required-directory "PHIMACS_RELEASE_DIR")
          phimacs-assets-directory (phimacs--required-directory "PHIMACS_EMACS_ASSETS")
          phimacs-pilish-directory (phimacs--required-directory "PHIMACS_PILISH_DIR")
          phimacs-user-file (or (getenv "PHIMACS_USER_FILE") phimacs-user-file)
          phimacs-release-manifest (phimacs--json (expand-file-name "release-manifest.json" phimacs-release-directory)))
    (let* ((manifest phimacs-release-manifest)
           (required (alist-get 'version (alist-get 'pi manifest)))
           (host (expand-file-name "node_modules/@earendil-works/pi-coding-agent/" phimacs-release-directory))
           (installed (phimacs--json (expand-file-name "package.json" host)))
           (runtime (alist-get 'runtime manifest)))
      (unless (equal required (alist-get 'version installed))
        (error "Phimacs host version mismatch; select a complete tested release"))
      (unless (and (equal 2 (alist-get 'pimuxProtocol runtime))
                   (eq t (alist-get 'detachedTargetImplemented runtime)))
        (error "This release is not a detached protocol-2 candidate; finish runtime integration first"))
      (setq phimacs-pi-executable (expand-file-name (alist-get 'executable (alist-get 'pi manifest)) phimacs-release-directory)
            phimacs-pimux-executable (expand-file-name "node_modules/@phimacs/pimux/bin/pimux" phimacs-release-directory)
            phimacs-task-status-executable (expand-file-name "node_modules/.bin/phimacs-task-status" phimacs-release-directory))
      (dolist (program (list phimacs-pi-executable phimacs-pimux-executable phimacs-task-status-executable))
        (unless (and (file-in-directory-p program phimacs-release-directory) (file-executable-p program))
          (error "Missing or escaping release executable: %s" program)))
      (unless (equal (alist-get 'sha256 (alist-get 'pi manifest))
                     (with-temp-buffer
                       (insert-file-contents-literally phimacs-pi-executable)
                       (secure-hash 'sha256 (current-buffer))))
        (error "Pi executable differs from this immutable release; reinstall the complete release")))
    (let* ((provision (phimacs--json (expand-file-name "provision.json" phimacs-assets-directory)))
           (lock (expand-file-name "inputs.json" phimacs-assets-directory))
           (grammar-owner (alist-get 'grammars (phimacs--json lock))))
      (unless (and (equal 1 (alist-get 'schemaVersion provision))
                   (equal (alist-get 'inputsSha256 provision)
                          (with-temp-buffer (insert-file-contents-literally lock)
                                            (secure-hash 'sha256 (current-buffer)))))
        (error "Emacs asset manifest does not match its locked inputs; provision a new candidate"))
      (when grammar-owner
        (unless (equal (alist-get 'pilishRevision grammar-owner)
                       (alist-get 'revision (alist-get 'pilish (alist-get 'externalForks phimacs-release-manifest))))
          (error "Pilish release and grammar-owner revisions disagree"))
        (dolist (source (alist-get 'pilishSourceFiles grammar-owner))
          (let* ((relative (symbol-name (car source)))
                 (file (expand-file-name relative phimacs-pilish-directory)))
            (unless (and (not (file-name-absolute-p relative))
                         (not (member ".." (split-string relative "/")))
                         (file-in-directory-p file phimacs-pilish-directory)
                         (not (file-symlink-p file)) (file-regular-p file)
                         (equal (cdr source)
                                (with-temp-buffer (insert-file-contents-literally file)
                                                  (secure-hash 'sha256 (current-buffer)))))
              (error "Pinned Pilish source differs from input lock: %s" relative)))))
      (dolist (package (alist-get 'packages provision))
        (dolist (directory (alist-get 'loadPaths package))
          (let ((resolved (phimacs--asset-path directory)))
            (unless (file-directory-p resolved) (error "Missing provisioned Lisp dependency"))
            (add-to-list 'load-path resolved t))))
      (unless (equal "verified" (alist-get 'status (alist-get 'native provision)))
        (error "Matching Ghostel module is not provisioned; run explicit Emacs setup"))
      (unless (equal "verified" (alist-get 'status (alist-get 'grammars provision)))
        (error "Essential Markdown grammars are not provisioned; run explicit --grammars setup"))
      (dolist (artifact (cons (alist-get 'native provision)
                              (alist-get 'artifacts (alist-get 'grammars provision))))
        (let ((file (phimacs--asset-path (alist-get 'path artifact))))
          (unless (equal (alist-get 'sha256 artifact)
                         (with-temp-buffer
                           (insert-file-contents-literally file)
                           (secure-hash 'sha256 (current-buffer))))
            (error "Provisioned native/grammar bytes changed; select an intact release")))))
    (add-to-list 'load-path phimacs-pilish-directory)
    (add-to-list 'load-path (expand-file-name "lisp/pi-deck" phimacs-release-directory))
    (add-to-list 'load-path (expand-file-name "node_modules/pi-orchestration/emacs" phimacs-release-directory))
    (add-to-list 'load-path (expand-file-name "node_modules/pi-sound/emacs" phimacs-release-directory))
    (setq treesit-extra-load-path (list (expand-file-name "tree-sitter" phimacs-assets-directory))
          ghostel-module-directory (expand-file-name "ghostel" phimacs-assets-directory)
          pilish-essential-grammar-action 'warn)
    ;; Startup cannot download a missing native module or essential grammar.
    (unless (and (fboundp 'module-load) (treesit-available-p))
      (error "This Emacs needs native-module and tree-sitter support"))
    (setq phimacs--environment-loaded t)))

(provide 'phimacs-environment)
;;; phimacs-environment.el ends here
