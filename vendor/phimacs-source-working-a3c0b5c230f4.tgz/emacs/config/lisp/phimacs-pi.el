;;; phimacs-pi.el --- Explicit detached frontend configuration -*- lexical-binding: t; -*-
;; SPDX-License-Identifier: MIT
(require 'phimacs-environment)
(require 'phimacs-ui)
(defvar phimacs--pi-enabled nil)

(defun phimacs-chat-paste (event)
  "Send terminal paste EVENT to this chat's public input buffer."
  (interactive "e")
  (let ((input (pilish-session-input-buffer (current-buffer))))
    (unless (buffer-live-p input) (user-error "This chat has no input buffer"))
    (when-let* ((window (get-buffer-window input))) (select-window window))
    (with-current-buffer input (goto-char (point-max)) (xterm-paste event))))

(defun phimacs-move-window-pair (move &rest arguments)
  "Call Evil MOVE with ARGUMENTS while preserving a chat/input pair."
  (if (bound-and-true-p pilish-window-pairing-mode)
      (progn
        (select-window (pilish-dissolve-window-pair (selected-window)))
        (let ((ignore-window-parameters t)) (apply move arguments)))
    (apply move arguments)))

(defun phimacs-enable-pi ()
  "Enable the supported fork only after validating its public contract.
No session is started here and no missing runtime is silently relaunched."
  (unless phimacs--pi-enabled
    (setq pilish-chat-style 'pi
          pilish-input-window-height 'fit
          pilish-header-line-location 'input
          pilish-extension-dialog-style 'inline
          pilish-send-while-busy 'steer
          pilish-send-on-double-return 0.4
          pilish-input-arrow-history t
          pilish-jump-to-answer t
          pilish-header-activity-phase nil
          pilish-header-cost nil
          pilish-header-context-usage nil
          pilish-essential-grammar-action 'warn
          pi-deck-state-file (expand-file-name "deck/state.eld" phimacs-state-directory)
          pi-deck-pane-header-prefix-function #'phimacs-pane-prefix)
    (require 'pilish)
    (unless (and (fboundp 'pilish-integration-capabilities)
                 (fboundp 'pilish-configure-runtime))
      (error "Loaded Pilish at %s lacks the Phimacs detached integration API; acquire the pinned fork (never stock MELPA)"
             (or (symbol-file 'pilish) "unknown")))
    (unless (file-in-directory-p (symbol-file 'pilish-configure-runtime 'defun) phimacs-pilish-directory)
      (error "Loaded Pilish integration API is outside the selected pinned source; restart Emacs with the complete release"))
    (let ((capabilities (pilish-integration-capabilities)))
      (unless (and (equal 1 (plist-get capabilities :api-version))
                   (equal 2 (plist-get capabilities :pimux-protocol))
                   (plist-get capabilities :authoritative-close))
        (error "Unsupported Pilish integration API/protocol; select a matching complete release")))
    (pilish-configure-runtime :pi-executable phimacs-pi-executable
                             :pimux-executable phimacs-pimux-executable
                             :task-status-executable phimacs-task-status-executable :protocol 2
                             :pi-version (alist-get 'version (alist-get 'pi phimacs-release-manifest))
                             :pi-sha256 (alist-get 'sha256 (alist-get 'pi phimacs-release-manifest)))
    (pilish-window-pairing-mode 1)
    (keymap-set pilish-chat-mode-map "<xterm-paste>" #'phimacs-chat-paste)
    (face-spec-set 'pilish-pi-user-message
                   '((((class color) (min-colors 257)) :background "#353747" :extend t)
                     (((class color) (min-colors 256)) :background "#3a3a3a" :extend t)
                     (t :inherit highlight :extend t)))
    (unless (advice-member-p #'phimacs-move-window-pair 'evil-move-window)
      (advice-add 'evil-move-window :around #'phimacs-move-window-pair))
    (require 'ghostel)
    (require 'evil-ghostel)
    (when phimacs-enable-orchestration (require 'pi-orchestration))
    (require 'pi-deck)
    ;; A runtime-capable Pilish does not make the old file-based deck restore safe.
    ;; Require the completed owning view API rather than guessing from symbols.
    (unless (and (fboundp 'pi-deck-integration-capabilities)
                 (let ((capabilities (pi-deck-integration-capabilities)))
                   (and (equal 1 (plist-get capabilities :api-version))
                        (plist-get capabilities :detached-desktop-restore))))
      (error "This pi-deck lacks detached desktop restoration; finish runtime/view integration before reference startup"))
    (setq pi-deck-restart-mode (intern (or (getenv "PHIMACS_DAEMON_MODE") "manual")))
    (when-let* ((launcher (getenv "PHIMACS_EMACS_LAUNCHER")))
      (setq pi-deck-restart-command (list launcher "--no-frame" "--daemon-mode" "manual")
            pi-deck-supervisor-restart-command
            (list launcher "--no-frame" "--daemon-mode" "supervised")))
    (pi-deck-mode 1)
    (phimacs-leader "d" '(:keymap pi-deck-command-map :which-key "deck"))
    (keymap-global-set "C-c d" pi-deck-command-map)
    (when phimacs-enable-sound
      (require 'pi-sound)
      (setq pi-sound-program (expand-file-name "node_modules/.bin/pi-sound" phimacs-release-directory))
      (phimacs-leader "v" #'pi-sound-dictate)
      (keymap-global-set "C-c v" #'pi-sound-dictate)
      (keymap-global-set "M-v" #'pi-sound-dictate)
      (add-to-list 'pi-deck-sidebar-header-items #'pi-sound-button t)
      (add-hook 'pi-deck-notify-functions #'pi-sound-deck-notify))
    (setq phimacs--pi-enabled t)))

(provide 'phimacs-pi)
;;; phimacs-pi.el ends here
