;;; phimacs-ui.el --- Dracula, modal keys and completion -*- lexical-binding: t; -*-
;; SPDX-License-Identifier: MIT
(require 'cl-lib)
(require 'subr-x)
(require 'phimacs-environment)

(defvar phimacs--ui-enabled nil)
(defvar phimacs-panel-visible nil)

(defun phimacs-show-messages ()
  "Show Messages in the reference bottom panel."
  (interactive)
  (setq phimacs-panel-visible t)
  (select-window (display-buffer-in-side-window (get-buffer-create "*Messages*")
                                                '((side . bottom) (slot . 0)
                                                  (window-height . 0.25)))))

(defun phimacs-toggle-panel ()
  "Toggle this frame's Messages/Help panel without changing agent panes."
  (interactive)
  (let ((panel (cl-find-if (lambda (window)
                           (eq 'bottom (window-parameter window 'window-side)))
                         (window-list))))
    (if panel (progn (delete-window panel) (setq phimacs-panel-visible nil))
      (phimacs-show-messages))))

(defun phimacs-modeline-chat ()
  "Use one blank chat-coloured row between chat and input."
  (setq-local mode-line-format '(" "))
  (dolist (face '(mode-line mode-line-inactive))
    (face-remap-set-base face '(:inherit default :box nil :overline nil :underline nil))))

(defun phimacs-modeline-input ()
  "Move Pilish's input status below its draft."
  (setq-local mode-line-format header-line-format
              header-line-format nil))

(defun phimacs-pane-prefix ()
  "Return the window number for the public deck pane-header hook."
  (let ((number (winum-get-number-string)))
    (unless (string-empty-p number) (propertize (concat " " number) 'face 'shadow))))

(defun phimacs-tty-frame (&optional frame)
  "Enable terminal mouse and readable borders in FRAME."
  (unless (display-graphic-p frame)
    (xterm-mouse-mode 1)
    (unless standard-display-table (setq standard-display-table (make-display-table)))
    (set-display-table-slot standard-display-table 'vertical-border (make-glyph-code ?│))))

(defun phimacs-enable-ui ()
  "Enable the reference UI once using only provisioned Lisp sources."
  (unless phimacs--ui-enabled
    (setq frame-background-mode 'dark
          use-dialog-box nil
          window-sides-vertical t
          delete-window-choose-selected 'pos
          mouse-drag-copy-region 'non-empty
          evil-want-keybinding nil
          evil-want-integration t
          evil-want-C-u-scroll t
          evil-want-C-i-jump nil
          evil-want-Y-yank-to-eol t
          evil-undo-system 'undo-redo
          evil-mode-line-format nil
          evil-normal-state-cursor '("DarkGoldenrod2" box)
          evil-insert-state-cursor '("chartreuse3" (bar . 2))
          evil-motion-state-cursor '("plum3" box)
          evil-escape-key-sequence "fd"
          evil-escape-delay 0.1
          winum-auto-setup-mode-line nil
          vertico-cycle t
          vertico-count 15
          completion-styles '(orderless basic)
          completion-category-defaults nil
          completion-category-overrides '((file (styles partial-completion)))
          completion-ignore-case t
          corfu-auto t
          corfu-auto-delay 0.2
          corfu-auto-prefix 2
          corfu-cycle t
          corfu-preselect 'prompt
          tab-always-indent 'complete
          text-mode-ispell-word-completion nil
          which-key-idle-delay 0.4
          dracula-alternate-mode-line-and-minibuffer nil)
    (require 'dracula-theme)
    (load-theme 'dracula t)
    (require 'evil)
    (evil-mode 1)
    (keymap-set evil-motion-state-map "<escape>" #'ignore)
    (require 'evil-collection)
    (evil-collection-init)
    (require 'evil-surround)
    (global-evil-surround-mode 1)
    (require 'evil-escape)
    (evil-escape-mode 1)
    (require 'evil-terminal-cursor-changer)
    (unless noninteractive (evil-terminal-cursor-changer-activate))
    (require 'general)
    (general-override-mode 1)
    (general-create-definer phimacs-leader
      :states '(normal insert visual motion emacs) :keymaps 'override
      :prefix "SPC" :non-normal-prefix "M-m")
    (phimacs-leader
      "SPC" #'execute-extended-command
      "ff" #'find-file "fs" #'save-buffer
      "bb" #'consult-buffer "bd" #'kill-current-buffer
      "bm" #'phimacs-show-messages
      "ss" #'consult-line "sp" #'consult-ripgrep
      "pf" #'project-find-file "pp" #'project-switch-project
      "gs" #'magit-status
      "ww" #'other-window "wd" #'delete-window
      "w/" #'split-window-right "w-" #'split-window-below
      "wh" #'evil-window-left "wj" #'evil-window-down
      "wk" #'evil-window-up "wl" #'evil-window-right
      "wu" #'winner-undo "wU" #'winner-redo
      "tp" #'phimacs-toggle-panel
      "qq" #'delete-frame "qQ" #'save-buffers-kill-emacs
      "hf" #'describe-function "hv" #'describe-variable "hk" #'describe-key)
    (dotimes (index 9)
      (general-define-key :states '(normal insert visual motion emacs) :keymaps 'override
                          :prefix "SPC" :non-normal-prefix "M-m"
                          (number-to-string (1+ index))
                          (intern (format "winum-select-window-%d" (1+ index)))))
    (require 'winum)
    (winum-mode 1)
    (require 'which-key)
    (which-key-mode 1)
    (require 'vertico)
    (vertico-mode 1)
    (keymap-set vertico-map "C-j" #'vertico-next)
    (keymap-set vertico-map "C-k" #'vertico-previous)
    (require 'vertico-directory)
    (keymap-set vertico-map "RET" #'vertico-directory-enter)
    (keymap-set vertico-map "DEL" #'vertico-directory-delete-char)
    (require 'orderless)
    (require 'marginalia)
    (marginalia-mode 1)
    (require 'consult)
    (keymap-global-set "<remap> <switch-to-buffer>" #'consult-buffer)
    (keymap-global-set "<remap> <yank-pop>" #'consult-yank-pop)
    (require 'embark)
    (keymap-global-set "C-." #'embark-act)
    (keymap-global-set "M-." #'embark-dwim)
    (require 'embark-consult)
    (require 'corfu)
    (global-corfu-mode 1)
    (require 'corfu-popupinfo)
    (corfu-popupinfo-mode 1)
    (require 'corfu-history)
    (corfu-history-mode 1)
    (require 'cape)
    (add-hook 'completion-at-point-functions #'cape-file)
    (add-hook 'completion-at-point-functions #'cape-dabbrev 90)
    (autoload 'magit-status "magit" nil t)
    (setq-default indent-tabs-mode nil
                  fill-column 88
                  mode-line-format '("%e " (:eval (winum-get-number-string)) "  %b"
                                     (:eval (when (buffer-modified-p) " ●"))
                                     "  %m  " vc-mode mode-line-format-right-align "%l:%C "))
    (let ((backups (expand-file-name "backups" phimacs-state-directory))
          (autosaves (expand-file-name "autosaves" phimacs-state-directory)))
      (dolist (directory (list backups autosaves))
        (make-directory directory t) (set-file-modes directory #o700))
      (setq backup-directory-alist `(("." . ,backups))
            auto-save-file-name-transforms `((".*" ,autosaves t))))
    (setq savehist-file (expand-file-name "history.eld" phimacs-state-directory)
          recentf-save-file (expand-file-name "recentf.eld" phimacs-state-directory)
          save-place-file (expand-file-name "places.eld" phimacs-state-directory)
          custom-file (expand-file-name "custom.el" phimacs-state-directory)
          xterm-extra-capabilities (and phimacs-enable-osc52 '(setSelection)))
    (savehist-mode 1)
    (save-place-mode 1)
    (winner-mode 1)
    (column-number-mode 1)
    (add-to-list 'display-buffer-alist
                 '("\\*\\(?:Messages\\|Warnings\\|Help\\|Backtrace\\|Compile-Log\\)\\*"
                   display-buffer-in-side-window (side . bottom) (slot . 0) (window-height . 0.25)))
    (add-hook 'pilish-chat-mode-hook #'phimacs-modeline-chat)
    (add-hook 'pilish-input-mode-hook #'phimacs-modeline-input)
    (add-hook 'after-make-frame-functions #'phimacs-tty-frame)
    (add-hook 'tty-setup-hook #'phimacs-tty-frame)
    (unless noninteractive (phimacs-tty-frame))
    (setq phimacs--ui-enabled t)))

(provide 'phimacs-ui)
;;; phimacs-ui.el ends here
