;;; early-init.el --- Isolated Phimacs startup -*- lexical-binding: t; -*-
;; SPDX-License-Identifier: MIT

(setq package-enable-at-startup nil
      package-archives nil
      package-quickstart nil
      native-comp-jit-compilation nil
      gc-cons-threshold (* 128 1024 1024)
      read-process-output-max (* 1024 1024)
      inhibit-startup-screen t
      initial-scratch-message nil
      frame-inhibit-implied-resize t
      frame-resize-pixelwise t
      load-prefer-newer t)
(dolist (parameter '((menu-bar-lines . 0) (tool-bar-lines . 0)
                     (vertical-scroll-bars) (horizontal-scroll-bars)))
  (add-to-list 'default-frame-alist parameter))

(defconst phimacs-config-directory
  (file-name-directory (or load-file-name buffer-file-name))
  "Immutable directory containing this reference configuration.")
(defconst phimacs-state-directory
  (file-name-as-directory
   (expand-file-name
    (or (getenv "PHIMACS_STATE_DIR")
        (expand-file-name "phimacs" (or (getenv "XDG_STATE_HOME")
                                       "~/.local/state")))))
  "Private mutable state, never the reference init directory.")
(when (file-in-directory-p phimacs-state-directory phimacs-config-directory)
  (error "PHIMACS_STATE_DIR must be outside the immutable configuration"))
(unless (file-directory-p phimacs-state-directory)
  (make-directory phimacs-state-directory t)
  (set-file-modes phimacs-state-directory #o700))
(unless (and (not (file-symlink-p (directory-file-name phimacs-state-directory)))
             (equal (file-attribute-user-id (file-attributes phimacs-state-directory))
                    (user-uid))
             (zerop (logand (file-modes phimacs-state-directory) #o077)))
  (error "Phimacs state directory must be owned by you with mode 0700"))
(setq package-user-dir (expand-file-name "unmanaged-packages" phimacs-state-directory)
      package-quickstart-file (expand-file-name "package-quickstart.el" phimacs-state-directory))
(when (fboundp 'startup-redirect-eln-cache)
  (startup-redirect-eln-cache (expand-file-name "eln-cache" phimacs-state-directory)))
(when-let* ((socket (getenv "PHIMACS_SERVER_SOCKET")))
  (unless (file-name-absolute-p socket) (error "PHIMACS_SERVER_SOCKET must be absolute"))
  (setq server-name socket server-socket-dir (file-name-directory socket)))
(add-to-list 'load-path (expand-file-name "lisp" phimacs-config-directory))
(add-hook 'emacs-startup-hook
          (lambda () (setq gc-cons-threshold (* 64 1024 1024))))
;;; early-init.el ends here
