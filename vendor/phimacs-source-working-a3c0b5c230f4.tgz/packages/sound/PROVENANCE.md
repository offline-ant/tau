# Source and asset provenance

The generic library and Emacs frontend are adapted from the original MIT-licensed
pi-sound source at revision `2a2d29b2e04dedb2ec304e689f8ed1066f8f03b2`.
The original software copyright and grant are preserved in `LICENSE`.
This is a reviewed extraction, not a Git-history import. Private authentication,
service-specific speech and automatic device-selection adapters are not included.

The notification sounds retain their original Apache-2.0 license separately from
the software. `sounds/NOTICE` identifies the Herdr source revision, original files
and conversion. Unmodified asset SHA-256 values:

- `done.wav`: `5c75f79b48d930814ae31d8757421fdd45f5bcbf8d834fe7f457c43d8429222d`
- `request.wav`: `0ef67793dff8da492669f2d6e68f4585b8cc9d6021da702610d2b04ba45d0e4a`

No installed runtime binaries, credentials, recordings, profiles or user caches
are part of this source or its package artifact.
