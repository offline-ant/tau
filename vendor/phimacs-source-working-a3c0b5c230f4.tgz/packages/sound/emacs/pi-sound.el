;;; pi-sound.el --- Voice dictation into any buffer -*- lexical-binding: t; -*-

;; SPDX-License-Identifier: MIT
;; Package-Requires: ((emacs "30.1"))

;;; Commentary:

;; `pi-sound-dictate' toggles a recording: the first call starts
;; `pi-sound dictate', the second stops it and inserts the transcript where
;; the recording started.  C-g while it runs cancels.  In send mode (see
;; `pi-sound-toggle-mode') a transcript inserted into a buffer listed in
;; `pi-sound-send-commands', such as a Pilish input buffer, is then
;; submitted with that buffer's send command; elsewhere it is only inserted.
;;
;; The CLI's explicitly configured capture source and speech backend are used.
;; Loading this frontend does not configure or access audio devices.
;;
;; `pi-sound-button' returns a header or mode line button showing the
;; state: a microphone when idle, a red "● REC <device>" while recording
;; and "…" while transcribing.  mouse-1 toggles dictation, mouse-3 toggles
;; the mode.  With pi-deck add it to `pi-deck-sidebar-header-items';
;; otherwise use it in a header or mode line as (:eval (pi-sound-button)).
;;
;; `pi-sound-play' and `pi-sound-notify' play a notification sound and show a
;; desktop pop-up through the configured output sink, in the background.
;; `pi-sound-deck-notify' does both for pi-deck: add it to
;; `pi-deck-notify-functions' (blocked plays "request", finished "done").

;;; Code:

(require 'subr-x)
(require 'seq)

(defgroup pi-sound nil
  "Voice dictation through the pi-sound CLI."
  :group 'convenience
  :prefix "pi-sound-")

(defcustom pi-sound-program "pi-sound"
  "The pi-sound CLI."
  :type 'string)

(defcustom pi-sound-send-commands '((pilish-input-mode . pilish-send))
  "Major modes whose buffers send mode submits, with their send commands.
After a transcript is inserted in send mode into a buffer derived from one
of these modes, its command runs in that buffer."
  :type '(alist :key-type symbol :value-type function))

(defface pi-sound-recording
  '((t :inherit error :weight bold))
  "Tab bar face while recording.")

(defvar pi-sound-state 'idle
  "Dictation state: `idle', `connecting', `recording' or `transcribing'.")

(defvar pi-sound-state-change-functions nil
  "Functions called with the new `pi-sound-state' whenever it changes.")

(defvar pi-sound-mode nil
  "Last known mode, \"type\" or \"send\"; nil until pi-sound reports it.")

(defvar pi-sound-device nil
  "Device of the current recording, or nil.")

(defvar pi-sound--process nil)
(defvar pi-sound--marker nil
  "Where the transcript goes.")

(defun pi-sound--set-state (state)
  "Enter STATE, notify `pi-sound-state-change-functions' and redraw."
  (unless (eq state pi-sound-state)
    (setq pi-sound-state state)
    (unless (memq state '(recording transcribing))
      (setq pi-sound-device nil))
    (run-hook-with-args 'pi-sound-state-change-functions state)
    (force-mode-line-update t)))

;;;; Inserting

(defun pi-sound--send-command (buffer)
  "Return BUFFER's send command from `pi-sound-send-commands', or nil."
  (with-current-buffer buffer
    (cdr (seq-find (lambda (entry) (derived-mode-p (car entry)))
                   pi-sound-send-commands))))

(defun pi-sound--insert (text)
  "Insert TEXT at `pi-sound--marker', or save it to the kill ring.
In send mode, then submit buffers that have a send command."
  (let ((buffer (marker-buffer pi-sound--marker)))
    (if (not (and buffer (buffer-live-p buffer)
                  (not (buffer-local-value 'buffer-read-only buffer))))
        (progn (kill-new text)
               (message "Dictation copied (buffer is read-only or gone): %s" text))
      (with-current-buffer buffer
        (let* ((pos (marker-position pi-sound--marker))
               (at-point (= (point) pos))
               (text (if (and (> pos (point-min))
                              (not (memq (char-before pos) '(?\s ?\t ?\n))))
                         (concat " " text)
                       text)))
          (save-excursion (goto-char pos) (insert text))
          (when at-point (goto-char (+ pos (length text))))
          (dolist (window (get-buffer-window-list buffer nil t))
            (when (= (window-point window) pos)
              (set-window-point window (+ pos (length text)))))
          (let ((send (and (equal pi-sound-mode "send") (pi-sound--send-command buffer))))
            (if send
                (call-interactively send)
              (message "Dictated: %s" text))))))))

;;;; Process

(defun pi-sound--handle (process message)
  "Act on one parsed MESSAGE from PROCESS."
  (let ((type (alist-get 'type message)))
    (when (member type '("final" "error"))
      (process-put process 'terminal t))
    (pcase type
      ("ready"
       (setq pi-sound-device (alist-get 'device message))
       (when-let* ((mode (alist-get 'mode message))) (setq pi-sound-mode mode))
       (pi-sound--set-state 'recording)
       (message "Dictating via %s (%s, %s) — again to stop, C-g to cancel"
                pi-sound-device (alist-get 'backend message) pi-sound-mode))
      ("partial" (message "… %s" (alist-get 'text message)))
      ("final"
       (let ((text (string-trim (alist-get 'text message))))
         (pi-sound--set-state 'idle)
         (if (string-empty-p text)
             (message "Dictation: nothing heard")
           (pi-sound--insert text)
           (when (alist-get 'limited message)
             (message "Dictation stopped at the 5-minute limit")))))
      ("error"
       (pi-sound--set-state 'idle)
       (message "Dictation failed: %s" (alist-get 'message message))))))

(defun pi-sound--filter (process output)
  "Parse complete JSON lines of OUTPUT from PROCESS."
  (let ((pending (concat (or (process-get process 'pending) "") output)))
    (while (string-match "\n" pending)
      (let ((line (substring pending 0 (match-beginning 0))))
        (setq pending (substring pending (match-end 0)))
        (unless (string-empty-p line)
          (condition-case nil
              (pi-sound--handle process (json-parse-string line :object-type 'alist))
            (json-parse-error (message "Dictation: unexpected output %S" line))))))
    (process-put process 'pending pending)))

(defun pi-sound--sentinel (process _event)
  "Forget PROCESS when it ends; report an exit without a result."
  (unless (process-live-p process)
    (when (eq process pi-sound--process)
      (setq pi-sound--process nil)
      (unless (process-get process 'terminal)
        (message "Dictation: %s exited without a result (status %s); see %s"
                 pi-sound-program (process-exit-status process)
                 (buffer-name (process-get process 'stderr))))
      (pi-sound--set-state 'idle))))

(defun pi-sound-cancel ()
  "Cancel the running dictation without inserting anything, else quit."
  (interactive)
  (if (not (process-live-p pi-sound--process))
      (keyboard-quit)
    (let ((process pi-sound--process))
      (setq pi-sound--process nil)
      (delete-process process))
    (pi-sound--set-state 'idle)
    (message "Dictation cancelled")))

(defvar pi-sound--cancel-map
  (let ((map (make-sparse-keymap)))
    (keymap-set map "C-g" #'pi-sound-cancel)
    map))

;;;###autoload
(defun pi-sound-dictate ()
  "Start dictating at point, or stop and insert the transcript."
  (interactive)
  (if (process-live-p pi-sound--process)
      (if (not (eq pi-sound-state 'recording))
          (message "Dictation: still %s (C-g cancels)" pi-sound-state)
        (process-send-eof pi-sound--process)
        (pi-sound--set-state 'transcribing)
        (message "Transcribing…"))
    (let ((stderr (get-buffer-create " *pi-sound-stderr*")))
      (with-current-buffer stderr (erase-buffer))
      (setq pi-sound--marker (point-marker))
      (condition-case error
          (setq pi-sound--process
                (make-process :name "pi-sound-dictate"
                              :command (list pi-sound-program "dictate")
                              :connection-type 'pipe
                              :noquery t
                              :stderr stderr
                              :filter #'pi-sound--filter
                              :sentinel #'pi-sound--sentinel))
        (file-missing
         (user-error "Dictation: %s not found (%s)" pi-sound-program
                     (error-message-string error))))
      (process-put pi-sound--process 'stderr stderr)
      (pi-sound--set-state 'connecting)
      (message "Dictation: connecting…")
      (set-transient-map pi-sound--cancel-map
                         (lambda () (process-live-p pi-sound--process))))))

;;;###autoload
(defun pi-sound-toggle-mode ()
  "Toggle between typing transcripts and sending them."
  (interactive)
  (with-temp-buffer
    (let ((status (condition-case error
                      (call-process pi-sound-program nil '(t nil) nil "mode" "toggle")
                    (file-missing
                     (user-error "Dictation: %s not found (%s)" pi-sound-program
                                 (error-message-string error)))))
          (mode (ignore-errors
                  (alist-get 'mode (json-parse-string (buffer-string) :object-type 'alist)))))
      (unless (and (eq status 0) (stringp mode))
        (user-error "Dictation: %s mode toggle failed: %s" pi-sound-program
                    (string-trim (buffer-string))))
      (setq pi-sound-mode mode)
      (force-mode-line-update t)
      (message "Dictation mode: %s" (if (equal mode "send") "send transcripts" "type transcripts")))))

;;;; Sound and notifications on the device

(defun pi-sound--run-detached (&rest args)
  "Run the pi-sound CLI with ARGS in the background, discarding its output.
Does nothing when the CLI is missing."
  (condition-case nil
      (make-process :name "pi-sound-output"
                    :command (cons pi-sound-program args)
                    :buffer nil :connection-type 'pipe :noquery t
                    :sentinel #'ignore)
    (file-missing nil)))

(defun pi-sound-play (name)
  "Play notification sound NAME (`done' or `request') on the user's device."
  (pi-sound--run-detached "play" (format "%s" name)))

(defun pi-sound-notify (title &optional body)
  "Show a desktop notification with TITLE and BODY on the user's device."
  (apply #'pi-sound--run-detached "notify" title (and body (list body))))

(defun pi-sound-deck-notify (kind title body _agent)
  "Play a sound for KIND and show TITLE and BODY on the user's device.
A `pi-deck-notify-functions' function: `blocked' plays \"request\",
`finished' plays \"done\"."
  (pi-sound-play (if (eq kind 'blocked) 'request 'done))
  (pi-sound-notify title body))

;;;; Button

(defun pi-sound-label ()
  "Return the button label for `pi-sound-state'."
  (pcase pi-sound-state
    ('recording (propertize (format " ● REC %s " (or pi-sound-device "")) 'face 'pi-sound-recording))
    ('transcribing " … ")
    ('connecting " 🎤… ")
    (_ " 🎤 ")))

(defvar-keymap pi-sound-button-map
  :doc "Header and mode line bindings of `pi-sound-button'."
  ;; Clicks act on release; the presses do nothing.
  "<header-line> <down-mouse-1>" #'ignore
  "<header-line> <mouse-1>" #'pi-sound-button-click
  "<header-line> <down-mouse-3>" #'ignore
  "<header-line> <mouse-3>" #'pi-sound-button-click
  "<mode-line> <down-mouse-1>" #'ignore
  "<mode-line> <mouse-1>" #'pi-sound-button-click
  "<mode-line> <down-mouse-3>" #'ignore
  "<mode-line> <mouse-3>" #'pi-sound-button-click)

(defun pi-sound-button ()
  "Return the dictation button for a header or mode line.
A `pi-deck-sidebar-header-items' function."
  (propertize (pi-sound-label)
              'mouse-face 'mode-line-highlight 'pointer 'hand
              'local-map pi-sound-button-map
              'help-echo (format "mouse-1: %s dictation; mouse-3: toggle mode (%s)"
                                 (if (eq pi-sound-state 'idle) "start" "stop")
                                 (or pi-sound-mode "type or send"))))

(defun pi-sound-button-click (event)
  "Toggle dictation for mouse-1 EVENT, the mode for mouse-3."
  (interactive "e")
  (if (eq (event-basic-type event) 'mouse-3)
      (pi-sound-toggle-mode)
    (pi-sound-dictate)))

(provide 'pi-sound)
;;; pi-sound.el ends here
