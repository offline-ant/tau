;;; pi-sound-test.el --- Tests for pi-sound.el -*- lexical-binding: t; -*-

;; Run: emacs -Q --batch -L emacs -l emacs/pi-sound-test.el -f ert-run-tests-batch-and-exit

;;; Code:

(require 'ert)
(require 'cl-lib)
(require 'pi-sound)

(defconst pi-sound-test--script "#!/bin/sh
# Fake pi-sound CLI; PI_SOUND_FAKE selects the dictation behaviour.
case \"$1\" in
play|notify)
  printf '%s|' \"$@\" >> \"$PI_SOUND_LOG\"; echo >> \"$PI_SOUND_LOG\"
  echo noise; echo noise >&2
  exit 0 ;;
mode)
  echo '{\"mode\":\"send\"}'
  exit 0 ;;
dictate)
  case \"$PI_SOUND_FAKE\" in
  error) echo '{\"type\":\"error\",\"message\":\"No microphone connected\"}'; exit 0 ;;
  crash) echo boom >&2; exit 3 ;;
  esac
  printf '{\"type\":\"ready\",\"device\":\"test-device\",\"backend\":\"fake\",\"mode\":\"%s\"}\\n' \"${PI_SOUND_MODE:-type}\"
  echo '{\"type\":\"partial\",\"text\":\"hel\"}'
  cat >/dev/null
  # A JSON line split across writes.
  printf '{\"type\":\"final\",\"te'; printf 'xt\":\"hello there\"}\\n' ;;
esac
")

(define-derived-mode pi-sound-test-input-mode text-mode "Test-Input"
  "Stands in for a Pilish input buffer.")

(defmacro pi-sound-test--with-fake (env &rest body)
  "Run BODY with `pi-sound-program' a fake CLI and ENV added to the environment."
  (declare (indent 1))
  `(let* ((dir (make-temp-file "pi-sound-test" t))
          (pi-sound-program (expand-file-name "pi-sound" dir))
          (process-environment (append ,env process-environment))
          (pi-sound-state 'idle)
          (pi-sound-mode nil)
          (pi-sound-device nil)
          (pi-sound--process nil)
          (states nil)
          (pi-sound-state-change-functions (list (lambda (state) (push state states)))))
     (with-temp-file pi-sound-program (insert pi-sound-test--script))
     (set-file-modes pi-sound-program #o755)
     (unwind-protect (progn ,@body)
       (when (process-live-p pi-sound--process) (delete-process pi-sound--process))
       (delete-directory dir t))))

(defun pi-sound-test--until (predicate)
  "Wait up to 5 seconds for PREDICATE."
  (let ((deadline (+ (float-time) 5)))
    (while (and (not (funcall predicate)) (< (float-time) deadline))
      (accept-process-output nil 0.05))
    (should (funcall predicate))))

(defun pi-sound-test--record ()
  "Start dictating, wait until recording, then stop and wait until idle."
  (pi-sound-dictate)
  (pi-sound-test--until (lambda () (eq pi-sound-state 'recording)))
  (pi-sound-dictate)
  (pi-sound-test--until (lambda () (and (eq pi-sound-state 'idle) (null pi-sound--process)))))

(ert-deftest pi-sound-type-inserts-at-start-with-spacing ()
  (pi-sound-test--with-fake nil
    (with-temp-buffer
      (insert "say")
      (pi-sound-dictate)
      (pi-sound-test--until (lambda () (eq pi-sound-state 'recording)))
      (should (equal pi-sound-device "test-device"))
      (should (equal pi-sound-mode "type"))
      ;; Typing while recording does not move the insertion point.
      (insert "!")
      (goto-char 4)
      (pi-sound-dictate)
      (should (eq pi-sound-state 'transcribing))
      (pi-sound-test--until (lambda () (eq pi-sound-state 'idle)))
      (should (equal (buffer-string) "say hello there!"))
      (should (= (point) (+ 4 (length " hello there"))))
      (should (equal (reverse states) '(connecting recording transcribing idle)))
      (should (null pi-sound-device)))))

(ert-deftest pi-sound-send-submits-only-send-buffers ()
  (pi-sound-test--with-fake '("PI_SOUND_MODE=send")
    (let* ((sent nil)
           (pi-sound-send-commands
            `((pi-sound-test-input-mode . ,(lambda () (interactive) (push (buffer-string) sent))))))
      (with-temp-buffer
        (pi-sound-test-input-mode)
        (insert "draft")
        (pi-sound-test--record)
        (should (equal sent '("draft hello there"))))
      (with-temp-buffer
        (pi-sound-test--record)
        (should (equal (buffer-string) "hello there"))
        (should (= (length sent) 1))))))

(ert-deftest pi-sound-cancel-inserts-nothing ()
  (pi-sound-test--with-fake nil
    (with-temp-buffer
      (pi-sound-dictate)
      (pi-sound-test--until (lambda () (eq pi-sound-state 'recording)))
      (pi-sound-cancel)
      (accept-process-output nil 0.2)
      (should (equal (buffer-string) ""))
      (should (eq pi-sound-state 'idle))
      (should (null pi-sound--process)))))

(ert-deftest pi-sound-read-only-goes-to-kill-ring ()
  (pi-sound-test--with-fake nil
    (let ((kill-ring nil))
      (with-temp-buffer
        (pi-sound-dictate)
        (pi-sound-test--until (lambda () (eq pi-sound-state 'recording)))
        (setq buffer-read-only t)
        (pi-sound-dictate)
        (pi-sound-test--until (lambda () (eq pi-sound-state 'idle)))
        (should (equal (buffer-string) ""))
        (should (equal (car kill-ring) "hello there"))))))

(ert-deftest pi-sound-errors-and-crashes-return-to-idle ()
  (dolist (fake '("error" "crash"))
    (pi-sound-test--with-fake (list (concat "PI_SOUND_FAKE=" fake))
      (with-temp-buffer
        (pi-sound-dictate)
        (pi-sound-test--until (lambda () (and (eq pi-sound-state 'idle) (null pi-sound--process))))
        (should (equal (buffer-string) ""))
        (should (equal (reverse states) '(connecting idle))))))
  (let ((pi-sound-program "/nonexistent/pi-sound") (pi-sound-state 'idle))
    (with-temp-buffer
      (should-error (pi-sound-dictate) :type 'user-error)
      (should (eq pi-sound-state 'idle)))))

(ert-deftest pi-sound-toggle-mode-reads-the-cli ()
  (pi-sound-test--with-fake nil
    (pi-sound-toggle-mode)
    (should (equal pi-sound-mode "send"))))

(ert-deftest pi-sound-button-shows-state-and-dispatches-clicks ()
  (pi-sound-test--with-fake nil
    (let ((button (pi-sound-button)))
      (should (string-match-p "🎤" button))
      (should (string-match-p "type or send" (get-text-property 1 'help-echo button)))
      (let ((map (get-text-property 1 'local-map button)))
        (should (eq (keymap-lookup map "<header-line> <mouse-1>") 'pi-sound-button-click))
        (should (eq (keymap-lookup map "<header-line> <mouse-3>") 'pi-sound-button-click))
        (should (eq (keymap-lookup map "<mode-line> <mouse-1>") 'pi-sound-button-click))))
    (setq pi-sound-state 'recording pi-sound-device "test-device" pi-sound-mode "send")
    (let ((button (pi-sound-button)))
      (should (string-match-p "● REC test-device" button))
      (should (eq (get-text-property 1 'face button) 'pi-sound-recording))
      (should (string-match-p "stop dictation.*(send)" (get-text-property 1 'help-echo button))))
    (setq pi-sound-state 'transcribing)
    (should (equal (substring-no-properties (pi-sound-button)) " … "))
    (let (called)
      (cl-letf (((symbol-function 'pi-sound-dictate) (lambda () (push 'dictate called)))
                ((symbol-function 'pi-sound-toggle-mode) (lambda () (push 'mode called))))
        (pi-sound-button-click '(mouse-1 nil))
        (pi-sound-button-click '(mouse-3 nil))
        (should (equal called '(mode dictate)))))))

;;;; Device output

(ert-deftest pi-sound-play-and-notify-run-in-the-background ()
  (let ((log (make-temp-file "pi-sound-log")))
    (unwind-protect
        (pi-sound-test--with-fake (list (concat "PI_SOUND_LOG=" log))
          (let ((before (length (process-list))))
            (pi-sound-deck-notify 'blocked "main needs attention" "~/x" nil)
            (pi-sound-deck-notify 'finished "main finished" nil nil)
            (pi-sound-play "done")
            (pi-sound-test--until (lambda () (<= (length (process-list)) before)))
            (should (equal (sort (split-string (with-temp-buffer (insert-file-contents log) (buffer-string)) "\n" t))
                           (sort (list "play|request|" "notify|main needs attention|~/x|"
                                       "play|done|" "notify|main finished|" "play|done|")))))
          ;; A missing CLI does nothing.
          (let ((pi-sound-program "/nonexistent/pi-sound"))
            (should-not (pi-sound-play 'done))
            (should-not (pi-sound-notify "x"))))
      (delete-file log))))

;;; pi-sound-test.el ends here
