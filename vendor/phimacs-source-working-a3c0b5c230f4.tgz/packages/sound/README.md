# pi-sound

Explicitly configured dictation, speech transcription and notifications. English
16 kHz mono signed 16-bit little-endian PCM; no backend fallback. Installation
does not enable dictation, access a microphone or discover credentials/devices.

## Configuration

Missing `<agentDir>/voice.json` means disabled, type mode. Malformed settings are
an error. Writes are atomic and private (0600; newly created directory 0700).

```json
{
  "backend": "local",
  "options": { "url": "http://127.0.0.1:8090", "model": "whisper-1" },
  "mode": "type",
  "capture": {
    "command": "parecord",
    "args": ["--raw", "--rate=16000", "--channels=1", "--format=s16le"]
  }
}
```

The example capture command is opt-in: supply an executable installed on your
machine or omit capture when the caller supplies audio. No shell interprets argv.
Local options: explicit credential-free HTTP(S) base `url`, optional `model`,
`timeoutMs` and explicitly supplied string `headers`. Options are backend-specific
and strictly validated before capture. No status command prints backend options.

## CLI

- `pi-sound dictate`: use explicitly configured capture.
- `pi-sound dictate --pcm FILE` or `--pcm -`: raw PCM file or standard input.
- `pi-sound mode [type|send|toggle]`: JSON mode, without selecting a backend.
- `pi-sound play done|request` and `notify TITLE [BODY]`: optional injected output;
  silent success when no output sink exists.

Dictation prints JSON lines: `ready` (device, backend, mode), any `partial` previews,
then exactly one `final` (text, optional limited) or `error` (message). Standard
input EOF stops external capture; PCM stdin EOF ends the audio. SIGINT/SIGTERM/
SIGHUP cancel without a terminal line. Dictation exits 0; other command errors
exit 1 and usage errors 2. No audio is stored. Maximum audio is five minutes;
15 seconds without audio fails. Odd partial samples are joined; trailing half
samples are discarded.

## Explicit composition

`createSoundRuntime` accepts a per-runtime `BackendRegistry`, optional
`CaptureSource`, optional `OutputSink`, and optional settings reader. Register an
arbitrary backend ID using `register(id, {validate, open})`. Opening receives
validated options, transcript/error callbacks and an AbortSignal, and must resolve
only when ready. A transcriber accepts `write(Buffer)`, `finish():Promise<string>`
and idempotent `close()`. Cancellation must release opening/streaming resources.

`transcriberFor(setting, registry)` validates synchronously, then returns an async
`OpenTranscriber(events, signal)` resolving `{backend, transcriber}`.
`configuredTranscriber(agentDir, runtime?)` reads settings for every utterance.
Browser callers such as Tau supply PCM directly to that transcriber; they do not
need a microphone/capture driver. `startDictation` coordinates a transcriber and
capture source with limits, cancellation, readiness and exactly-once completion.
There is no ambient registry singleton or private adapter discovery.

Composition entry points: `runCli(args, {runtime, agentDir, signal})` from
`pi-sound/cli`, and `registerDictation(pi, {runtime, agentDir})` from
`pi-sound/extension`. Private/site adapters belong outside this package and are
explicitly imported by their own bootstrap. No private integration is bundled.

## Frontends

The opt-in Pi extension provides /dictate, Alt+V and /dictate-setting. Type mode
pastes at the TUI cursor and refuses RPC type insertion; send mode submits the
transcript, steering a busy agent. Session shutdown cancels the recording.
Backend setting arguments are an ID and optional JSON options object; disabled,
type, send and status are also available.

`emacs/pi-sound.el` uses the configurable `pi-sound-program`, inserts at the
recording's original marker, supports type/send, cancellation, header buttons and
optional deck notifications. Loading it installs no global keys/hooks. Configure
the CLI/capture/backend first and add desired UI bindings explicitly.

## Development and licenses

From the coordinated workspace: run the package check and compile scripts, focused
`node --test test/<name>.test.ts`, and
`emacs -Q --batch -L emacs -l emacs/pi-sound-test.el -f ert-run-tests-batch-and-exit`.
No test requires real accounts, microphones or paid services.

Software preserves the original MIT grant in LICENSE. Notification sounds derive
from Herdr and retain the separate Apache-2.0 grant and conversion provenance in
`sounds/LICENSE-APACHE-2.0` and `sounds/NOTICE`.
