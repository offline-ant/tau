/** Strict, private settings. Missing configuration disables speech. */
import { randomUUID } from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export const MODES = ['type', 'send'] as const;
export type DictationMode = (typeof MODES)[number];
export interface CaptureCommand { command: string; args: string[] }
export interface VoiceSetting {
  backend: string | null;
  options: Record<string, unknown>;
  mode: DictationMode;
  capture?: CaptureCommand;
}

export function defaultAgentDir(env: NodeJS.ProcessEnv = process.env, home = os.homedir()): string {
  const configured = env.PI_CODING_AGENT_DIR;
  if (!configured) return path.join(home, '.pi', 'agent');
  if (configured === '~') return home;
  return configured.startsWith('~/') ? path.join(home, configured.slice(2)) : configured;
}
export function voiceSettingFile(agentDir: string): string { return path.join(agentDir, 'voice.json'); }

export function objectValue(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function parseVoiceSetting(value: unknown): VoiceSetting {
  if (!objectValue(value) || Object.keys(value).some((key) => !['backend', 'options', 'mode', 'capture'].includes(key))) {
    throw new Error('Expected backend, options, mode and optional capture command.');
  }
  if (value.backend !== undefined && value.backend !== null &&
      (typeof value.backend !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(value.backend) || value.backend === 'disabled')) {
    throw new Error('backend must be a nonempty backend ID or null (disabled).');
  }
  if (value.options !== undefined && !objectValue(value.options)) throw new Error('options must be an object.');
  if (value.mode !== undefined && !MODES.includes(value.mode as DictationMode)) throw new Error('mode must be type or send.');
  const setting: VoiceSetting = {
    backend: (value.backend as string | null | undefined) ?? null,
    options: (value.options as Record<string, unknown> | undefined) ?? {},
    mode: (value.mode as DictationMode | undefined) ?? 'type',
  };
  if (value.capture !== undefined) {
    const capture = value.capture;
    if (!objectValue(capture) || Object.keys(capture).some((key) => key !== 'command' && key !== 'args') ||
        typeof capture.command !== 'string' || !capture.command || !Array.isArray(capture.args) ||
        capture.args.some((arg: unknown) => typeof arg !== 'string')) {
      throw new Error('capture must contain an explicit command and string args array.');
    }
    setting.capture = { command: capture.command, args: capture.args as string[] };
  }
  // Settings are JSON data; reject unsupported values instead of dropping them on write.
  const encoded = JSON.stringify(setting, (_key, item: unknown) => {
    if (item === undefined || typeof item === 'function' || typeof item === 'symbol' || typeof item === 'bigint' ||
        (typeof item === 'number' && !Number.isFinite(item))) throw new Error('Settings must contain finite JSON values.');
    return item;
  });
  if (!encoded) throw new Error('Invalid voice configuration.');
  return setting;
}

export function readVoiceSetting(agentDir: string): VoiceSetting {
  const file = voiceSettingFile(agentDir);
  let contents: string;
  try { contents = fs.readFileSync(file, 'utf8'); }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return { backend: null, options: {}, mode: 'type' };
    throw new Error(`Cannot read voice configuration ${file}.`);
  }
  let value: unknown;
  try { value = JSON.parse(contents); }
  catch { throw new Error(`Invalid voice configuration ${file}: malformed JSON.`); }
  try { return parseVoiceSetting(value); }
  catch (error) { throw new Error(`Invalid voice configuration ${file}: ${error instanceof Error ? error.message : String(error)}`); }
}

export function writeVoiceSetting(agentDir: string, value: VoiceSetting): void {
  const setting = parseVoiceSetting(value);
  const file = voiceSettingFile(agentDir);
  fs.mkdirSync(agentDir, { recursive: true, mode: 0o700 });
  const temporary = `${file}.${randomUUID()}.tmp`;
  try {
    fs.writeFileSync(temporary, `${JSON.stringify(setting)}\n`, { mode: 0o600, flag: 'wx' });
    fs.renameSync(temporary, file);
  } finally { fs.rmSync(temporary, { force: true }); }
}

export function setBackend(agentDir: string, backend: string | null, options: Record<string, unknown> = {},
  readSetting: (dir: string) => VoiceSetting = readVoiceSetting): VoiceSetting {
  let previous: VoiceSetting | undefined;
  try { previous = readSetting(agentDir); } catch {}
  const setting = parseVoiceSetting({ ...previous, backend, options, mode: previous?.mode ?? 'type' });
  writeVoiceSetting(agentDir, setting);
  return setting;
}

export function setMode(agentDir: string, mode: DictationMode | 'toggle',
  readSetting: (dir: string) => VoiceSetting = readVoiceSetting): VoiceSetting {
  const previous = readSetting(agentDir);
  const next = mode === 'toggle' ? (previous.mode === 'type' ? 'send' : 'type') : mode;
  const setting = { ...previous, mode: next };
  writeVoiceSetting(agentDir, setting);
  return setting;
}
