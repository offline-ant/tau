/** Composable JSON-lines CLI; importing this module never starts recording. */
import type { Readable, Writable } from 'node:stream';
import { commandCapture, fileCapture, streamCapture, type CaptureSource } from './capture.ts';
import { startDictation } from './dictation.ts';
import { SOUNDS, notifyDevice, playSound, type SoundName } from './output.ts';
import { createSoundRuntime, transcriberFor, type SoundRuntime } from './runtime.ts';
import { MODES, defaultAgentDir, setMode, type DictationMode } from './settings.ts';

export interface CliOptions {
  runtime?: SoundRuntime;
  agentDir?: string;
  stdin?: Readable;
  stdout?: Writable;
  stderr?: Writable;
  signal?: AbortSignal;
}
const USAGE = 'Usage: pi-sound dictate [--pcm FILE|-] | mode [type|send|toggle] | play done|request | notify TITLE [BODY]';

export async function runCli(args: string[], options: CliOptions = {}): Promise<number> {
  const runtime = options.runtime ?? createSoundRuntime();
  const agentDir = options.agentDir ?? defaultAgentDir();
  const stdin = options.stdin ?? process.stdin;
  const stdout = options.stdout ?? process.stdout;
  const stderr = options.stderr ?? process.stderr;
  const print = (value: object) => { stdout.write(`${JSON.stringify(value)}\n`); };
  const [command, argument, ...extra] = args;
  if (command === 'dictate' && (argument === undefined || (argument === '--pcm' && extra.length === 1))) {
    let stop: (() => void) | undefined;
    const onEnd = () => stop?.();
    try {
      const setting = runtime.readSetting(agentDir);
      // Resolve and validate before creating a capture stream or starting a command.
      const open = transcriberFor(setting, runtime.backends);
      let capture: CaptureSource | undefined = runtime.capture;
      const pcm = argument === '--pcm' ? extra[0] : undefined;
      if (pcm !== undefined) capture = pcm === '-' ? streamCapture(stdin, 'standard input') : fileCapture(pcm);
      else if (!capture && setting.capture) capture = commandCapture(setting.capture);
      if (!capture) throw new Error('No capture source configured. Supply --pcm FILE|- or an explicit capture command.');
      const dictation = startDictation({ capture, open, signal: options.signal,
        emit: (message) => print(message.type === 'ready' ? { ...message, mode: setting.mode } : message) });
      stop = () => dictation.stop();
      if (pcm === undefined) {
        stdin.on('end', onEnd);
        stdin.on('error', onEnd);
        stdin.resume();
        if (stdin.readableEnded) stop();
      }
      await dictation.done;
    } catch (error) {
      if (!options.signal?.aborted) print({ type: 'error', message: error instanceof Error ? error.message : String(error) });
    } finally {
      stdin.off('end', onEnd);
      stdin.off('error', onEnd);
      if (argument === undefined) stdin.pause();
    }
    return 0;
  }
  try {
    if (command === 'mode' && extra.length === 0) {
      if (argument !== undefined && argument !== 'toggle' && !MODES.includes(argument as DictationMode)) throw new Error(USAGE);
      const setting = argument === undefined ? runtime.readSetting(agentDir) : setMode(agentDir, argument as DictationMode | 'toggle', runtime.readSetting);
      print({ mode: setting.mode });
    } else if (command === 'play' && SOUNDS.includes(argument as SoundName) && extra.length === 0) {
      await playSound(runtime.output, argument as SoundName);
    } else if (command === 'notify' && argument !== undefined && extra.length <= 1) {
      await notifyDevice(runtime.output, argument, extra[0]);
    } else {
      stderr.write(`${USAGE}\n`);
      return 2;
    }
    return 0;
  } catch (error) {
    stderr.write(`pi-sound: ${error instanceof Error ? error.message : String(error)}\n`);
    return 1;
  }
}
