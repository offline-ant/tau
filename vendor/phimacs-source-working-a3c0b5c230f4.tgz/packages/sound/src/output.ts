import fs from 'node:fs';

export const SPEAKER_SAMPLE_RATE = 44_100;
export const SOUNDS = ['done', 'request'] as const;
export type SoundName = (typeof SOUNDS)[number];

export interface OutputSink {
  /** 44.1 kHz mono s16le samples; return a destination label or null. */
  play(pcm: Buffer): Promise<string | null>;
  notify(title: string, body: string): Promise<string | null>;
}

/** Validate chunk bounds and format before exposing bundled PCM. */
export function wavSamples(wav: Buffer): Buffer {
  if (wav.length < 12 || wav.toString('ascii', 0, 4) !== 'RIFF' || wav.toString('ascii', 8, 12) !== 'WAVE') {
    throw new Error('Not a WAV file.');
  }
  let validFormat = false;
  for (let offset = 12; offset + 8 <= wav.length;) {
    const id = wav.toString('ascii', offset, offset + 4);
    const size = wav.readUInt32LE(offset + 4);
    const body = offset + 8;
    if (body + size > wav.length) throw new Error('Truncated WAV chunk.');
    if (id === 'fmt ') {
      if (size < 16) throw new Error('Truncated WAV format.');
      validFormat = wav.readUInt16LE(body) === 1 && wav.readUInt16LE(body + 2) === 1 &&
        wav.readUInt32LE(body + 4) === SPEAKER_SAMPLE_RATE && wav.readUInt16LE(body + 14) === 16;
    } else if (id === 'data') {
      if (!validFormat || size % 2) throw new Error('WAV must be 44100 Hz mono 16-bit PCM.');
      return wav.subarray(body, body + size);
    }
    offset = body + size + (size % 2);
  }
  throw new Error('WAV file has no data chunk.');
}
export function soundFile(name: SoundName): URL {
  if (!SOUNDS.includes(name)) throw new Error('Unknown notification sound.');
  return new URL(`../sounds/${name}.wav`, import.meta.url);
}
export async function playSound(sink: OutputSink | undefined, name: SoundName): Promise<string | null> {
  const file = soundFile(name);
  if (!sink) return null;
  return sink.play(wavSamples(fs.readFileSync(file)));
}
export async function notifyDevice(sink: OutputSink | undefined, title: string, body = ''): Promise<string | null> {
  return sink ? sink.notify(title.replace(/[\r\n]+/g, ' ').trim(), body) : null;
}
