import { SAMPLE_RATE, type Transcriber } from './backends.ts';
import type { Capture, CaptureSource } from './capture.ts';
import type { OpenTranscriber } from './runtime.ts';

export const MAX_RECORDING_SECONDS = 300;
export const IDLE_MS = 15_000;
export type DictationMessage =
  | { type: 'ready'; device: string; backend: string }
  | { type: 'partial'; text: string }
  | { type: 'final'; text: string; limited?: true }
  | { type: 'error'; message: string };
export interface Dictation {
  stop(): void;
  cancel(): void;
  readonly done: Promise<void>;
}
export interface DictationOptions {
  capture: CaptureSource;
  open: OpenTranscriber;
  emit(message: DictationMessage): void;
  maxSeconds?: number;
  idleMs?: number;
  signal?: AbortSignal;
}

/** One utterance, exactly one terminal message unless cancelled. */
export function startDictation(options: DictationOptions): Dictation {
  const maxSeconds = options.maxSeconds ?? MAX_RECORDING_SECONDS;
  const idleMs = options.idleMs ?? IDLE_MS;
  if (!Number.isFinite(maxSeconds) || maxSeconds <= 0 || maxSeconds > MAX_RECORDING_SECONDS ||
      !Number.isFinite(idleMs) || idleMs <= 0) throw new Error('Invalid dictation limits.');
  const maxBytes = Math.floor(maxSeconds * SAMPLE_RATE) * 2;
  const backendAbort = new AbortController();
  const captureAbort = new AbortController();
  let capture: Capture | undefined;
  let transcriber: Transcriber | undefined;
  let received = 0;
  let odd: Buffer | undefined;
  let done = false;
  let finishing = false;
  let stopRequested = false;
  let ready = false;
  let pendingPartial: string | undefined;
  let idle: NodeJS.Timeout | undefined;
  let settle!: () => void;
  const settled = new Promise<void>((resolve) => { settle = resolve; });

  function releaseCapture() {
    clearTimeout(idle);
    captureAbort.abort();
    capture?.close();
  }
  function end(message: DictationMessage | null) {
    if (done) return;
    done = true;
    releaseCapture();
    backendAbort.abort();
    transcriber?.close();
    options.signal?.removeEventListener('abort', cancel);
    try { if (message) options.emit(message); } finally { settle(); }
  }
  function cancel() { end(null); }
  function fail(error: unknown) {
    end({ type: 'error', message: error instanceof Error ? error.message : String(error) });
  }
  function finish(limited: boolean) {
    if (done || finishing || !transcriber || !capture) return;
    finishing = true;
    releaseCapture();
    if (!received) return fail(new Error('The configured capture source produced no audio.'));
    Promise.resolve().then(() => transcriber!.finish()).then(
      (text) => end({ type: 'final', text, ...(limited ? { limited: true as const } : {}) }), fail);
  }
  function resetIdle() {
    clearTimeout(idle);
    idle = setTimeout(() => fail(new Error('No audio from the configured capture source; recording stopped.')), idleMs);
  }
  async function run() {
    backendAbort.signal.throwIfAborted();
    const opened = await options.open({
      partial: (text) => {
        if (done || finishing) return;
        if (ready) options.emit({ type: 'partial', text });
        else pendingPartial = text;
      },
      error: (message) => fail(new Error(message)),
    }, backendAbort.signal);
    transcriber = opened.transcriber;
    if (done) { transcriber.close(); return; }
    // Await backend readiness before capture is opened or ready is reported.
    capture = await options.capture.open(captureAbort.signal);
    if (done) { capture.close(); return; }
    options.emit({ type: 'ready', device: capture.device, backend: opened.backend });
    ready = true;
    if (pendingPartial !== undefined && !done) options.emit({ type: 'partial', text: pendingPartial });
    if (done) return;
    capture.stream.on('error', fail);
    capture.stream.on('end', () => finish(false));
    capture.stream.on('close', () => { if (!done && !finishing) finish(false); });
    capture.stream.on('data', (data: Buffer | string) => {
      if (done || finishing || !transcriber) return;
      const bytes = typeof data === 'string' ? Buffer.from(data) : data;
      let chunk = odd ? Buffer.concat([odd, bytes]) : bytes;
      odd = undefined;
      if (chunk.length % 2) { odd = chunk.subarray(-1); chunk = chunk.subarray(0, -1); }
      chunk = chunk.subarray(0, maxBytes - received);
      received += chunk.length;
      try { if (chunk.length) transcriber.write(Buffer.from(chunk)); } catch (error) { fail(error); return; }
      if (received >= maxBytes) finish(true);
      else resetIdle();
    });
    if (stopRequested) finish(false);
    else resetIdle();
  }
  // A microtask boundary prevents synchronous callbacks from preceding caller setup.
  Promise.resolve().then(run).catch(fail);
  options.signal?.addEventListener('abort', cancel, { once: true });
  if (options.signal?.aborted) cancel();
  return { stop() { stopRequested = true; finish(false); }, cancel, done: settled };
}
