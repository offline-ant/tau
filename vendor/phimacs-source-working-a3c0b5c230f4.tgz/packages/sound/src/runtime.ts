import { BackendRegistry, type TranscriberEvents, type Transcriber } from './backends.ts';
import type { CaptureSource } from './capture.ts';
import { localBackend } from './local.ts';
import type { OutputSink } from './output.ts';
import { readVoiceSetting, type VoiceSetting } from './settings.ts';

export type OpenTranscriber = (events: TranscriberEvents, signal: AbortSignal) =>
  Promise<{ backend: string; transcriber: Transcriber }>;

export interface SoundRuntime {
  readonly backends: BackendRegistry;
  readonly capture?: CaptureSource;
  readonly output?: OutputSink;
  readSetting(agentDir: string): VoiceSetting;
}
export function createPublicBackends(): BackendRegistry { return new BackendRegistry().register('local', localBackend); }
export function createSoundRuntime(options: Partial<SoundRuntime> = {}): SoundRuntime {
  return { backends: options.backends ?? createPublicBackends(), capture: options.capture, output: options.output,
    readSetting: options.readSetting ?? readVoiceSetting };
}
/** Validation runs before capture/network resources are acquired. */
export function transcriberFor(setting: VoiceSetting, backends: BackendRegistry): OpenTranscriber {
  const prepared = backends.prepare(setting.backend, setting.options);
  return async (events, signal) => ({ backend: prepared.backend, transcriber: await prepared.open(events, signal) });
}
/** Re-read settings for every utterance; callers own their registry explicitly. */
export function configuredTranscriber(agentDir: string, runtime: SoundRuntime = createSoundRuntime()): OpenTranscriber {
  return async (events, signal) => transcriberFor(runtime.readSetting(agentDir), runtime.backends)(events, signal);
}
