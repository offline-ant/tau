import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { PassThrough, Readable, Writable } from 'node:stream';
import { setImmediate } from 'node:timers/promises';
import { test } from 'node:test';
import {
  BackendRegistry, createSoundRuntime, configuredTranscriber, parseVoiceSetting, readVoiceSetting,
  setMode, startDictation, streamCapture, transcriberFor, writeVoiceSetting,
  type DictationMessage, type SoundRuntime, type Transcriber,
} from '../src/index.ts';
import { runCli } from '../src/cli.ts';

function temporary() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sound-core-'));
  return { dir, close: () => fs.rmSync(dir, { recursive: true, force: true }) };
}
function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((done) => { resolve = done; });
  return { promise, resolve };
}
function recorder() {
  const chunks: Buffer[] = [];
  let closed = 0;
  const transcriber: Transcriber = {
    write: (chunk) => { chunks.push(Buffer.from(chunk)); },
    finish: async () => 'hello world',
    close: () => { closed++; },
  };
  return { transcriber, chunks, get closed() { return closed; } };
}
function output() {
  let text = '';
  const stream = new Writable({ write(chunk, _encoding, callback) { text += String(chunk); callback(); } });
  return { stream, get text() { return text; } };
}

// Missing/unregistered backends fail before any capture, network or credential discovery.
test('missing settings disable recording and never touch any other file or capture', async (t) => {
  const temp = temporary(); t.after(temp.close);
  const reads: string[] = [];
  const original = fs.readFileSync;
  t.mock.method(fs, 'readFileSync', (...args: Parameters<typeof fs.readFileSync>) => {
    reads.push(String(args[0]));
    return Reflect.apply(original, fs, args);
  });
  let captures = 0;
  const runtime = createSoundRuntime({ capture: { open() { captures++; throw new Error('must not capture'); } } });
  assert.deepEqual(runtime.readSetting(temp.dir), { backend: null, options: {}, mode: 'type' });
  await assert.rejects(configuredTranscriber(temp.dir, runtime)({ partial() {}, error() {} }, new AbortController().signal), /disabled/);
  const stdout = output();
  assert.equal(await runCli(['dictate'], { runtime, agentDir: temp.dir, stdin: new PassThrough(), stdout: stdout.stream }), 0);
  assert.equal(captures, 0);
  assert.ok(reads.every((file) => file === path.join(temp.dir, 'voice.json')));
  assert.equal(JSON.parse(stdout.text).type, 'error');
});

test('private atomic settings, arbitrary IDs, validation and mode do not enable backend', (t) => {
  const temp = temporary(); t.after(temp.close);
  const dir = path.join(temp.dir, 'new');
  assert.equal(setMode(dir, 'toggle').backend, null);
  assert.equal(fs.statSync(dir).mode & 0o777, 0o700);
  assert.equal(fs.statSync(path.join(dir, 'voice.json')).mode & 0o777, 0o600);
  writeVoiceSetting(dir, { backend: 'plugin.custom-1', options: { project: 'synthetic' }, mode: 'send' });
  assert.equal(readVoiceSetting(dir).backend, 'plugin.custom-1');
  for (const value of [[], { backend: '' }, { extra: true }, { mode: 'bad' }, { options: [] }, { options: { bad: NaN } }, { capture: { command: 'x', args: [1] } }]) {
    assert.throws(() => parseVoiceSetting(value));
  }
  fs.writeFileSync(path.join(dir, 'voice.json'), '{bad');
  assert.throws(() => setMode(dir, 'type'), /Invalid voice configuration/);
  assert.equal(fs.readFileSync(path.join(dir, 'voice.json'), 'utf8'), '{bad');
});

test('registry instances are independent and plugin options validate before opening', async () => {
  let opened = 0;
  const backend = new BackendRegistry().register('custom', {
    validate(value) { assert.deepEqual(value, { accepted: true }); return { accepted: true }; },
    open() { opened++; return recorder().transcriber; },
  });
  assert.throws(() => transcriberFor({ backend: 'custom', options: {}, mode: 'type' }, backend));
  assert.throws(() => new BackendRegistry().prepare('custom'), /not registered/);
  assert.equal(opened, 0);
  const open = transcriberFor({ backend: 'custom', options: { accepted: true }, mode: 'type' }, backend);
  const result = await open({ partial() {}, error() {} }, new AbortController().signal);
  assert.equal(result.backend, 'custom');
  assert.equal(opened, 1);
  result.transcriber.close();
});

test('await backend readiness before capture; retain odd samples; one terminal result', async () => {
  const ready = deferred<Transcriber>();
  const announced = deferred<void>();
  const stream = new PassThrough();
  const recorded = recorder();
  let captureOpened = false;
  const messages: DictationMessage[] = [];
  const dictation = startDictation({
    open: async () => ({ backend: 'synthetic', transcriber: await ready.promise }),
    capture: { open(signal) { captureOpened = true; return streamCapture(stream, 'synthetic').open(signal); } },
    emit(message) { messages.push(message); if (message.type === 'ready') announced.resolve(); },
  });
  await setImmediate();
  assert.equal(captureOpened, false);
  ready.resolve(recorded.transcriber);
  await announced.promise;
  stream.write(Buffer.from([1]));
  stream.write(Buffer.from([2, 3]));
  stream.end(Buffer.from([4, 5]));
  await dictation.done;
  dictation.stop(); dictation.cancel();
  assert.deepEqual(Buffer.concat(recorded.chunks), Buffer.from([1, 2, 3, 4]));
  assert.deepEqual(messages.map((message) => message.type), ['ready', 'final']);
  assert.equal(recorded.closed, 1);
});

test('cancel while opening settles immediately and closes a late backend without capture', async () => {
  const opened = deferred<Transcriber>();
  const recorded = recorder();
  let captures = 0;
  const messages: DictationMessage[] = [];
  const dictation = startDictation({
    open: async () => ({ backend: 'fake', transcriber: await opened.promise }),
    capture: { open() { captures++; throw new Error('must not capture'); } },
    emit: (message) => messages.push(message),
  });
  await setImmediate();
  dictation.cancel();
  await dictation.done;
  opened.resolve(recorded.transcriber);
  await setImmediate();
  assert.equal(recorded.closed, 1);
  assert.equal(captures, 0);
  assert.deepEqual(messages, []);
});

test('audio limit clips exactly and marks final; idle and empty input are errors', async () => {
  for (const kind of ['limit', 'idle', 'empty'] as const) {
    const stream = new PassThrough();
    const recorded = recorder();
    const ready = deferred<void>();
    const messages: DictationMessage[] = [];
    const dictation = startDictation({
      open: async () => ({ backend: 'fake', transcriber: recorded.transcriber }),
      capture: streamCapture(stream), maxSeconds: 1 / 16_000, idleMs: 10,
      emit(message) { messages.push(message); if (message.type === 'ready') ready.resolve(); },
    });
    await ready.promise;
    if (kind === 'limit') stream.write(Buffer.from([1, 2, 3, 4]));
    else if (kind === 'empty') stream.end();
    await dictation.done;
    const terminal = messages.at(-1);
    if (kind === 'limit') {
      assert.deepEqual(terminal, { type: 'final', text: 'hello world', limited: true });
      assert.deepEqual(Buffer.concat(recorded.chunks), Buffer.from([1, 2]));
    } else assert.equal(terminal?.type, 'error');
    assert.equal(messages.filter((message) => message.type === 'final' || message.type === 'error').length, 1);
  }
});

test('backend synchronous error and thrown PCM write settle once', async () => {
  for (const kind of ['open', 'write'] as const) {
    const messages: DictationMessage[] = [];
    const stream = new PassThrough();
    const dictation = startDictation({
      open: async (events) => {
        if (kind === 'open') events.error('synthetic backend failure');
        return { backend: 'fake', transcriber: { write() { throw new Error('synthetic write failure'); }, finish: async () => '', close() {} } };
      },
      capture: streamCapture(stream),
      emit(message) { messages.push(message); if (message.type === 'ready') stream.end(Buffer.from([1, 2])); },
    });
    await dictation.done;
    assert.equal(messages.filter((message) => message.type === 'error').length, 1);
  }
});

test('CLI mode updates use the composed reader and canonical private writer', async (t) => {
  const temp = temporary(); t.after(temp.close);
  const runtime: SoundRuntime = createSoundRuntime({ readSetting: () => ({ backend: 'custom', options: { x: true }, mode: 'type' }) });
  const stdout = output();
  assert.equal(await runCli(['mode', 'toggle'], { runtime, agentDir: temp.dir, stdout: stdout.stream }), 0);
  assert.equal(readVoiceSetting(temp.dir).backend, 'custom');
  assert.equal(readVoiceSetting(temp.dir).mode, 'send');
  assert.deepEqual(JSON.parse(stdout.text), { mode: 'send' });
});

test('CLI explicit PCM source transcribes without a capture driver and preserves exit protocol', async (t) => {
  const temp = temporary(); t.after(temp.close);
  const recorded = recorder();
  const runtime = createSoundRuntime({
    backends: new BackendRegistry().register('fake', { validate: () => ({}), open: () => recorded.transcriber }),
    readSetting: () => ({ backend: 'fake', options: {}, mode: 'send' }),
  });
  const stdout = output(); const stderr = output();
  assert.equal(await runCli(['dictate', '--pcm', '-'], { runtime, agentDir: temp.dir,
    stdin: Readable.from([Buffer.from([1, 2])]), stdout: stdout.stream, stderr: stderr.stream }), 0);
  assert.deepEqual(stdout.text.trim().split('\n').map((line) => JSON.parse(line).type), ['ready', 'final']);
  assert.equal(JSON.parse(stdout.text.split('\n')[0]).mode, 'send');
  assert.equal(await runCli(['bad'], { stderr: stderr.stream }), 2);
  assert.equal(await runCli(['mode', 'bad'], { stderr: stderr.stream }), 1);
  assert.equal(stderr.text.includes('Usage:'), true);
});

test('early partials wait for ready and pre-cancelled input opens nothing', async () => {
  const stream = new PassThrough();
  const messages: DictationMessage[] = [];
  const transcriber = recorder().transcriber;
  const dictation = startDictation({
    open: async (events) => { events.partial('early preview'); return { backend: 'fake', transcriber }; },
    capture: streamCapture(stream),
    emit(message) {
      messages.push(message);
      if (message.type === 'ready') stream.end(Buffer.from([1, 2]));
    },
  });
  await dictation.done;
  assert.deepEqual(messages.map((message) => message.type), ['ready', 'partial', 'final']);
  const controller = new AbortController();
  controller.abort();
  let opened = 0;
  const cancelled = startDictation({ signal: controller.signal,
    open: async () => { opened++; return { backend: 'fake', transcriber }; },
    capture: streamCapture(new PassThrough()), emit() { assert.fail('Cancelled recording must be silent.'); } });
  await cancelled.done;
  await setImmediate();
  assert.equal(opened, 0);
});

test('malformed settings never echo backend option values', (t) => {
  const temp = temporary(); t.after(temp.close);
  fs.writeFileSync(path.join(temp.dir, 'voice.json'), '{"options":{"key":"synthetic-hidden"} bad');
  assert.throws(() => readVoiceSetting(temp.dir), (error: unknown) => error instanceof Error &&
    error.message.includes('malformed JSON') && !error.message.includes('synthetic-hidden'));
});
