/** Explicit launch/control CLI. RPC frontends connect directly to the returned socket. */
import { startRuntime, stopRuntime, listRuntimes, lookupRuntime, lookupTerminalReceipt, RuntimeOperationError, type ParentTask } from "./runtime.ts";
import { runManagedTui } from "./managed-tui.ts";
export { intendedSessionFile, servesRpc } from "./host.ts";

function option(args: string[], key: string): string | undefined {
  const at = args.indexOf(key);
  return at < 0 ? undefined : args[at + 1];
}

export async function main(args: string[]): Promise<void> {
  const action = args[0];
  const json = (value: unknown): void => { process.stdout.write(`${JSON.stringify(value)}\n`); };
  const controller = new AbortController();
  const cancelled = (): void => controller.abort();
  try {
    if (action === "start" || action === "tui") {
      const separator = args.indexOf("--");
      const command = separator < 0 ? undefined : args[separator + 1];
      if (!command) throw new Error(`Usage: pimux ${action} ${action === "start" ? "--json " : ""}-- <absolute Pi executable> [arguments]`);
      const piArgs = args.slice(separator + 2);
      if (action === "tui") {
        const exit = await runManagedTui({ command, args: piArgs });
        process.exitCode = exit.code ?? (exit.signal ? 128 + (exit.signal === "SIGINT" ? 2 : 15) : 1);
      } else {
        for (const signal of ["SIGTERM", "SIGINT", "SIGHUP"] as const) process.once(signal, cancelled);
        const parent: ParentTask | undefined = process.env.PHIMACS_PARENT_TASK
          ? JSON.parse(process.env.PHIMACS_PARENT_TASK) as ParentTask : undefined;
        json(await startRuntime({ command, args: piArgs, signal: controller.signal, ...parent ? { parent } : {} }));
      }
    } else if (action === "list") json(listRuntimes());
    else if (action === "lookup") {
      const file = option(args, "--session");
      if (!file) throw new Error("Usage: pimux lookup --json --session <absolute path>");
      const claim = lookupRuntime(file);
      // Claim tokens are internal capabilities, not public discovery fields.
      json(claim ? { file: claim.file, owner: claim.owner } : null);
    } else if (action === "receipt") {
      const muxId = option(args, "--id");
      if (!muxId || muxId.startsWith("--")) throw new Error("Usage: pimux receipt --json --id <muxId>");
      json(lookupTerminalReceipt(muxId));
    } else if (action === "stop") {
      const muxId = option(args, "--id");
      if (!muxId) throw new Error("Usage: pimux stop --json --id <muxId>");
      json(await stopRuntime(muxId));
    } else throw new Error("Usage: pimux {start|list|lookup|receipt|stop} --json; pimux tui -- <absolute Pi executable> [arguments]");
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const operation = error instanceof RuntimeOperationError ? ` Operation ${error.operationId}, runtime ${error.muxId}; reconcile before retrying.` : "";
    process.stderr.write(`pimux: ${message}${operation}\n`);
    process.exitCode = 1;
  } finally {
    for (const signal of ["SIGTERM", "SIGINT", "SIGHUP"] as const) process.off(signal, cancelled);
  }
}
