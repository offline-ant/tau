import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";
import test from "node:test";
import { exactSessionArgs, servesRpc, verifyHost } from "./host.ts";
import { parseArgs } from "@earendil-works/pi-coding-agent";
import { createClaimTestEnvironment } from "./ownership.ts";

test("managed exec accepts the actual Node entry, never a shell/shebang wrapper", (t) => {
  const isolated = createClaimTestEnvironment();
  t.after(() => fs.rmSync(isolated.root, { recursive: true, force: true }));
  fs.writeFileSync(path.join(isolated.root, "package.json"), JSON.stringify({ name: "@earendil-works/pi-coding-agent", version: "1.4.0" }));
  const command = path.join(isolated.root, "pi");
  fs.writeFileSync(command, "#!/bin/sh\nexit 0\n", { mode: 0o700 });
  assert.throws(() => verifyHost(command), /supported Node entry point/);
  fs.writeFileSync(command, "#!/usr/bin/env node\n// synthetic audited Node entry\n", { mode: 0o700 });
  assert.equal(verifyHost(command).executable, command);
});

test("literal flag-like option values are parsed by Pi, not mistaken for session/export/mode switches", (t) => {
  const isolated = createClaimTestEnvironment();
  t.after(() => fs.rmSync(isolated.root, { recursive: true, force: true }));
  const file = path.join(isolated.sessions, "b.jsonl");
  fs.writeFileSync(file, "synthetic");
  const selected = exactSessionArgs(["--session", file, "--system-prompt", "--export", "A"], isolated.root, isolated.env, true);
  const parsed = parseArgs(selected.args);
  assert.equal(selected.file, file);
  assert.equal(parsed.session, file);
  assert.equal(parsed.export, undefined);
  assert.equal(parsed.systemPrompt, "--export");
  assert.deepEqual(parsed.messages, ["A"]);
  assert.equal(servesRpc(["--system-prompt", "--mode", "rpc"]), false);
  assert.equal(servesRpc(["--mode=rpc"]), false, "Pi does not parse this spelling as its mode option");
});

test("one canonical resolution is used for both the claim and actual Pi argument despite alias retarget", (t) => {
  const isolated = createClaimTestEnvironment();
  t.after(() => fs.rmSync(isolated.root, { recursive: true, force: true }));
  const a = path.join(isolated.sessions, "a.jsonl");
  const b = path.join(isolated.sessions, "b.jsonl");
  const alias = path.join(isolated.sessions, "alias.jsonl");
  fs.writeFileSync(a, "a"); fs.writeFileSync(b, "b"); fs.symlinkSync(a, alias);
  const original = fs.realpathSync.native;
  let retargeted = false;
  fs.realpathSync.native = ((file: fs.PathLike) => {
    const result = original(file);
    if (file === alias && !retargeted) { retargeted = true; fs.unlinkSync(alias); fs.symlinkSync(b, alias); }
    return result;
  }) as typeof original;
  try {
    const selected = exactSessionArgs(["--mode", "rpc", "--session", alias], isolated.root, isolated.env);
    assert.equal(selected.file, a);
    assert.equal(selected.args.at(-1), a);
    assert.equal(retargeted, true);
  } finally { fs.realpathSync.native = original; }
});
