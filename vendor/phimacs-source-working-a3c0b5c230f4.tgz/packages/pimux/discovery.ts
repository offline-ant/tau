/**
 * Discovery files: one `<id>.json` and `<id>.sock` per live wrapper in a
 * private per-user directory. JSON files are replaced atomically. An entry is
 * reclaimed only when neither its wrapper nor its Pi is alive, and for a socket
 * only after a refused connection while its identity did not change.
 */
import * as fs from "node:fs";
import * as net from "node:net";
import * as path from "node:path";
import { redactEndpoint } from "./endpoint.ts";
import { isRecord, type Placement } from "./protocol.ts";
import { processExists, type ProcessIdentity } from "./process-identity.ts";
import type { HostIdentity } from "./host.ts";
import type { Blocked, MuxStatus } from "./state.ts";

export interface OrchestrationRef { host: string; endpoint: string; id: string; name?: string }

export interface DiscoveryRecord {
  protocol: number;
  muxId: string;
  socket: string;
  pid: number;
  /** Null until Pi is spawned. */
  piPid: number | null;
  ownerIdentity?: ProcessIdentity;
  piIdentity?: ProcessIdentity | null;
  operationId?: string;
  phase?: "provisional" | "committed";
  host?: HostIdentity;
  cwd: string;
  startedAt: string;
  updatedAt: string;
  status: MuxStatus;
  blocked: Blocked | null;
  /** While starting, only the file `--session` names is known. */
  session: { file: string | null; id: string | null; name: string | null } | null;
  model: { provider: string; id: string } | null;
  thinkingLevel: string | null;
  placement: Placement;
  orchestration: OrchestrationRef | null;
  parent: OrchestrationRef | null;
}

/** `PIMUX_DIR`, else `/tmp/pi-mux-<uid>`: fixed so frontends with different TMPDIRs agree. */
export function muxDirectory(env: NodeJS.ProcessEnv = process.env): string {
  return env.PIMUX_DIR || `/tmp/pi-mux-${process.getuid?.() ?? "user"}`;
}

/** Creates the directory 0700, or verifies an existing one is a private directory of this user. */
export function ensurePrivateDirectory(dir: string): void {
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const stat = fs.lstatSync(dir);
  const uid = process.getuid?.();
  if (!stat.isDirectory() || (uid !== undefined && stat.uid !== uid) || (stat.mode & 0o077) !== 0) {
    throw new Error(`pimux: ${dir} must be a directory owned by this user with mode 0700`);
  }
}

export function writeDiscovery(file: string, record: DiscoveryRecord): void {
  const temporary = path.join(path.dirname(file), `.${path.basename(file)}.${process.pid}.tmp`);
  fs.writeFileSync(temporary, `${JSON.stringify(record, null, 2)}\n`, { mode: 0o600 });
  fs.renameSync(temporary, file);
}

export function readDiscovery(file: string): DiscoveryRecord | undefined {
  try {
    const stat = fs.lstatSync(file);
    if (!stat.isFile() || stat.uid !== process.getuid?.() || (stat.mode & 0o077) !== 0) return undefined;
    const parsed: unknown = JSON.parse(fs.readFileSync(file, "utf8"));
    // Unsupported live owners remain visible: absence must not trigger a new writer.
    return isRecord(parsed) && Number.isSafeInteger(parsed.protocol) && typeof parsed.muxId === "string"
      && typeof parsed.socket === "string" && Number.isSafeInteger(parsed.pid)
      ? parsed as unknown as DiscoveryRecord : undefined;
  } catch {
    return undefined;
  }
}

export function listDiscovery(dir: string): DiscoveryRecord[] {
  let names: string[];
  try { names = fs.readdirSync(dir); } catch { return []; }
  return names.filter((name) => name.endsWith(".json") && !name.startsWith("."))
    .map((name) => readDiscovery(path.join(dir, name))).filter((record): record is DiscoveryRecord => record !== undefined);
}

function identity(file: string): string | undefined {
  try {
    const stat = fs.lstatSync(file);
    return `${stat.dev}:${stat.ino}:${stat.ctimeMs}`;
  } catch {
    return undefined;
  }
}

function refused(socket: string): Promise<boolean> {
  return new Promise((resolve) => {
    const connection = net.connect(socket);
    connection.once("connect", () => { connection.destroy(); resolve(false); });
    connection.once("error", (error: NodeJS.ErrnoException) => resolve(error.code === "ECONNREFUSED"));
  });
}

/** Unknown metadata is not evidence that a writer died. */
function ownerAlive(record: DiscoveryRecord | undefined): boolean {
  if (!record) return true;
  return processExists(record.ownerIdentity ?? record.pid)
    || (record.piIdentity ? processExists(record.piIdentity) : record.piPid !== null && processExists(record.piPid));
}

/** Removes entries of wrappers that died without cleaning up; returns the removed ids. */
export async function reclaimStale(dir: string): Promise<string[]> {
  let names: string[];
  try { names = fs.readdirSync(dir); } catch { return []; }
  const removed: string[] = [];
  for (const name of names) {
    if (name.endsWith(".sock")) {
      const socket = path.join(dir, name);
      const before = identity(socket);
      if (!before || !await refused(socket) || identity(socket) !== before) continue;
      const id = name.slice(0, -5);
      const metadata = path.join(dir, `${id}.json`);
      const beforeMetadata = identity(metadata);
      if (ownerAlive(readDiscovery(metadata)) || identity(socket) !== before || identity(metadata) !== beforeMetadata) continue;
      fs.rmSync(socket, { force: true });
      fs.rmSync(path.join(dir, `${id}.json`), { force: true });
      removed.push(id);
    } else if (name.endsWith(".json") && !name.startsWith(".")) {
      // A wrapper killed before listening leaves only its JSON file.
      const id = name.slice(0, -5);
      if (fs.existsSync(path.join(dir, `${id}.sock`))) continue;
      const metadata = path.join(dir, name);
      const beforeMetadata = identity(metadata);
      if (ownerAlive(readDiscovery(metadata)) || identity(metadata) !== beforeMetadata) continue;
      fs.rmSync(metadata, { force: true });
      removed.push(id);
    }
  }
  return removed;
}

/** This process's orchestration identity, and the parent identity a host gave a child it started. */
export function orchestrationIdentity(env: NodeJS.ProcessEnv): { orchestration: OrchestrationRef | null; parent: OrchestrationRef | null } {
  const { PI_ORCHESTRATION_HOST: host, PI_ORCHESTRATION_ENDPOINT: endpoint, PI_ORCHESTRATION_TARGET: target } = env;
  let parent: OrchestrationRef | null = null;
  try {
    const parsed: unknown = env.PI_ORCHESTRATION_PARENT ? JSON.parse(env.PI_ORCHESTRATION_PARENT) : undefined;
    if (isRecord(parsed) && typeof parsed.host === "string" && typeof parsed.endpoint === "string" && typeof parsed.id === "string") {
      parent = { host: parsed.host, endpoint: redactEndpoint(parsed.endpoint), id: parsed.id,
        ...typeof parsed.name === "string" ? { name: parsed.name } : {} };
    }
  } catch { /* malformed: no parent */ }
  return {
    orchestration: host && endpoint && target ? { host, endpoint: redactEndpoint(endpoint), id: target } : null,
    parent,
  };
}
