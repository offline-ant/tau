import * as fs from "node:fs";
import * as path from "node:path";
import { fauxAssistantMessage, fauxProvider, fauxToolCall, type TranscriptContext } from "@earendil-works/pi-ai";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";

/** pimux integration fixture: inference stays inside Pi's faux providers. */
export default function pimuxFixture(pi: ExtensionAPI): void {
  const lastUserText = (context: TranscriptContext): string => {
    const message = context.messages.findLast((item) => item.role === "user");
    if (!message) return "";
    return typeof message.content === "string" ? message.content
      : message.content.flatMap((item) => item.type === "text" ? [item.text] : []).join("\n");
  };
  const respond = async (context: TranscriptContext) => {
    const last = context.messages.at(-1);
    if (last?.role === "toolResult") return fauxAssistantMessage(`tool done: ${last.toolName}`);
    const text = lastUserText(context);
    // "stream N": N words, slowly enough to join mid-stream on the slow provider.
    const stream = /^stream (\d+)/.exec(text);
    if (stream) return fauxAssistantMessage(Array.from({ length: Number(stream[1]) }, (_, index) => `word${index}`).join(" "));
    // "tool": a bash tool that prints until stopped, with a silent background child (its PID
    // is recorded) that a broken output pipe does not stop.
    if (text === "tool") {
      const command = `sleep 300 & echo $! > ${JSON.stringify(path.join(process.cwd(), "tool.pid"))}; while :; do echo tick; sleep 0.05; done`;
      return fauxAssistantMessage([fauxToolCall("bash", { command })], { stopReason: "toolUse" });
    }
    return fauxAssistantMessage(`reply: ${text}`);
  };
  for (const [name, tokensPerSecond] of [["pimux-fx", 1_000_000], ["pimux-fx-slow", 150]] as const) {
    const provider = fauxProvider({ provider: name, models: [{ id: "one", reasoning: true }, { id: "two", reasoning: true }], tokensPerSecond });
    provider.setResponses(Array.from({ length: 200 }, () => respond));
    pi.registerProvider(provider.provider);
  }
  pi.on("before_agent_start", (_event, ctx) => {
    if (!ctx.model?.provider.startsWith("pimux-fx")) throw new Error("pimux fixture refuses non-faux providers");
  });
  pi.registerCommand("fx-select", {
    description: "Ask a select dialog; args: timeout in ms",
    handler: async (args, ctx) => {
      const timeout = Number(args.trim()) || undefined;
      const choice = await ctx.ui.select("Pick", ["a", "b"], { timeout });
      ctx.ui.notify(`picked:${choice ?? "none"}`, "info");
    },
  });
  pi.registerCommand("fx-abandon", {
    description: "Ask a dialog that the extension abandons after 200 ms",
    handler: async (_args, ctx) => {
      const controller = new AbortController();
      setTimeout(() => controller.abort(), 200);
      const confirmed = await ctx.ui.confirm("Abandoned", "?", { signal: controller.signal });
      ctx.ui.notify(`abandoned:${confirmed}`, "info");
    },
  });
  pi.registerCommand("fx-wait", {
    description: "Act as a worker waiting for the user",
    handler: async (_args, ctx) => { ctx.ui.setStatus("worker-frame", "worker:waiting"); },
  });
  pi.registerCommand("fx-new", {
    description: "Start a new session from an extension command",
    handler: async (_args, ctx) => {
      const result = await ctx.newSession();
      fs.writeFileSync(path.join(process.cwd(), "fx-new.json"), JSON.stringify(result));
    },
  });
  pi.registerCommand("fx-tree", {
    description: "Navigate to the first entry of the session tree",
    handler: async (_args, ctx) => {
      const first = ctx.sessionManager.getEntries().find((entry) => entry.type === "message");
      if (first) await ctx.navigateTree(first.id);
    },
  });
}
