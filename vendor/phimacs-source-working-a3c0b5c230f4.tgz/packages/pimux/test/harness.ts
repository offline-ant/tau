import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import * as fs from "node:fs";
import * as net from "node:net";
import * as path from "node:path";
import { setTimeout as delay } from "node:timers/promises";
import { fileURLToPath } from "node:url";
import type { TestContext } from "node:test";
import { type DiscoveryRecord, readDiscovery } from "../discovery.ts";
import { LineSplitter } from "../jsonl.ts";
import { createClaimTestEnvironment, type ClaimTestEnvironment } from "../ownership.ts";
import { processIdentityStatus, readProcessIdentity, type ProcessIdentity } from "../process-identity.ts";
import { startRuntime, stopRuntime, type ParentTask, type RuntimeReceipt } from "../runtime.ts";
import { isReadOnlyCommand, parseInputContext, type JsonRecord } from "../protocol.ts";

export const BIN = fileURLToPath(new URL("../bin/pimux", import.meta.url));
export const PI = fs.realpathSync.native(fileURLToPath(new URL("../../../node_modules/.bin/pi", import.meta.url)));
const FIXTURE = fileURLToPath(new URL("./fixture.ts", import.meta.url));

export async function until<T>(check: () => T | undefined | false, description: string, timeoutMs = 15_000): Promise<T> {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const value = check();
    if (value) return value;
    assert.ok(Date.now() < deadline, `Timed out: ${description}`);
    await delay(20);
  }
}

export function alive(pid: number): boolean {
  try { return readProcessIdentity(pid) !== undefined; } catch { return true; }
}

export class Peer {
  records: JsonRecord[] = [];
  private nextId = 0;
  private readonly write: (line: string) => void;
  constructor(write: (line: string) => void) { this.write = write; }
  readonly splitter = new LineSplitter((line) => this.records.push(JSON.parse(line) as JsonRecord), 128 * 1024 * 1024, () => {});
  send(record: JsonRecord): void {
    // Test actions capture the last authoritative branch anchor. Tests of raw
    // malformed/pre-boundary input write directly to their owned socket.
    const snapshot = this.records.findLast((received) => received.type === "pimux_snapshot");
    const context = parseInputContext(snapshot?.inputContext);
    const command = typeof record.type === "string" && !record.type.startsWith("pimux_")
      && !isReadOnlyCommand(record.type) && !("pimuxContext" in record) && context
      ? { ...record, pimuxContext: context } : record;
    this.write(`${JSON.stringify(command)}\n`);
  }
  mark(): number { return this.records.length; }
  waitFor(match: (record: JsonRecord) => boolean, description: string, after = 0, timeoutMs?: number): Promise<JsonRecord> {
    return until(() => this.records.slice(after).find(match), description, timeoutMs);
  }
  after(index: number, match: (record: JsonRecord) => boolean): JsonRecord[] { return this.records.slice(index).filter(match); }
  async request(record: JsonRecord): Promise<JsonRecord> {
    const id = `req-${++this.nextId}`;
    this.send({ ...record, id });
    const response = await this.waitFor((received) => received.type === "response" && received.id === id, `response to ${String(record.type)}`);
    if (response.success === true && (["new_session", "switch_session", "fork", "clone", "navigate_tree"].includes(String(record.type))
      || (record.type === "prompt" && typeof record.message === "string" && record.message.trimStart().startsWith("/")))) {
      const responseIndex = this.records.indexOf(response);
      const snapshot = await this.waitFor((received) => received.type === "pimux_snapshot" && received.reason === "request", "post-action context boundary", responseIndex + 1);
      await this.waitFor((received) => received.type === "pimux_live" && received.generation === snapshot.generation, "post-action live boundary", responseIndex + 1);
    }
    return response;
  }
  async run(message: string): Promise<void> {
    const start = this.mark();
    const response = await this.request({ type: "prompt", message });
    assert.equal(response.success, true, String(response.error));
    await this.waitFor((record) => record.type === "agent_settled", `settle after ${message}`, start);
  }
}
export type SocketPeer = Peer & { socket: net.Socket };
export async function connectPeer(receipt: RuntimeReceipt): Promise<SocketPeer> {
  const socket = net.connect(receipt.socket);
  const peer = Object.assign(new Peer((line) => socket.write(line)), { socket });
  socket.on("error", () => {});
  socket.on("data", (chunk: Buffer) => peer.splitter.push(chunk));
  await peer.waitFor((record) => record.type === "pimux_live", "socket snapshot/live boundary", 0, 30_000);
  const hello = peer.records[0]!;
  assert.equal(hello.protocol, 2);
  assert.equal(hello.muxId, receipt.muxId);
  assert.equal("role" in hello, false);
  return peer;
}

export interface Prepared {
  dir: string; sessionFile: string; env: NodeJS.ProcessEnv; piArgs: string[]; isolation: ClaimTestEnvironment;
}
export function prepare(entries = 0): Prepared {
  const isolation = createClaimTestEnvironment();
  const dir = isolation.root;
  const agentDir = path.join(dir, "agent");
  const home = path.join(dir, "home");
  const temporary = path.join(dir, "tmp");
  for (const folder of [agentDir, home, temporary]) fs.mkdirSync(folder, { mode: 0o700 });
  fs.writeFileSync(path.join(agentDir, "settings.json"), JSON.stringify({
    defaultProvider: "pimux-fx", defaultModel: "one", compaction: { enabled: false }, retry: { enabled: false },
  }), { mode: 0o600 });
  const sessionFile = path.join(isolation.sessions, "session.jsonl");
  const header = { type: "session", version: 3, id: randomUUID(), timestamp: new Date().toISOString(), cwd: dir };
  fs.writeFileSync(sessionFile, [header, ...linearEntries(entries)].map((record) => `${JSON.stringify(record)}\n`).join(""), { mode: 0o600 });
  const env: NodeJS.ProcessEnv = { ...process.env, ...isolation.env, HOME: home, TMPDIR: temporary,
    PI_CODING_AGENT_DIR: agentDir, PI_CODING_AGENT_SESSION_DIR: isolation.sessions, PI_NESTED: "" };
  for (const key of Object.keys(env)) if (key.startsWith("PI_ORCHESTRATION_") || key.startsWith("PHIMACS_PARENT_") || key === "PI_REMOTE" || key === "PHIMACS_MANAGED_CLAIM") delete env[key];
  return { dir, sessionFile, env, isolation, piArgs: ["--mode", "rpc", "--session", sessionFile,
    "--no-extensions", "--no-skills", "--no-prompt-templates", "--no-context-files", "--provider", "pimux-fx", "--model", "one", "-e", FIXTURE] };
}
function linearEntries(count: number): JsonRecord[] {
  const timestamp = new Date().toISOString();
  return Array.from({ length: count }, (_, index) => {
    const message = index % 2 === 0
      ? { role: "user", content: [{ type: "text", text: `question ${index}` }], timestamp: 1 }
      : { role: "assistant", content: [{ type: "text", text: `answer ${index}` }], api: "pimux-fx", provider: "pimux-fx", model: "one",
        usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } }, stopReason: "stop", timestamp: 1 };
    return { type: "message", id: `e${index}`, parentId: index ? `e${index - 1}` : null, timestamp, message };
  });
}

export interface MuxRun extends Prepared {
  first: SocketPeer; receipt: RuntimeReceipt; ownerIdentity: ProcessIdentity; piIdentity: ProcessIdentity;
  discovery(): DiscoveryRecord | undefined; connect(): Promise<SocketPeer>; stop(): Promise<void>;
}
export async function startMux(t: TestContext, options: { env?: Record<string, string>; entries?: number; parent?: ParentTask } = {}): Promise<MuxRun> {
  const prepared = prepare(options.entries);
  const env = { ...prepared.env, ...options.env };
  const parent = options.parent ?? (env.PI_ORCHESTRATION_PLACEMENT === "worker" ? { process: readProcessIdentity(process.pid)!, taskId: randomUUID() } : undefined);
  let receipt: RuntimeReceipt;
  try { receipt = await startRuntime({ command: PI, args: prepared.piArgs, cwd: prepared.dir, env, ...parent ? { parent } : {} }); }
  catch (error) {
    const logs = path.join(prepared.dir, "mux", "logs");
    const diagnostics = fs.existsSync(logs) ? fs.readdirSync(logs).map((name) => fs.readFileSync(path.join(logs, name), "utf8")).join("\n") : "";
    throw new Error(`${error instanceof Error ? error.message : String(error)}\n${diagnostics}`);
  }
  const ownerIdentity = readProcessIdentity(receipt.pid)!;
  const piIdentity = readProcessIdentity(receipt.piPid)!;
  const sockets = new Set<net.Socket>();
  const connect = async (): Promise<SocketPeer> => { const peer = await connectPeer(receipt); sockets.add(peer.socket); return peer; };
  const stop = async (): Promise<void> => {
    for (const socket of sockets) socket.destroy();
    if (processIdentityStatus(ownerIdentity) === "alive") await stopRuntime(receipt.muxId, { env });
    await until(() => processIdentityStatus(ownerIdentity) === "dead" && processIdentityStatus(piIdentity) === "dead", "owned runtime and Pi exited", 15_000);
  };
  t.after(async () => { await stop(); fs.rmSync(prepared.dir, { recursive: true, force: true }); });
  const first = await connect();
  return { ...prepared, env, first, receipt, ownerIdentity, piIdentity, connect, stop,
    discovery: () => readDiscovery(path.join(env.PIMUX_DIR!, `${receipt.muxId}.json`)) };
}
