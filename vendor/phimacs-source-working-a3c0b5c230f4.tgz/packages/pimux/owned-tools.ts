/** Remember identity-proven descendant process groups before a Pi crash reparents them. */
import * as fs from "node:fs";
import { processIdentityStatus, readProcessIdentity, type ProcessIdentity } from "./process-identity.ts";

function processGroup(pid: number): { parent: number; group: number } | undefined {
  try {
    const text = fs.readFileSync(`/proc/${pid}/stat`, "utf8");
    const fields = text.slice(text.lastIndexOf(")") + 2).trim().split(/\s+/);
    return { parent: Number(fields[1]), group: Number(fields[2]) };
  } catch { return undefined; }
}

export class OwnedToolGroups {
  private readonly groups = new Map<number, Map<number, ProcessIdentity>>();
  capture(piPid: number): void {
    for (const [group, members] of this.groups) {
      for (const [pid, identity] of members) if (processIdentityStatus(identity) === "dead") members.delete(pid);
      if (members.size === 0) this.groups.delete(group);
    }
    const descendants = new Set([piPid]);
    const processes = fs.readdirSync("/proc").filter((name) => /^\d+$/.test(name)).map((name) => {
      const pid = Number(name); return { pid, stat: processGroup(pid) };
    });
    let changed = true;
    while (changed) {
      changed = false;
      for (const { pid, stat } of processes) if (stat && descendants.has(stat.parent) && !descendants.has(pid)) { descendants.add(pid); changed = true; }
    }
    for (const { pid, stat } of processes) {
      if (!stat || pid === piPid || !descendants.has(pid) || stat.group === processGroup(process.pid)?.group) continue;
      let identity: ProcessIdentity | undefined;
      try { identity = readProcessIdentity(pid); } catch { continue; }
      if (!identity) continue;
      const members = this.groups.get(stat.group) ?? new Map<number, ProcessIdentity>();
      members.set(pid, identity); this.groups.set(stat.group, members);
    }
  }
  /** A live exact member must still belong to that group; PID-only evidence never authorizes a signal. */
  stop(): void {
    for (const [group, members] of this.groups) {
      if (![...members.values()].some((member) => processIdentityStatus(member) === "alive" && processGroup(member.pid)?.group === group)) continue;
      try { process.kill(-group, "SIGKILL"); } catch { /* group already exited */ }
    }
    this.groups.clear();
  }
}
