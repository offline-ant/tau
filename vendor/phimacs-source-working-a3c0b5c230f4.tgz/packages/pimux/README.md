# pimux: detached Pi runtimes and equal frontends

One detached pimux owns one Pi RPC process. Pilish and Tau connect directly to its
private Unix socket; neither frontend has special lifetime authority. There is no
central daemon, primary promotion, idle auto-stop or automatic restart.

Linux, Node 24 and the pinned Pi host are required. Compile with the workspace's
`npm run compile`; the executable and every Node-loaded module are JavaScript and
work below `node_modules`. The companion/guard are explicitly loaded extensions,
never auto-discovered package extensions.

## Launch and control

```sh
pimux start --json -- /absolute/release/node_modules/.bin/pi --mode rpc --session /absolute/session.jsonl
pimux list --json
pimux lookup --json --session /absolute/session.jsonl
pimux receipt --json --id <muxId>
pimux stop --json --id <muxId>
pimux tui -- /absolute/release/node_modules/.bin/pi --session /absolute/session.jsonl
```

`start` returns exactly one JSON object on stdout:

```json
{"protocol":2,"operationId":"opaque","muxId":"opaque","socket":"/private/runtime.sock","pid":1234,"piPid":1235,"sessionFile":"/private/session.jsonl","state":"committed","outcome":"started"}
```

The outcome is `started` or `attached`. An existing compatible RPC owner is
attached; a native TUI or unsupported owner refuses. No duplicate writer fallback.
Absent `--session`, the launcher allocates an exact unique pathname before spawn.
Resolve session IDs/continue/resume/fork selectors read-only in the frontend first;
managed startup rejects unresolved selectors, `--no-session` and initial prompts.
Submit intentional input only after the socket's complete snapshot/live boundary.

The host must be an absolute real Pi executable belonging to the exact supported
coding-agent package (currently 1.4.0). `PHIMACS_PI_VERSION` and
`PHIMACS_PI_SHA256`, or the typed `expectedHost` option, enforce release metadata.
The owner rechecks the entry-point hash before spawn. Whole-release dependency
integrity is the installer/manifest's responsibility, not a checksum of one entry.
The unrelated global Pi is neither invoked nor changed. Managed argument selection
uses the matched host peer's public `parseArgs` API, not a second guessed flag
parser. Pure ownership/process-identity modules have no SDK dependency.

`tui` is a separate managed native launch, not an RPC bridge. It inherits the
terminal, holds the same writer claims and loads the transition guard. Its lifetime
remains terminal/host-owned; it is not an attachable shared root. Raw Pi remains
outside the cooperative guarantee.

## Typed APIs

Declared exports:

- `@phimacs/pimux/runtime`: `startRuntime({command,args,cwd?,env?,signal?,timeoutMs?,
  expectedHost?,parent?})`, `listRuntimes(env?)`, `lookupRuntime(file,env?)`,
  `lookupTerminalReceipt(muxId,env?)`, `stopRuntime(muxId,{env?,operationId?,timeoutMs?})`,
  `verifyRuntimeConnection(receipt,timeoutMs?,signal?,expectedSessionFile?)` and
  `validateSocket(path)`.
- `@phimacs/pimux/ownership`: `acquireClaim`, `lookupClaim`, `updateClaim`,
  `reconcileClaim`, `releaseClaim`, `claimsForOwner`, `canonicalSessionPath`,
  `createClaimTestEnvironment` and the claim types/errors.
- `@phimacs/pimux/process-identity`: exact Linux PID/start-time/boot identity,
  `readProcessIdentity`, `processIdentityStatus`, `processExists` and equality.
- `@phimacs/pimux/managed-tui`: `runManagedTui({command,args,cwd?,env?,expectedHost?})`.
- `@phimacs/pimux/guard`: explicit Pi transition extension and
  `installManagedSessionGuard` and `reserveManagedSession(file)`;
  `MANAGED_CLAIM_ENV` names its private capability. Reservation is available only
  to the exact managed Pi, before an extension initializes a new file; the guard
  retains it until writer exit, including failed/cancelled switches. It does not
  transfer/release a source claim or authorize another Pi.
- Discovery, protocol, mux, client, state, JSONL, host and endpoint exports own their
  corresponding reusable contracts; no orchestration-host dependency exists.

`RuntimeReceipt` has the fields shown above. `RuntimeOperationError` carries
`operationId` and `muxId` for uncertainty recovery. `TerminalReceipt` has
`{protocol:2,muxId,operationId,state:"stopped",code,signal,stoppedAt}`. The terminal
receipt identifies the runtime, not a new agent subsequently using the same file.

`receipt --json --id` and `lookupTerminalReceipt` read only retained terminal
evidence: a validated `TerminalReceipt`, or JSON/typed `null` when none is retained.
They never connect, start/stop Pi, create runtime directories or mutate claims.
Malformed identities, records and unsafe/symlink evidence fail explicitly. Missing
or expired evidence is unknown, not proof of closure; frontends must not retire a
saved view merely because this lookup returns `null`.

An RPC worker must supply `parent:{process:{pid,startTime,bootId},taskId}`. The CLI
reads the same structure from `PHIMACS_PARENT_TASK`. Worker placement without a
live exact parent and task ID refuses. Parent death stops its subordinate runtime;
view disconnect does not. The orchestration result protocol still owns task
cancellation, result publication and intentional resume; pimux never promotes an
orphan worker or fabricates its result.

## Startup, cancellation and lifetime

The launcher claims the exact file before Pi can open it. It spawns a detached
owner with private IPC and no frontend stdio. That same capability transfers to
the owner atomically, then records Pi's exact process identity. Before commitment,
launcher cancellation/loss stops only this provisional owner/Pi and waits for
exit. A timeout or uncertain exit retains operation evidence and claims; callers
reconcile instead of blindly retrying.

Readiness requires the mandatory guard and a successful companion snapshot without
inference. A listening socket or `get_state` is insufficient. After readiness the
launcher commits ownership, receives its receipt, disconnects and exits. A lost
acknowledgement is resolved from the private operation file. A post-commit frontend
failure leaves the runtime available for reconnect/explicit stop.

With zero clients Pi output is drained and snapshots/replay state still update.
Already accepted work and provider waits continue and may incur usage. Closing
Emacs, Tau or the last view never sends EOF to Pi. Reconnection sends no paid
prompt, `continue`, tool command or inferred retry. A missing runtime becomes an
unavailable/stopped view requiring explicit recovery.

Explicit stop is identity-bound and acknowledged after actual Pi exit. Its private
receipt is written before final socket output, so a lost reply can be reconciled.
Repeated stop of that identity returns the same receipt. Graceful termination is
followed by identity-checked forced termination only for the owned Pi; uncertainty
keeps the claim and refuses replacement. No client signals a raw Pi PID.

Pi death ends its mux. Mux death is detected by the companion using exact parent
identity plus pipe closure; Pi terminates and cleans its child groups. The owner
also remembers identity-proven tool groups for cleanup after a Pi crash. A tool
spawned immediately before an unobservable Pi `SIGKILL` can escape that observation;
this is a process-lifecycle limitation, not a claimed kernel-level containment
guarantee. Neither Pi nor its mux restarts automatically after crash/reboot.

## Cooperative writer claims

Production claims live under fixed `/tmp/phimacs-session-claims-<uid>`, independent
of `TMPDIR`, agent directories, release versions and `PIMUX_DIR`. Private 0700
nonsymlink directories, 0600 files, a cross-process bakery transaction mutex and
atomic publication serialize intended canonical path and existing inode indexes.
Hardlinks, symlinks, absent destinations and subsequent inode materialization share
ownership. Retargeted paths refuse; obsolete capabilities cannot release a new
owner. Atomic owner updates have no release/reacquire gap.

A live **or uncertain** wrapper or Pi retains ownership. Linux start time and boot
identity distinguish reused PIDs; zombies are exited writers. Stale recovery checks
unchanged records while serialized and requires both recorded processes definitely
dead. A refused socket, timeout, missing discovery or sent signal is not exit proof.

Existing-file transitions acquire in awaited `session_before_switch` and return
`{cancel:true}` on refusal. Throwing a hook is not cancellation. New/fork paths
claim at `session_start`; startup failures terminate this owned Pi and fail wrapper
readiness. Old and provisional claims stay until exit because Pi 1.4 does not
settle every cancelled/failed/flush transition authoritatively. This deliberately
prefers refusal over reopening a possibly still-writable file. An old retained
reservation is not an attachable conversation: attachment validates the snapshot's
current session file and refuses to redirect an old-file request to a new session.

**Boundary:** Pi 1.4 can repair/migrate during open; native selectors, direct SDK
mutators and runtime fork allocation have unguarded pre-I/O writes. Post-open
claims cannot prevent those operations, nor raw external Pi/editors. The stronger
universal storage gate remains blocked on an owning upstream storage API; no Pi
fork or hidden monkeypatch is included. All Phimacs launch/transfer callers must
use the exported launch/claim facilities. Wiring every orchestration path is a
separate integration gate, not implied by this package's tests.

Tests use `createClaimTestEnvironment()` and `PHIMACS_TEST_ROOT` only inside a
marked, user-private `/tmp/phimacs-test-*` tree. They cannot authorize files outside
its `sessions/` subtree, including escaping symlinks or external hardlinks. The
helper returns `{root,sessions,claims,options,env}` without changing process env.
Never point synthetic claims at production conversations.

## Socket protocol 2

All transports are same-user private Unix sockets. Clients verify socket/directory
ownership and permissions, `pimux_hello.protocol === 2`, mux identity and the complete
snapshot/live boundary. Protocol 1 lifetime semantics are not translated. There is
no role field, privileged creator or stdio transport. Maximum 32 connected peers;
client lines are limited to 64 MiB, Pi records to 128 MiB.

The first record is:

```json
{"type":"pimux_hello","protocol":2,"muxId":"opaque","clientId":1,"piPid":1235,"socket":"/private/runtime.sock","capabilities":["snapshot","stop","detached"]}
```

Pi JSONL records otherwise retain their RPC meaning. Framing splits LF only,
strips an optional CR and never treats U+2028/U+2029 as record boundaries.

### Snapshots, generations and replay

Each peer automatically receives `pimux_snapshot`, N replay records, then
`pimux_live` of the same generation. `pimux_bootstrap` requests a new authoritative
boundary and optionally narrows `include` to a nonempty subset of `entries` and
`messages`. Its correlated response reports the requested generation. Tau requests
bootstrap when selecting a view as well as reconnecting.

A snapshot contains `generation`, `reason`, `session:{file,id,name,cwd}`, `model`,
`thinkingLevel`, `idle`, `leafId`, selected `entries`/`messages`,
`run:{active,compacting,tailTruncated}`, optional `historyError`, and replay count.
Entries are flat append-order entries across all branches, not a nested tree.
Follow parent IDs iteratively. Messages reflect exactly Pi's active projection at
the boundary. Completed messages never overlap replayed in-flight streams.

Replay order: latest title, per-key status/widget, authoritative queue, live run/
message/tool/compaction/retry/bash tail, then open dialogs. The tail is bounded at
32 MiB; overflow drops an entire stream's replay and marks `tailTruncated`, never
an arbitrary middle. Final live records remain authoritative. UI caches each have
bounded counts/bytes. Notifications, editor overwrite, responses and ended turns
are not replayed as new work.

Generations increase globally. A newer snapshot/gap/session/tree boundary abandons
an unfinished older sequence; discard the old partial reconstruction. Waiting
clients receive their own responses and exit, not incremental records that would
mix with the pending snapshot. Every snapshot's identity is authoritative even if
a separate change record was lost. Failed ordinary snapshots send
`pimux_snapshot_failed`; change snapshots can fall back to identity plus
`historyError` so stale history is never presented as the new session.

Other records retain their names: `pimux_session_changed`, `pimux_tree_changed`,
`pimux_model_changed`, `pimux_bash_start/end`, `pimux_gap`,
`pimux_dialog_closed`, and final `pimux_exit {code,signal,stderrTail}`.

### Routing, input and control

Commands get per-client correlated IDs; only their sender gets the response with
its original ID restored. Bash start/output/end are shared with `bashId`; private
response IDs do not leak. Pending requests and snapshots are bounded and purged
on disconnect. Internal snapshot commands never appear in `get_commands`.
External commands/dialog replies are refused until runtime commitment/readiness.

All peers see dialogs; first answer wins, and every peer sees closure. Timeout and
Pi's aggregate prompt-ended indication remain distinct. Pi does not identify one
abandoned dialog among multiple open dialogs, so exact per-dialog abandonment
remains an upstream limitation. Never close a dialog merely because a run starts.

Pi supplies no causal request identity for `set_editor_text`; even one pending
request cannot prove that a delayed callback belongs to it. Every such request
becomes a recoverable labelled `pimux_editor_text` notice, never a draft overwrite. At
most 256 notices/4 MiB survive for later snapshots; truncation is explicit and must
not be presented as complete. Malformed/unroutable Pi output goes to bounded
private diagnostics, never to an elected frontend.

`pimux_stop` requires `expectedMuxId` and nonempty `operationId` (and, if supplied,
protocol 2). Its receipt is authoritative even when shutdown closes the socket
before the correlated reply. Wrong identities/protocols cannot stop another owner.
Abort remains Pi's explicit RPC abort, not frontend disconnect or runtime stop.

Slow peers never pause Pi or other peers. Each queue recovers dropped live output
with a gap and snapshot. Repeated overflow or more than 64 MiB queued disconnects
that peer; responses are not silently discarded. Recovery/reconnect never resends
input whose delivery is uncertain.

## Discovery, private diagnostics and tests

`PIMUX_DIR`, else `/tmp/pi-mux-<uid>`, contains private per-runtime discovery/socket
files and `operations/`, `receipts/`, `logs/`. Discovery includes protocol, mux/Pi
identities, exact host entry identity, provisional/committed phase, session, model,
status, placement and redacted host/parent references. Unsupported owners remain
visible and fail closed. Claims, not discovery scans, enforce writer exclusion.

Diagnostics retain at most 64 KiB per runtime; completed receipts and their linked
operation/log files are retained for the most recent 128 stopped runtimes.
Provisional operation evidence is retained for explicit reconciliation, not erased
on timeout. No private capability token is exposed by the public lookup command.
Release selection never hot-swaps a live owner's modules.

```sh
# From the Phimacs root; all provider calls below are faux and sessions synthetic.
node packages/pimux/scripts/compile.mjs
node --test packages/pimux/ownership.test.ts packages/pimux/mux.test.ts packages/pimux/state.test.ts packages/pimux/discovery.test.ts packages/pimux/companion.test.ts
node --test packages/pimux/pimux.test.ts packages/pimux/runtime.test.ts packages/pimux/lifecycle.test.ts packages/pimux/managed-tui.test.ts packages/pimux/host.test.ts packages/pimux/runtime-files.test.ts packages/pimux/receipt.test.ts
```
