/** Short-lived detached runtime launcher and identity-bound local control. */
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import * as fs from "node:fs";
import * as net from "node:net";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import { setTimeout as delay } from "node:timers/promises";
import { type DiscoveryRecord, listDiscovery, muxDirectory, readDiscovery } from "./discovery.ts";
import { acquireClaim, canonicalSessionPath, ClaimConflictError, lookupClaim, releaseClaim, type ClaimHandle, type ClaimOptions, type ClaimRecord } from "./ownership.ts";
import { readProcessIdentity, processIdentityStatus, sameProcessIdentity, type ProcessIdentity } from "./process-identity.ts";
import { exactSessionArgs, verifyHost, servesRpc, type HostIdentity } from "./host.ts";
import { LineSplitter } from "./jsonl.ts";
import { isRecord, PROTOCOL_VERSION } from "./protocol.ts";
import { readPrivateJson, runtimePaths, writePrivateJson } from "./runtime-files.ts";

export interface RuntimeReceipt {
  protocol: 2;
  operationId: string;
  muxId: string;
  socket: string;
  pid: number;
  piPid: number;
  sessionFile: string;
  state: "committed";
  outcome: "started" | "attached";
}
export interface TerminalReceipt {
  protocol: 2;
  muxId: string;
  operationId: string;
  state: "stopped";
  code: number | null;
  signal: string | null;
  stoppedAt: string;
}
export interface ParentTask { process: ProcessIdentity; taskId: string }
export interface StartRuntimeOptions {
  command: string;
  args: string[];
  cwd?: string;
  env?: NodeJS.ProcessEnv;
  signal?: AbortSignal;
  timeoutMs?: number;
  expectedHost?: { version?: string; sha256?: string };
  parent?: ParentTask;
}
export interface RuntimeInitialization {
  type: "initialize";
  operationId: string;
  muxId: string;
  claim: ClaimHandle;
  command: string;
  args: string[];
  cwd: string;
  host: HostIdentity;
  parent?: ParentTask;
}
export interface OperationRecord {
  protocol: 2;
  operationId: string;
  muxId: string;
  state: "provisional" | "ready" | "committed" | "failed";
  receipt?: RuntimeReceipt;
  error?: string;
}
export class RuntimeOperationError extends Error {
  readonly operationId: string;
  readonly muxId: string;
  constructor(message: string, operationId: string, muxId: string) { super(message); this.operationId = operationId; this.muxId = muxId; }
}

function optionsFor(env: NodeJS.ProcessEnv): ClaimOptions { return env.PHIMACS_TEST_ROOT ? { testRoot: env.PHIMACS_TEST_ROOT } : {}; }

export function validateSocket(socket: string): void {
  const stat = fs.lstatSync(socket);
  if (!stat.isSocket() || stat.uid !== process.getuid?.() || (stat.mode & 0o077) !== 0) throw new Error("Runtime socket must be same-user and private");
  const parent = fs.lstatSync(path.dirname(socket));
  if (!parent.isDirectory() || parent.uid !== process.getuid?.() || (parent.mode & 0o077) !== 0) throw new Error("Runtime socket directory is unsafe");
}

/** Exposes no claims from an unrelated namespace; foreign/unsupported live owners are refusals. */
export function lookupRuntime(file: string, env = process.env): ClaimRecord | undefined { return lookupClaim(file, optionsFor(env)); }
export function listRuntimes(env = process.env): DiscoveryRecord[] { return listDiscovery(muxDirectory(env)); }

/** Read retained terminal evidence only; absence never establishes runtime death. */
export function lookupTerminalReceipt(muxId: string, env = process.env): TerminalReceipt | null {
  if (typeof muxId !== "string" || !/^[a-zA-Z0-9-]+$/.test(muxId)) throw new Error("Invalid runtime identity");
  const directory = muxDirectory(env);
  const receipts = path.join(directory, "receipts");
  for (const dir of [directory, receipts]) {
    let stat: fs.Stats;
    try { stat = fs.lstatSync(dir); }
    catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return null; throw error; }
    if (!stat.isDirectory() || stat.uid !== process.getuid?.() || (stat.mode & 0o077) !== 0) {
      throw new Error("Terminal receipt directory has unsafe ownership/permissions");
    }
  }
  const receipt = readPrivateJson<unknown>(path.join(receipts, `${muxId}.json`));
  if (receipt === undefined) return null;
  if (!isRecord(receipt) || receipt.protocol !== PROTOCOL_VERSION || receipt.muxId !== muxId
    || receipt.state !== "stopped" || typeof receipt.operationId !== "string" || !/^[a-zA-Z0-9-]+$/.test(receipt.operationId)
    || !(receipt.code === null || (typeof receipt.code === "number" && Number.isSafeInteger(receipt.code) && receipt.code >= 0))
    || !(receipt.signal === null || (typeof receipt.signal === "string" && receipt.signal.length > 0))
    || typeof receipt.stoppedAt !== "string" || !Number.isFinite(Date.parse(receipt.stoppedAt))) {
    throw new Error("Invalid retained terminal receipt");
  }
  return { protocol: PROTOCOL_VERSION, muxId, operationId: receipt.operationId, state: "stopped",
    code: receipt.code, signal: receipt.signal, stoppedAt: receipt.stoppedAt };
}

function verifyAttachmentHost(file: string, owner: ClaimRecord["owner"], host: HostIdentity): void {
  const discovery = readDiscovery(file);
  if (!discovery || discovery.protocol !== PROTOCOL_VERSION || discovery.phase !== "committed"
    || discovery.muxId !== owner.id || discovery.socket !== owner.socket || discovery.operationId !== owner.operationId
    || !discovery.ownerIdentity || !sameProcessIdentity(discovery.ownerIdentity, owner.wrapper)
    || !owner.pi || !discovery.piIdentity || !sameProcessIdentity(discovery.piIdentity, owner.pi)) {
    throw new Error("Existing runtime has no supported exact owner/host identity; attachment refused");
  }
  const advertised = discovery.host;
  if (!isRecord(advertised) || advertised.executable !== host.executable || advertised.version !== host.version || advertised.sha256 !== host.sha256) {
    throw new Error("Existing runtime uses a different or unsupported Pi host/release; attachment refused");
  }
  verifyHost(advertised.executable, host);
}

async function attachExisting(claim: ClaimRecord, host: HostIdentity, env: NodeJS.ProcessEnv, timeoutMs: number, signal?: AbortSignal): Promise<RuntimeReceipt> {
  const owner = claim.owner;
  if (owner.kind !== "rpc" || owner.protocol !== PROTOCOL_VERSION || !owner.socket || !owner.operationId) {
    throw new Error(`Session is owned by a nonattachable ${owner.kind} runtime; no replacement writer was started`);
  }
  const files = runtimePaths(owner.id, owner.operationId, { ...env, PIMUX_DIR: path.dirname(owner.socket) });
  const deadline = performance.now() + timeoutMs;
  while (performance.now() < deadline) {
    signal?.throwIfAborted();
    // The same capability transfers launcher -> detached owner without a gap.
    // Re-read that capability instead of treating the now-exited launcher as
    // the permanent owner during a concurrent attachment.
    const current = lookupClaim(claim.file, optionsFor(env));
    if (!current || current.token !== claim.token || current.owner.id !== owner.id
      || processIdentityStatus(current.owner.wrapper) !== "alive") throw new Error("Runtime owner is dead or uncertain; reconcile ownership before starting again");
    const operation = readPrivateJson<OperationRecord>(files.operation);
    if (operation?.state === "failed") throw new Error(operation.error ?? "Existing runtime startup failed");
    if (operation?.state === "committed" && operation.receipt) {
      verifyAttachmentHost(files.discovery, current.owner, host);
      await verifyRuntimeConnection(operation.receipt, timeoutMs, signal, claim.file);
      verifyAttachmentHost(files.discovery, current.owner, host);
      return { ...operation.receipt, sessionFile: claim.file, outcome: "attached" };
    }
    await delay(20, undefined, { signal });
  }
  throw new RuntimeOperationError("Existing runtime is still provisional; no second writer was started", owner.operationId, owner.id);
}

/** Handshake and full snapshot/live boundary, with no prompt, are the attachment readiness test. */
export function verifyRuntimeConnection(receipt: RuntimeReceipt, timeoutMs = 30_000, signal?: AbortSignal, expectedSessionFile = receipt.sessionFile): Promise<void> {
  validateSocket(receipt.socket);
  return new Promise((resolve, reject) => {
    const socket = net.connect(receipt.socket);
    let hello = false;
    let snapshot: { generation: number; file: string } | undefined;
    const timer = setTimeout(() => finish(new Error("Runtime attachment did not reach pimux_live")), timeoutMs);
    const aborted = (): void => finish(new Error("Runtime attachment cancelled"));
    const finish = (error?: Error): void => {
      clearTimeout(timer); signal?.removeEventListener("abort", aborted); socket.destroy();
      if (error) reject(error); else resolve();
    };
    const lines = new LineSplitter((line) => {
      let record: unknown;
      try { record = JSON.parse(line); } catch { finish(new Error("Invalid runtime handshake")); return; }
      if (!isRecord(record)) return;
      if (record.type === "pimux_hello") {
        if (record.protocol !== PROTOCOL_VERSION || record.muxId !== receipt.muxId || record.piPid !== receipt.piPid) finish(new Error("Runtime identity/protocol mismatch"));
        else hello = true;
      } else if (record.type === "pimux_snapshot" && hello && typeof record.generation === "number" && isRecord(record.session) && typeof record.session.file === "string") {
        snapshot = { generation: record.generation, file: record.session.file };
      } else if (record.type === "pimux_live" && hello && snapshot && record.generation === snapshot.generation) {
        if (canonicalSessionPath(snapshot.file) !== canonicalSessionPath(expectedSessionFile)) {
          finish(new Error("Requested file is retained by a runtime now serving another conversation; no second writer was started"));
        } else finish();
      }
      else if (record.type === "pimux_snapshot_failed" || record.type === "pimux_exit") finish(new Error("Runtime is not snapshot-ready"));
    }, 128 * 1024 * 1024, () => finish(new Error("Runtime handshake exceeds its bound")));
    socket.on("data", (chunk: Buffer) => lines.push(chunk));
    socket.once("error", finish);
    socket.once("end", () => finish(new Error("Runtime disconnected before readiness")));
    signal?.addEventListener("abort", aborted, { once: true });
    if (signal?.aborted) aborted();
  });
}

export async function startRuntime(options: StartRuntimeOptions): Promise<RuntimeReceipt> {
  const env = options.env ?? process.env;
  const cwd = path.resolve(options.cwd ?? process.cwd());
  options.signal?.throwIfAborted();
  const host = verifyHost(options.command, options.expectedHost ?? {
    version: env.PHIMACS_PI_VERSION, sha256: env.PHIMACS_PI_SHA256,
  });
  if (!servesRpc(options.args)) throw new Error("pimux start requires a serving --mode rpc invocation");
  const selected = exactSessionArgs(options.args, cwd, env);
  const muxId = randomUUID();
  const operationId = randomUUID();
  const files = runtimePaths(muxId, operationId, env);
  const launcher = readProcessIdentity(process.pid);
  if (!launcher) throw new Error("Cannot establish launcher identity");
  let claim: ClaimHandle;
  try {
    claim = acquireClaim(selected.file, { id: muxId, kind: "rpc", wrapper: launcher, pi: null, protocol: PROTOCOL_VERSION, socket: files.socket, operationId }, optionsFor(env));
  } catch (error) {
    if (error instanceof ClaimConflictError && error.code === "CLAIM_CONFLICT") return attachExisting(error.claim, host, env, options.timeoutMs ?? 30_000, options.signal);
    throw error;
  }
  writePrivateJson(files.operation, { protocol: PROTOCOL_VERSION, operationId, muxId, state: "provisional" } satisfies OperationRecord);
  const entry = fileURLToPath(new URL("./owner-entry.js", import.meta.resolve("@phimacs/pimux/runtime")));
  let child: ReturnType<typeof spawn>;
  try {
    child = spawn(process.execPath, [entry], { cwd, env, detached: true, stdio: ["ignore", "ignore", "ignore", "ipc"] });
  } catch (error) { releaseClaim(claim); throw error; }
  const initialization: RuntimeInitialization = { type: "initialize", operationId, muxId, claim, command: host.executable, args: selected.args, cwd, host,
    ...options.parent ? { parent: options.parent } : {} };
  return new Promise<RuntimeReceipt>((resolve, reject) => {
    let settled = false;
    let cancelling = false;
    let cancellationTimer: ReturnType<typeof setTimeout> | undefined;
    const cleanup = (): void => { clearTimeout(timer); if (cancellationTimer) clearTimeout(cancellationTimer); options.signal?.removeEventListener("abort", cancel); };
    const complete = (error?: Error, receipt?: RuntimeReceipt): void => {
      if (settled) return;
      settled = true; cleanup();
      if (child.connected) child.disconnect();
      child.unref();
      if (error) reject(error); else resolve(receipt!);
    };
    const cancel = (): void => {
      if (settled || cancelling) return;
      cancelling = true;
      if (child.connected) child.send({ type: "cancel" });
      cancellationTimer = setTimeout(() => complete(new RuntimeOperationError("Startup cancellation is uncertain; reconcile the retained operation before retrying", operationId, muxId)), 10_000);
    };
    const timer = setTimeout(cancel, options.timeoutMs ?? 30_000);
    child.on("message", (message: unknown) => {
      if (!isRecord(message)) return;
      if (message.type === "ready") {
        if (cancelling || options.signal?.aborted) cancel();
        else if (child.connected) child.send({ type: "commit" });
      } else if (message.type === "committed" && isRecord(message.receipt)) complete(undefined, message.receipt as unknown as RuntimeReceipt);
      else if (message.type === "failed") complete(new RuntimeOperationError(String(message.error ?? "Runtime startup failed"), operationId, muxId));
    });
    child.once("error", (error) => {
      // Spawn did not execute: the launcher still owns its unchanged capability.
      try { releaseClaim(claim); } catch { /* transfer may already have happened; fail closed */ }
      complete(new RuntimeOperationError(error.message, operationId, muxId));
    });
    child.once("exit", () => {
      const operation = readPrivateJson<OperationRecord>(files.operation);
      if (operation?.state === "committed" && operation.receipt) complete(undefined, operation.receipt);
      else complete(new RuntimeOperationError(operation?.error ?? "Runtime exited before commitment; inspect retained operation", operationId, muxId));
    });
    options.signal?.addEventListener("abort", cancel, { once: true });
    if (child.connected) child.send(initialization);
    if (options.signal?.aborted) cancel();
  });
}

export async function stopRuntime(muxId: string, options: { env?: NodeJS.ProcessEnv; timeoutMs?: number; operationId?: string } = {}): Promise<TerminalReceipt> {
  const env = options.env ?? process.env;
  const operationId = options.operationId ?? randomUUID();
  const files = runtimePaths(muxId, operationId, env);
  const retained = readPrivateJson<TerminalReceipt>(files.receipt);
  if (retained?.muxId === muxId && retained.state === "stopped") return retained;
  const discovery = readDiscovery(files.discovery);
  if (!discovery || discovery.muxId !== muxId || discovery.protocol !== PROTOCOL_VERSION) throw new Error("Runtime unavailable or unsupported; no process was signalled");
  validateSocket(discovery.socket);
  const timeoutMs = options.timeoutMs ?? 15_000;
  return new Promise((resolve, reject) => {
    const socket = net.connect(discovery.socket);
    let settled = false;
    const finish = (error?: Error, receipt?: TerminalReceipt): void => {
      if (settled) return;
      settled = true; clearTimeout(timer); socket.destroy();
      const retainedNow = readPrivateJson<TerminalReceipt>(files.receipt);
      if (retainedNow?.muxId === muxId && retainedNow.state === "stopped") resolve(retainedNow);
      else if (receipt) resolve(receipt); else reject(error ?? new Error("Stop acknowledgement lost; reconcile this runtime's retained receipt"));
    };
    const timer = setTimeout(() => finish(new Error("Stop is uncertain; no duplicate operation was submitted")), timeoutMs);
    const lines = new LineSplitter((line) => {
      let record: unknown; try { record = JSON.parse(line); } catch { return; }
      if (!isRecord(record)) return;
      if (record.type === "pimux_hello") {
        if (record.protocol !== PROTOCOL_VERSION || record.muxId !== muxId) finish(new Error("Stop target identity mismatch"));
        else socket.write(`${JSON.stringify({ type: "pimux_stop", id: operationId, operationId, expectedMuxId: muxId })}\n`);
      } else if (record.type === "response" && record.id === operationId) {
        if (record.success === true) finish(undefined, record.data as unknown as TerminalReceipt);
        else finish(new Error(String(record.error ?? "Stop refused")));
      } else if (record.type === "pimux_exit") finish();
    }, 128 * 1024 * 1024, () => finish(new Error("Stop response exceeds bound")));
    socket.on("data", (chunk: Buffer) => lines.push(chunk));
    socket.once("error", finish);
    socket.once("end", () => finish());
  });
}
