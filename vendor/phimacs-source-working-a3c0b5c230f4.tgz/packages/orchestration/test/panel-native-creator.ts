// Disposable process identity used by native panel creator-death tests.
process.stdin.resume();
