;;; contextual-native.el --- Explicit candidate host for native tests -*- lexical-binding: t; -*-
;; SPDX-License-Identifier: MIT
;;; Commentary:
;; Only acquired candidate inputs, never the user's init, packages or daemon.
;;; Code:
(require 'json)
(let* ((assets (getenv "PI_CONTEXTUAL_ASSETS"))
       (receipt (with-temp-buffer
                  (insert-file-contents (expand-file-name "provision.json" assets))
                  (json-parse-buffer :object-type 'plist))))
  (dolist (package (append (plist-get receipt :packages) nil))
    (dolist (directory (append (plist-get package :loadPaths) nil))
      (add-to-list 'load-path (expand-file-name directory assets))))
  (setq ghostel-module-directory (expand-file-name "ghostel" assets)
        treesit-extra-load-path (list (expand-file-name "tree-sitter" assets))))
(add-to-list 'load-path (getenv "PI_EMACS_PILISH"))
(add-to-list 'load-path (getenv "PI_CONTEXTUAL_ORCHESTRATION"))
(setq native-comp-jit-compilation nil
      load-prefer-newer t
      pilish-essential-grammar-action 'warn)
(require 'pilish)
(pilish-configure-runtime :pi-executable (getenv "PHIMACS_PI")
                          :pimux-executable (getenv "PI_CONTEXTUAL_PIMUX")
                          :protocol 2 :pi-version "1.4.0")
(require 'pi-orchestration)
(provide 'contextual-native)
;;; contextual-native.el ends here
