import assert from "node:assert/strict";
import test from "node:test";
import type { ExtensionAPI, ExtensionCommandContext, RegisteredCommand } from "@earendil-works/pi-coding-agent";
import { registerSwitch } from "./switch.ts";
import { registerTake } from "./take.ts";
import type { SwitchSource } from "../switch-destinations.ts";

function fixture(options: { muxId?: string; failure?: string } = {}) {
  const commands = new Map<string, RegisteredCommand>();
  const notices: string[] = [];
  const shares: string[] = [];
  const preparations: SwitchSource[] = [];
  let writes = 0;
  let replacements = 0;
  let starts = 0;
  let wait: (() => Promise<void>) | undefined;
  const pi = {
    registerCommand: (name: string, command: RegisteredCommand) => commands.set(name, command),
    appendEntry: () => { writes++; },
  } as unknown as ExtensionAPI;
  const ctx = {
    cwd: "/synthetic/project", sessionManager: { getSessionFile: () => "/synthetic/session.jsonl" },
    isIdle: () => false, hasPendingMessages: () => true,
    switchSession: async () => { replacements++; return { cancelled: false }; },
    ui: { select: async () => "tau", notify: (message: string) => notices.push(message) },
  } as unknown as ExtensionCommandContext;
  registerSwitch(pi, {
    runtime: () => options.muxId, environment: () => ({ HOME: "/synthetic", PHIMACS_MANAGED_CLAIM: "never-forward-this", PHIMACS_PARENT_TASK: "never-forward-parent" }),
    share: async (muxId) => {
      shares.push(muxId);
      await wait?.();
      if (options.failure) throw new Error(options.failure);
      return "Tau attached";
    },
    prepare: async (_kind, source) => {
      preparations.push(source);
      return { start: async () => { starts++; if (options.failure) throw new Error(options.failure); return "Emacs attached"; } };
    },
  });
  registerTake(pi);
  return { ctx, notices, shares, preparations,
    command: (name = "switch", arg = "tau") => commands.get(name)!.handler(arg, ctx),
    hold: (fn: () => Promise<void>) => { wait = fn; },
    counts: () => ({ writes, replacements, starts }),
  };
}

test("busy shared RPC can attach Tau without source replacement, appends or inferred prompts", async () => {
  const f = fixture({ muxId: "runtime-one" });
  await f.command();
  assert.deepEqual(f.shares, ["runtime-one"]);
  assert.deepEqual(f.counts(), { writes: 0, replacements: 0, starts: 0 });
  assert.match(f.notices.at(-1)!, /Both views stay live and in sync/);
});

test("Emacs attachment carries explicit mux identity and cannot inherit writer capability or parent task", async () => {
  const f = fixture({ muxId: "runtime-one" });
  await f.command("switch", "emacs");
  assert.deepEqual(f.preparations[0]!.runtime, { protocol: 2, muxId: "runtime-one" });
  assert.deepEqual(f.preparations[0]!.args, []);
  assert.equal(f.preparations[0]!.env.PHIMACS_MANAGED_CLAIM, "");
  assert.equal(f.preparations[0]!.env.PHIMACS_PARENT_TASK, "");
  assert.deepEqual(f.counts(), { writes: 0, replacements: 0, starts: 1 });
});

for (const destination of ["herdr", "emacs", "tau"]) {
  test(`native /switch ${destination} refuses before any destination or source mutation`, async () => {
    const f = fixture();
    await f.command("switch", destination);
    assert.match(f.notices.at(-1)!, /source cannot be made permanently unable to write/);
    assert.deepEqual(f.shares, []);
    assert.deepEqual(f.preparations, []);
    assert.deepEqual(f.counts(), { writes: 0, replacements: 0, starts: 0 });
  });
}

test("RPC to native refuses rather than release a live writer", async () => {
  const f = fixture({ muxId: "runtime-one" });
  await f.command("switch", "herdr");
  assert.match(f.notices.at(-1)!, /No claim was released and no destination was opened/);
  assert.deepEqual(f.shares, []);
});

test("attachment failure does not reload or stop the source and permits an explicit retry", async () => {
  const f = fixture({ muxId: "runtime-one", failure: "attachment uncertain; inspect views" });
  await f.command();
  await f.command();
  assert.equal(f.shares.length, 2);
  assert.match(f.notices.at(-1)!, /attachment uncertain/);
  assert.deepEqual(f.counts(), { writes: 0, replacements: 0, starts: 0 });
});

test("a concurrent command cannot start another attachment while readiness is pending", async () => {
  const f = fixture({ muxId: "runtime-one" });
  let finish!: () => void;
  f.hold(() => new Promise<void>((resolve) => { finish = resolve; }));
  const first = f.command();
  await f.command();
  assert.match(f.notices.at(-1)!, /already in progress/);
  finish();
  await first;
  assert.equal(f.shares.length, 1);
});

for (const command of ["take", "_session-take"]) {
  test(`${command} keeps source and receiver untouched instead of executing the unsafe legacy handoff`, async () => {
    const f = fixture({ muxId: "runtime-one" });
    await f.command(command, "tau");
    assert.match(f.notices.at(-1)!, /failed replacements have no authoritative settlement/);
    assert.deepEqual(f.counts(), { writes: 0, replacements: 0, starts: 0 });
    assert.deepEqual(f.shares, []);
  });
}
