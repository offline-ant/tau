import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { TRANSFER_OWNERSHIP_BLOCKER } from "../session-transfer.ts";

/**
 * Pi 1.4 has no capability that makes a loaded source permanently unable to
 * write, or that authoritatively settles a failed replacement. Opening the
 * receiver first duplicates a writer; releasing first while the source remains
 * loaded is not a handoff. Keep the command, but never run that unsafe protocol.
 * Shared RPC clients use /switch to attach without transferring ownership.
 */
export function registerTake(pi: ExtensionAPI): void {
  pi.registerCommand("take", {
    description: "Explain the native session-handoff safety requirement. Usage: /take [tau|herdr]",
    handler: async (args, ctx) => {
      const destination = args.trim();
      if (destination && destination !== "tau" && destination !== "herdr") {
        ctx.ui.notify("Usage: /take [tau|herdr].", "error");
        return;
      }
      ctx.ui.notify(TRANSFER_OWNERSHIP_BLOCKER, "error");
    },
  });
  pi.registerCommand("_session-take", {
    description: "Refuse the retired unsafe native takeover dispatch",
    handler: async (_token, ctx) => { ctx.ui.notify(TRANSFER_OWNERSHIP_BLOCKER, "error"); },
  });
}
