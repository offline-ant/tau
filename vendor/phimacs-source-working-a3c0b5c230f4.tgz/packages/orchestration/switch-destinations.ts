import { execFile, spawn } from "node:child_process";
import { promisify } from "node:util";
import * as os from "node:os";
import * as path from "node:path";
import { emacsDaemon, prepareEmacsSwitch } from "./switch-emacs.ts";
import { readDiscovery } from "@phimacs/pimux/discovery";
import { canonicalSessionPath, lookupClaim } from "@phimacs/pimux/ownership";
import { readProcessIdentity, sameProcessIdentity } from "@phimacs/pimux/process-identity";
import { MANAGED_CLAIM_ENV } from "@phimacs/pimux/guard";
import { PROTOCOL_VERSION } from "@phimacs/pimux/protocol";
import { ensureTauServer, localTauConnection, type TauServer } from "./tau-server.ts";
import { TRANSFER_OWNERSHIP_BLOCKER } from "./session-transfer.ts";

export type SwitchDestination = "herdr" | "tau" | "emacs";
export interface SwitchSource {
  sessionFile: string;
  cwd: string;
  args: string[];
  env: Record<string, string>;
  /** Required for a frontend attachment; never permission to start another writer. */
  runtime?: { protocol: 2; muxId: string };
}
export interface PreparedSwitch { start(): Promise<string> }

/** Explicit empty values override identities inherited from the destination host. */
export function switchEnvironment(env: NodeJS.ProcessEnv): Record<string, string> {
  return {
    PI_CODING_AGENT_DIR: path.resolve(env.PI_CODING_AGENT_DIR || path.join(env.HOME || os.homedir(), ".pi", "agent")),
    PI_NESTED: "", PI_ORCHESTRATION_TARGET: "", PI_ORCHESTRATION_CONTROL: "",
    PI_ORCHESTRATION_PLACEMENT: "", PI_ORCHESTRATION_PARENT: "", PHIMACS_PARENT_TASK: "", PHIMACS_PARENT_TASK_FILE: "",
    PHIMACS_MANAGED_CLAIM: "", PIMUX_DISCOVERY: "",
    HERDR_ENV: "", HERDR_SOCKET_PATH: env.HERDR_SOCKET_PATH || "",
    HERDR_WORKSPACE_ID: "", HERDR_TAB_ID: "", HERDR_PANE_ID: "", TMUX: "", TMUX_PANE: "",
    ...(env.PI_CODING_AGENT_SESSION_DIR ? { PI_CODING_AGENT_SESSION_DIR: path.resolve(env.PI_CODING_AGENT_SESSION_DIR) } : {}),
  };
}

function object(value: unknown): Record<string, unknown> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) throw new Error("Invalid destination response");
  return value as Record<string, unknown>;
}

export function assertSharedSwitch(source: SwitchSource): asserts source is SwitchSource & { runtime: { protocol: 2; muxId: string } } {
  if (source.runtime?.protocol !== PROTOCOL_VERSION || !source.runtime.muxId) throw new Error(TRANSFER_OWNERSHIP_BLOCKER);
}

export async function prepareSwitch(kind: SwitchDestination, source: SwitchSource): Promise<PreparedSwitch> {
  assertSharedSwitch(source);
  if (kind === "herdr") throw new Error(TRANSFER_OWNERSHIP_BLOCKER);
  if (kind === "emacs") return prepareEmacsSwitch(source, await emacsDaemon(process.env));
  const server = await ensureTauServer({ ...process.env, ...source.env });
  return prepareTauSwitch(source, server.endpoint, openTauBrowser, server);
}

export async function openTauBrowser(url: string): Promise<void> {
  const command = process.platform === "darwin" ? "open" : process.platform === "win32" ? "rundll32.exe" : "xdg-open";
  const args = process.platform === "win32" ? ["url.dll,FileProtocolHandler", url] : [url];
  await new Promise<void>((resolve, reject) => {
    const child = spawn(command, args, { detached: true, stdio: "ignore" });
    child.once("error", reject);
    child.once("spawn", () => { child.unref(); resolve(); });
  });
}

type TauConnection = ReturnType<typeof localTauConnection>;
async function openTauTab(connection: TauConnection, sessionId: string, open: (url: string) => Promise<void>, server?: TauServer): Promise<string> {
  const hash = `session=${encodeURIComponent(sessionId)}`;
  const url = `${connection.base}/#${hash}`;
  let browser = "";
  try { await open(url); } catch { browser = "\nBrowser could not be opened; open this URL manually."; }
  const addresses = (server?.browserUrls ?? []).map((address) => {
    const external = new URL(address);
    external.username = ""; external.password = ""; external.hash = hash;
    return external.href;
  }).filter((address) => address !== url);
  const remote = addresses.length ? `\nBrowser URLs: ${addresses.join("\n")}` : "";
  const service = server?.pid ? `\nTau server PID: ${server.pid}${server.logFile ? `; log: ${server.logFile}` : ""}. It runs independently of this panel.` : "";
  return `Tau tab ${sessionId} at ${url}${remote}${service}${browser}`;
}

/** Discovery is only a locator: the claim must identify this exact live Pi. */
export function sharedMuxId(env: NodeJS.ProcessEnv, sessionFile?: string): string | undefined {
  const serialized = env[MANAGED_CLAIM_ENV];
  if (!serialized || !env.PIMUX_DISCOVERY) return undefined;
  const capability = object(JSON.parse(serialized));
  if (typeof capability.file !== "string" || typeof capability.token !== "string") throw new Error("Invalid managed source capability; no destination was opened.");
  const options = env.PHIMACS_TEST_ROOT ? { testRoot: env.PHIMACS_TEST_ROOT } : {};
  const initial = lookupClaim(capability.file, options);
  const current = lookupClaim(sessionFile ?? capability.file, options);
  const self = readProcessIdentity(process.pid);
  const discovery = readDiscovery(env.PIMUX_DISCOVERY);
  if (!initial || initial.token !== capability.token || !current || !self || !current.owner.pi
    || current.owner.id !== initial.owner.id || current.owner.kind !== "rpc" || current.owner.protocol !== PROTOCOL_VERSION
    || !sameProcessIdentity(current.owner.pi, self) || !discovery || discovery.protocol !== PROTOCOL_VERSION
    || discovery.phase !== "committed" || discovery.muxId !== current.owner.id || discovery.piPid !== self.pid
    || !discovery.ownerIdentity || !sameProcessIdentity(discovery.ownerIdentity, current.owner.wrapper)
    || discovery.socket !== current.owner.socket || !discovery.session?.file
    || canonicalSessionPath(discovery.session.file) !== current.file) {
    throw new Error("Shared runtime ownership is unconfirmed; the source and its claims were left unchanged.");
  }
  return current.owner.id;
}

/** Attach this exact runtime, including while busy; never ask Tau to resume its file. */
export async function shareTauSession(muxId: string, open: (url: string) => Promise<void> = openTauBrowser, server?: TauServer): Promise<string> {
  const tau = server ?? await ensureTauServer({ ...process.env, ...switchEnvironment(process.env) });
  const connection = localTauConnection(tau.endpoint);
  let response: Response;
  let data: Record<string, unknown>;
  try {
    response = await fetch(`${connection.base}/api/live-sessions/attach`, {
      method: "POST", headers: connection.headers, body: JSON.stringify({ muxId }), redirect: "error", signal: AbortSignal.timeout(120_000),
    });
    data = object(await response.json());
  } catch { throw new Error("Cannot reach the local Tau server; the shared runtime is unchanged."); }
  if (!response.ok) throw new Error(`Tau could not attach to this session (HTTP ${response.status}).`);
  const session = object(data.session);
  const attached = session.attached;
  if (data.attached !== true || typeof session.id !== "string" || typeof attached !== "object" || attached === null
    || (attached as Record<string, unknown>).muxId !== muxId) throw new Error("Tau did not confirm an attachment to this runtime. Inspect its live tabs; do not start another Pi.");
  return `${data.started === true ? "Shared with" : "Already shared with"} ${await openTauTab(connection, session.id, open, tau)}`;
}

export async function prepareTauSwitch(source: SwitchSource, endpoint: string, open: (url: string) => Promise<void> = openTauBrowser, server?: TauServer): Promise<PreparedSwitch> {
  assertSharedSwitch(source);
  const tau = server ?? { endpoint, started: false };
  localTauConnection(endpoint); // Refuse remote endpoints before any attachment.
  return { start: () => shareTauSession(source.runtime.muxId, open, tau) };
}

/** Local Herdr discovery for read-only takeover listings; never starts a Pi. */
export function herdrCommand(endpoint?: string, environment: NodeJS.ProcessEnv = process.env): (args: string[]) => Promise<string> {
  const env = { ...environment };
  if (endpoint) env.HERDR_SOCKET_PATH = endpoint;
  else delete env.HERDR_SOCKET_PATH;
  return async (args) => {
    const { stdout } = await promisify(execFile)(environment.HERDR_BIN_PATH || "herdr", args, { env, timeout: 120_000, maxBuffer: 1024 * 1024 });
    return stdout;
  };
}

/** Native handoff cannot be made transactional by a launcher or extension. */
export async function prepareHerdrSwitch(_source: SwitchSource, _endpoint?: string, _run?: (args: string[]) => Promise<string>): Promise<PreparedSwitch> {
  throw new Error(TRANSFER_OWNERSHIP_BLOCKER);
}
