import assert from "node:assert/strict";
import * as http from "node:http";
import test, { type TestContext } from "node:test";
import { fileURLToPath } from "node:url";
import { readProcessIdentity } from "@phimacs/pimux/process-identity";
import type { RuntimeReceipt, StartRuntimeOptions } from "@phimacs/pimux/runtime";
import type { StartSpec } from "../host-types.ts";
import { createWebHost, parseWebEndpoint, renderEntries, type WebRuntimeServices } from "./web.ts";

const PI = fileURLToPath(new URL("./cli.js", import.meta.resolve("@earendil-works/pi-coding-agent")));
const SELF = readProcessIdentity(process.pid)!;
const spec = (): Extract<StartSpec, { kind: "pi" }> => ({ kind: "pi", name: "delegate-test", cwd: process.cwd(),
  sessionFile: "/synthetic/session.jsonl", args: ["--provider", "faux", "--model", "faux"], placement: "worker",
  env: { PHIMACS_PI: PI, PHIMACS_PARENT_TASK: JSON.stringify({ process: SELF, taskId: "task-test" }), PHIMACS_PARENT_TASK_FILE: "/synthetic/parent-task.json" },
  prompt: "/worker-run /synthetic/request.json" });
function fakeRuntime(options: { rejectPrompt?: boolean; attached?: boolean } = {}) {
  const starts: StartRuntimeOptions[] = [];
  const stops: string[] = [];
  const prompts: string[] = [];
  const receipt: RuntimeReceipt = { protocol: 2, muxId: "mux-test", operationId: "operation-test", socket: "/synthetic/mux-test.sock",
    pid: process.pid, piPid: process.pid, sessionFile: "/synthetic/session.jsonl", state: "committed", outcome: options.attached ? "attached" : "started" };
  const services: WebRuntimeServices = {
    start: async (input) => { starts.push(input); return receipt; },
    stop: async (id) => { stops.push(id); return { protocol: 2, muxId: id, operationId: "stop-test", state: "stopped", code: 0, signal: null, stoppedAt: new Date().toISOString() }; },
    identity: () => SELF,
    request: async (_runtime, request) => {
      if (request.type === "prompt") {
        if (options.rejectPrompt) return { type: "response", success: false, error: "No model selected" };
        assert.equal(request.streamingBehavior, "steer"); prompts.push(String(request.message));
        return { type: "response", success: true };
      }
      assert.equal(request.type, "get_messages");
      return { type: "response", success: true, data: { messages: prompts.map((content) => ({ role: "user", content })) } };
    },
  };
  return { services, starts, stops, prompts, receipt };
}
async function fakeTau(t: TestContext, options: { credentials?: string; wrongMux?: boolean } = {}) {
  const calls: Array<{ method: string; path: string; body: Record<string, unknown>; authorization?: string }> = [];
  const server = http.createServer(async (request, response) => {
    let text = "";
    for await (const chunk of request) text += String(chunk);
    const body = text ? JSON.parse(text) as Record<string, unknown> : {};
    calls.push({ method: request.method!, path: request.url!, body, authorization: request.headers.authorization });
    const send = (status: number, data: unknown) => { response.writeHead(status, { "Content-Type": "application/json" }); response.end(JSON.stringify(data)); };
    if (options.credentials && request.headers.authorization !== `Basic ${Buffer.from(options.credentials).toString("base64")}`) return send(401, { error: "Unauthorized" });
    if (request.method === "POST" && request.url === "/api/live-sessions/attach") return send(200, { attached: true,
      session: { id: "tau-test", attached: { muxId: options.wrongMux ? "other-mux" : body.muxId } } });
    if (request.method === "DELETE" && request.url === "/api/live-sessions/tau-test") return send(200, { success: true });
    return send(404, { error: "Unexpected frontend request" });
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(async () => { server.closeAllConnections(); await new Promise<void>((resolve) => server.close(() => resolve())); });
  const address = server.address();
  assert.ok(address && typeof address !== "string");
  return { server, calls, endpoint: `http://${options.credentials ? `${options.credentials}@` : ""}127.0.0.1:${address.port}` };
}

test("credentials stay out of URLs and unauthorized attachment stops only its newly owned worker", async (t) => {
  assert.deepEqual(parseWebEndpoint("http://user:secret@127.0.0.1:3001"), { base: "http://127.0.0.1:3001",
    headers: { "Content-Type": "application/json", Authorization: `Basic ${Buffer.from("user:secret").toString("base64")}` } });
  assert.throws(() => parseWebEndpoint("/tmp/socket"), /must be a URL/);
  assert.throws(() => parseWebEndpoint("//user:secret@host"), (error: Error) => !error.message.includes("secret"));
  assert.throws(() => parseWebEndpoint("ws://localhost"), /must use http or https/);
  const tau = await fakeTau(t, { credentials: "user:secret" });
  const runtime = fakeRuntime();
  const host = createWebHost(tau.endpoint, runtime.services);
  const target = await host.start(spec());
  assert.equal(tau.calls[0].authorization, `Basic ${Buffer.from("user:secret").toString("base64")}`);
  await host.close(target);
  const refused = fakeRuntime();
  await assert.rejects(createWebHost(tau.endpoint.replace("user:secret@", ""), refused.services).start(spec()), /check the endpoint credentials/);
  assert.deepEqual(refused.stops, ["mux-test"]);
});

test("web creates a parent-bound exact local runtime then attaches by mux, never create/resume/force", async (t) => {
  const tau = await fakeTau(t);
  const runtime = fakeRuntime();
  const host = createWebHost(tau.endpoint, runtime.services);
  const input = spec();
  const target = await host.start(input);
  assert.equal(host.parent(), undefined);
  assert.equal(runtime.starts.length, 1);
  assert.equal(runtime.starts[0].command, PI);
  assert.deepEqual(runtime.starts[0].args, ["--mode", "rpc", "--session", input.sessionFile, ...input.args]);
  assert.deepEqual(runtime.starts[0].parent, { process: SELF, taskId: "task-test" });
  assert.equal(runtime.starts[0].env?.PHIMACS_PARENT_TASK_FILE, "/synthetic/parent-task.json");
  assert.deepEqual(tau.calls.map(({ method, path, body }) => ({ method, path, body })), [{ method: "POST", path: "/api/live-sessions/attach", body: { muxId: "mux-test" } }]);
  assert.deepEqual(target.process, SELF);
  assert.equal(target.runtime?.muxId, "mux-test");
  assert.deepEqual(runtime.prompts, [input.prompt]);
  await host.send(target, { kind: "prompt", text: "continue" });
  assert.match(await host.read(target), /user: \/worker-run.*\n\nuser: continue/);
  assert.equal(await host.state(target), "running");
  assert.equal(await host.state({ ...target, process: { ...SELF, startTime: `${SELF.startTime}0` } }), "exited");
  // Losing Tau is not loss of the runtime or its task/result protocol.
  tau.server.closeAllConnections();
  await new Promise<void>((resolve) => tau.server.close(() => resolve()));
  assert.equal(await host.state(target), "running");
  await host.send(target, { kind: "prompt", text: "still connected directly" });
  await host.close(target);
  assert.deepEqual(runtime.stops, ["mux-test"]);
});

test("unconfirmed attachment or rejected prompt closes only this owned task and never replays", async (t) => {
  const tau = await fakeTau(t, { wrongMux: true });
  const own = fakeRuntime();
  await assert.rejects(createWebHost(tau.endpoint, own.services).start(spec()), /exact runtime attachment/);
  assert.deepEqual(own.stops, ["mux-test"]);
  assert.deepEqual(own.prompts, []);
  const existing = fakeRuntime({ attached: true });
  await assert.rejects(createWebHost(tau.endpoint, existing.services).start(spec()), /owning parent task/);
  assert.deepEqual(existing.stops, []);
  const valid = await fakeTau(t);
  const rejected = fakeRuntime({ rejectPrompt: true });
  await assert.rejects(createWebHost(valid.endpoint, rejected.services).start(spec()), /No model selected/);
  assert.deepEqual(rejected.stops, ["mux-test"]);
  assert.equal(valid.calls.at(-1)?.method, "DELETE");
});

test("web refuses terminal work, missing parent authority and cancellation before any launch", async (t) => {
  const tau = await fakeTau(t);
  const runtime = fakeRuntime();
  const host = createWebHost(tau.endpoint, runtime.services);
  await assert.rejects(host.start({ kind: "shell", name: "shell", cwd: process.cwd(), argv: ["bash"], placement: "worker" }), /no terminal/);
  await assert.rejects(host.start({ ...spec(), env: { PHIMACS_PI: PI } }), /parent process identity/);
  const cancelled = new AbortController(); cancelled.abort();
  await assert.rejects(host.start(spec(), cancelled.signal), { name: "AbortError" });
  assert.equal(runtime.starts.length, 0);
  const target = await host.start(spec());
  await assert.rejects(host.send(target, { kind: "text", text: "x", enter: true }), /no terminal/);
  await assert.rejects(host.send(target, { kind: "keys", keys: ["ctrl+c"] }), /no terminal/);
});

test("an attachment receipt cannot redirect the requested conversation or confer cleanup ownership", async (t) => {
  const tau = await fakeTau(t);
  for (const supplied of [false, true]) {
    const runtime = fakeRuntime();
    const wrong = { ...runtime.receipt, sessionFile: "/synthetic/other.jsonl" };
    runtime.services.start = async (input) => { runtime.starts.push(input); return wrong; };
    await assert.rejects(createWebHost(tau.endpoint, runtime.services).start({ ...spec(), ...(supplied ? { runtime: wrong } : {}) }), /different session/);
    assert.deepEqual(runtime.prompts, []);
    assert.deepEqual(runtime.stops, supplied ? [] : ["mux-test"]);
    assert.equal(tau.calls.length, 0, "identity validation precedes frontend attachment");
  }
});

test("a supplied runtime's historical started receipt never authorizes failed-view cleanup", async (t) => {
  const tau = await fakeTau(t, { wrongMux: true });
  const runtime = fakeRuntime();
  await assert.rejects(createWebHost(tau.endpoint, runtime.services).start({ ...spec(), runtime: runtime.receipt }), /exact runtime attachment/);
  assert.equal(runtime.starts.length, 0);
  assert.deepEqual(runtime.stops, []);
  assert.deepEqual(runtime.prompts, []);
});

test("prompt acceptance requires an affirmative response", async (t) => {
  const tau = await fakeTau(t);
  const runtime = fakeRuntime();
  runtime.services.request = async () => ({ type: "response" });
  await assert.rejects(createWebHost(tau.endpoint, runtime.services).start(spec()), /rejected the prompt/);
  assert.deepEqual(runtime.stops, ["mux-test"]);
});

test("transcript rendering preserves useful blocks and bounded tail", () => {
  const entries = [{ type: "message", message: { role: "user", content: "run" } }, { type: "custom", data: "ignored" },
    { type: "message", message: { role: "assistant", content: [{ type: "thinking", text: "hidden" }, { type: "text", text: "starting" }, { type: "toolCall", name: "bash" }, { type: "image" }] } }];
  assert.equal(renderEntries(entries, 80), "user: run\n\nassistant: starting\n[tool bash]\n[image]");
  assert.equal(renderEntries(entries, 2), "[tool bash]\n[image]");
  assert.equal(renderEntries([], 2), "");
});
