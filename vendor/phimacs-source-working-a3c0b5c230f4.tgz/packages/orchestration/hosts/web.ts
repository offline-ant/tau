/*
 * Web host: Tau attaches a view to a locally owned detached Pi runtime.
 * Prompts and transcript reads use the runtime's identity-checked socket,
 * independently of the view/server lifetime. No terminal panels are available.
 */

import * as path from "node:path";
import type { Host, HostTarget } from "../host-types.ts";
import { startRuntime, stopRuntime, type ParentTask } from "@phimacs/pimux/runtime";
import { processIdentityStatus } from "@phimacs/pimux/process-identity";
import { canonicalSessionPath } from "@phimacs/pimux/ownership";
import { managedHost, processIdentity } from "../managed-launch.ts";
import { runtimeIdentity, runtimeRequest } from "./runtime-request.ts";

const REQUEST_TIMEOUT_MS = 30_000;

interface Connection {
  base: string;
  headers: Record<string, string>;
}

/** The endpoint is a URL; HTTP Basic credentials live in its userinfo. */
export function parseWebEndpoint(endpoint: string): Connection {
  let url: URL;
  try {
    url = new URL(endpoint);
  } catch {
    // Not echoed: a malformed URL can still hold its credentials.
    throw new Error("The web orchestration endpoint must be a URL.");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error(`The web orchestration endpoint must use http or https, not '${url.protocol}'.`);
  }
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (url.username) {
    const credentials = `${decodeURIComponent(url.username)}:${decodeURIComponent(url.password)}`;
    headers.Authorization = `Basic ${Buffer.from(credentials).toString("base64")}`;
  }
  url.username = "";
  url.password = "";
  return { base: url.origin, headers };
}

interface EntryMessage {
  role?: string;
  content?: unknown;
}

function record(value: unknown): Record<string, unknown> {
  return typeof value === "object" && value !== null ? value as Record<string, unknown> : {};
}

/** `undefined` for 404, so callers can distinguish a closed session from a failure. */
async function request(
  connection: Connection,
  method: string,
  path: string,
  body: unknown,
  signal: AbortSignal | undefined,
): Promise<Record<string, unknown> | undefined> {
  const timeout = AbortSignal.timeout(REQUEST_TIMEOUT_MS);
  let response: Response;
  try {
    response = await fetch(`${connection.base}${path}`, {
      method,
      headers: connection.headers,
      signal: signal ? AbortSignal.any([signal, timeout]) : timeout,
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
  } catch (error) {
    signal?.throwIfAborted();
    throw new Error(`Could not reach the web host at ${connection.base}: ${error instanceof Error ? error.message : String(error)}`);
  }
  if (response.status === 404) return undefined;
  const text = await response.text();
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error(`The web host at ${connection.base} answered ${method} ${path} with non-JSON content (status ${response.status}).`);
  }
  const data = record(parsed);
  if (!response.ok) {
    const detail = typeof data.error === "string" ? data.error : `status ${response.status}`;
    throw new Error(`Web host ${method} ${path} failed: ${detail}${response.status === 401 ? " (check the endpoint credentials)" : ""}`);
  }
  return data;
}

function blockText(block: Record<string, unknown>): string | undefined {
  if (block.type === "text" && typeof block.text === "string") return block.text;
  if (block.type === "image") return "[image]";
  if (block.type === "toolCall") return `[tool ${String(block.name ?? "?")}]`;
  return undefined;
}

function messageText(message: EntryMessage): string {
  if (typeof message.content === "string") return message.content;
  if (!Array.isArray(message.content)) return "";
  return message.content.map((block) => blockText(record(block))).filter((text): text is string => text !== undefined).join("\n");
}

/** Terminal hosts return a pane snapshot; here the equivalent is the transcript tail. */
export function renderEntries(entries: unknown[], lines: number): string {
  const rendered: string[] = [];
  for (const entry of entries) {
    const item = record(entry);
    if (item.type !== "message") continue;
    const message = record(item.message) as EntryMessage;
    const text = messageText(message).trim();
    if (!text) continue;
    rendered.push(`${message.role ?? "message"}: ${text}`);
  }
  return rendered.join("\n\n").split("\n").slice(-Math.max(1, lines)).join("\n");
}

export interface WebRuntimeServices {
  start: typeof startRuntime;
  stop: typeof stopRuntime;
  identity: typeof runtimeIdentity;
  request: typeof runtimeRequest;
}

export function createWebHost(endpoint: string, runtime: WebRuntimeServices = { start: startRuntime, stop: stopRuntime, identity: runtimeIdentity, request: runtimeRequest }): Host {
  const connection = parseWebEndpoint(endpoint);
  const sessionPath = (target: HostTarget) => `/api/live-sessions/${encodeURIComponent(target.id)}`;
  const host: Host = {
    kind: "web", endpoint,
    // Sessions are a flat server-owned list: nothing to parent a new one to.
    parent: () => undefined,
    async start(spec, signal) {
      signal?.throwIfAborted();
      if (spec.kind === "shell") {
        throw new Error("The web host runs Pi sessions only; it has no terminal for shell panels. Select a terminal host with /orchestration-host to start panels.");
      }
      const env = { ...process.env, ...spec.env, PI_ORCHESTRATION_PLACEMENT: spec.placement,
        PHIMACS_PARENT_TASK: spec.placement === "worker" ? spec.env?.PHIMACS_PARENT_TASK ?? "" : "",
        PHIMACS_PARENT_TASK_FILE: spec.placement === "worker" ? spec.env?.PHIMACS_PARENT_TASK_FILE ?? "" : "" };
      const selected = managedHost(env);
      let parent: ParentTask | undefined;
      if (spec.placement === "worker") {
        const value = record(env.PHIMACS_PARENT_TASK ? JSON.parse(env.PHIMACS_PARENT_TASK) : undefined);
        const identity = processIdentity(value.process);
        if (!identity || typeof value.taskId !== "string" || !value.taskId) throw new Error("Detached worker requires its parent process identity and task ID");
        parent = { process: identity, taskId: value.taskId };
      }
      const receipt = spec.runtime ?? await runtime.start({ command: selected.executable,
        args: ["--mode", "rpc", "--session", spec.sessionFile, ...spec.args], cwd: spec.cwd, env,
        signal, expectedHost: { version: selected.version, sha256: selected.sha256 }, ...(parent ? { parent } : {}) });
      let target: HostTarget | undefined;
      try {
        if (spec.placement === "worker" && receipt.outcome === "attached" && !spec.runtime) throw new Error("Worker already has a live runtime; continue through its owning parent task");
        if (canonicalSessionPath(receipt.sessionFile) !== canonicalSessionPath(spec.sessionFile)) throw new Error("Detached runtime receipt names a different session");
        const identity = runtime.identity(receipt, env);
        // Tau attaches to our already owned runtime. No create/resume/force or
        // server-side model choice can open a second writer.
        const attached = await request(connection, "POST", "/api/live-sessions/attach", { muxId: receipt.muxId }, signal);
        const session = record(attached?.session);
        if (attached?.attached !== true || typeof session.id !== "string" || record(session.attached).muxId !== receipt.muxId) throw new Error("Tau did not confirm this exact runtime attachment");
        target = { host: "web", endpoint, id: session.id, name: spec.name, kind: "pi", sessionFile: receipt.sessionFile, runtime: receipt, process: identity };
        signal?.throwIfAborted();
        if (spec.prompt) await host.send(target, { kind: "prompt", text: spec.prompt }, signal);
        return target;
      } catch (error) {
        let cleanup = "";
        if (receipt.outcome === "started" && spec.placement === "worker" && !spec.runtime) {
          try { await runtime.stop(receipt.muxId, { env: { ...env, PIMUX_DIR: path.dirname(receipt.socket) } }); }
          catch (failure) { cleanup = ` Owned worker cleanup uncertain: ${String(failure)}`; }
        }
        if (target) await request(connection, "DELETE", sessionPath(target), undefined, undefined).catch(() => undefined);
        throw new Error(`${String(error)} Runtime ${receipt.muxId}; no prompt replay.${cleanup}`);
      }
    },
    async send(target, input, signal) {
      if (input.kind !== "prompt") {
        throw new Error("The web host has no terminal: it accepts Pi prompts, not typed text or key presses.");
      }
      // "steer" only applies while the child is streaming; an idle child takes
      // the prompt directly. Either way the human's own draft is untouched.
      if (!target.runtime || !target.process) throw new Error("Managed web target lacks owned runtime identity");
      const response = await runtime.request(target.runtime, {
        type: "prompt", message: input.text, streamingBehavior: "steer",
      }, signal);
      if (response.success !== true) {
        throw new Error(`Web host rejected the prompt for ${target.name}: ${String(response.error ?? "unknown error")}`);
      }
    },
    async read(target, lines = 80, signal) {
      if (!target.runtime) throw new Error("Managed web target lacks runtime identity");
      const response = await runtime.request(target.runtime, { type: "get_messages" }, signal);
      if (response.success !== true) throw new Error(String(response.error ?? "Cannot read runtime transcript"));
      const data = record(response.data);
      return renderEntries(Array.isArray(data.messages) ? data.messages.map((message) => ({ type: "message", message })) : [], lines);
    },
    // Only the actual Pi's recorded start identity decides runtime liveness.
    async state(target, signal) {
      signal?.throwIfAborted();
      if (!target.process) throw new Error("Managed web target lacks process-start identity; a tab is not Pi liveness");
      const state = processIdentityStatus(target.process);
      if (state === "unknown") throw new Error("Detached Pi liveness is uncertain");
      return state === "alive" ? "running" : "exited";
    },
    async close(target, signal) {
      signal?.throwIfAborted();
      if (!target.runtime || !target.process) throw new Error("Cannot stop an unowned web runtime");
      if (processIdentityStatus(target.process) !== "dead") await runtime.stop(target.runtime.muxId, { env: { ...process.env, PIMUX_DIR: path.dirname(target.runtime.socket) } });
      // DELETE disconnects the view. A dead Tau cannot invalidate confirmed stop.
      await request(connection, "DELETE", sessionPath(target), undefined, undefined).catch(() => undefined);
    },
  };
  return host;
}
