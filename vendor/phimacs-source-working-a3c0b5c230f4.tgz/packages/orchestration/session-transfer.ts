import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";

export { reserveManagedSession } from "@phimacs/pimux/guard";

export const TRANSFER_OWNERSHIP_BLOCKER =
  "Native session handoff is unavailable with Pi 1.4: the source cannot be made permanently unable to write before another Pi opens its file, and failed replacements have no authoritative settlement. No claim was released and no destination was opened. For a detached RPC agent use /switch emacs or /switch tau to attach the same runtime. For a native agent, explicitly stop it, verify its owned process has exited, then reopen the saved conversation with the release's managed launcher. Do not run a second raw pi --session against a live conversation.";

const TRANSFERRING = Symbol.for("pi-orchestration:transferring");
export function transferOperation(): { active: boolean } {
  const global = globalThis as typeof globalThis & { [TRANSFERRING]?: { active: boolean } };
  return global[TRANSFERRING] ??= { active: false };
}

/** Legacy transport metadata; no registered command executes its unsafe load operation. */
export interface SessionTransfer {
  sessionFile: string;
  cwd: string;
  agentDir: string;
  leafId: string | null;
  model: { provider: string; id: string };
  thinking: ReturnType<ExtensionAPI["getThinkingLevel"]>;
  tools: string[];
}
