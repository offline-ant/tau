import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as http from "node:http";
import * as net from "node:net";
import * as os from "node:os";
import * as path from "node:path";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";
import test, { type TestContext } from "node:test";
import { acquireClaim, createClaimTestEnvironment, lookupClaim, releaseClaim } from "@phimacs/pimux/ownership";
import { readProcessIdentity } from "@phimacs/pimux/process-identity";
import { writeDiscovery, type DiscoveryRecord } from "@phimacs/pimux/discovery";
import { prepareTauSwitch, prepareHerdrSwitch, shareTauSession, sharedMuxId, switchEnvironment, type SwitchSource } from "./switch-destinations.ts";

function source(t: TestContext): SwitchSource {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "pi-switch-transport-"));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  return { sessionFile: path.join(directory, "conversation.jsonl"), cwd: directory, args: [],
    env: switchEnvironment({ HOME: directory }), runtime: { protocol: 2, muxId: "mux-1" } };
}
async function tau(t: TestContext, handle: http.RequestListener) {
  const server = http.createServer(handle);
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  t.after(() => new Promise<void>((resolve) => { server.close(() => resolve()); server.closeAllConnections(); }));
  return `http://fixture-user:fixture-password@127.0.0.1:${(server.address() as net.AddressInfo).port}`;
}
function json(response: http.ServerResponse, data: unknown, status = 200) {
  response.writeHead(status, { "Content-Type": "application/json" }); response.end(JSON.stringify(data));
}
async function body(request: http.IncomingMessage) {
  let text = "";
  for await (const chunk of request) text += String(chunk);
  return JSON.parse(text) as Record<string, unknown>;
}

test("Tau switch uses only identity-bound attach, never resume/refresh/force, and redacts credentials", async (t) => {
  const session = source(t);
  const requests: Array<{ route: string; data: Record<string, unknown> }> = [];
  const endpoint = await tau(t, async (req, res) => {
    requests.push({ route: `${req.method} ${req.url}`, data: await body(req) });
    assert.equal(req.headers.authorization, `Basic ${Buffer.from("fixture-user:fixture-password").toString("base64")}`);
    json(res, { session: { id: "tab", attached: { muxId: "mux-1" } }, attached: true, started: true });
  });
  const opened: string[] = [];
  const prepared = await prepareTauSwitch(session, endpoint, async (url) => { opened.push(url); });
  assert.deepEqual(requests, []);
  const receipt = await prepared.start();
  assert.deepEqual(requests, [{ route: "POST /api/live-sessions/attach", data: { muxId: "mux-1" } }]);
  assert.equal(opened.length, 1);
  assert.match(receipt, /Shared with Tau tab tab/);
  assert.doesNotMatch(receipt, /fixture-user|fixture-password/);
});

test("reusing a Tau view is an attachment without reloading Pi", async (t) => {
  const endpoint = await tau(t, (_req, res) => json(res, { session: { id: "tab", attached: { muxId: "mux-1" } }, attached: true, started: false }));
  assert.match(await shareTauSession("mux-1", async () => {}, { endpoint, started: false }), /^Already shared with/);
});

for (const failure of ["disconnect", "bad-json", "wrong-runtime", "ownership", "unacknowledged"]) {
  test(`Tau ${failure} cannot trigger fallback or expose private response data`, async (t) => {
    const session = source(t);
    let requests = 0;
    const endpoint = await tau(t, (req, res) => {
      requests++;
      assert.equal(req.url, "/api/live-sessions/attach");
      if (failure === "disconnect") req.socket.destroy();
      else if (failure === "bad-json") res.end("fixture-password");
      else if (failure === "ownership") json(res, { error: "fixture-password" }, 409);
      else json(res, { session: { id: "tab", attached: { muxId: failure === "wrong-runtime" ? "other" : "mux-1" } }, attached: failure !== "unacknowledged" });
    });
    const prepared = await prepareTauSwitch(session, endpoint, async () => assert.fail("failed attachment opened browser"));
    await assert.rejects(prepared.start(), (error: unknown) => error instanceof Error && !/fixture-password/.test(error.message));
    assert.equal(requests, 1);
  });
}

test("native and unsupported transfers refuse before any daemon, workspace or network operation", async (t) => {
  const session = source(t);
  delete session.runtime;
  await assert.rejects(prepareTauSwitch(session, "http://127.0.0.1:1"), /No claim was released/);
  await assert.rejects(prepareHerdrSwitch(session, undefined, async () => assert.fail("native preflight ran")), /source cannot be made permanently unable to write/);
  await assert.rejects(prepareTauSwitch({ ...session, runtime: { protocol: 2, muxId: "mux-1" } }, "https://user:secret@example.org"), /local Tau/);
});

test("browser failure preserves confirmed attachment with a credential-free encoded manual link", async (t) => {
  const session = source(t);
  const endpoint = await tau(t, (_req, res) => json(res, { session: { id: "live /?#", attached: { muxId: "mux-1" } }, attached: true, started: true }));
  const prepared = await prepareTauSwitch(session, endpoint, async () => { throw new Error("fixture-password"); }, {
    endpoint, started: true, browserUrls: ["https://fixture-user:fixture-password@example.test:3443"],
  });
  const result = await prepared.start();
  assert.match(result, /Browser could not be opened/);
  assert.match(result, /https:\/\/example.test:3443\/#session=live%20%2F%3F%23/);
  assert.doesNotMatch(result, /fixture-user|fixture-password/);
});

test("a long-lived desktop opener does not delay or get killed after attachment", { timeout: 15_000, skip: process.platform === "win32" }, async (t) => {
  const session = source(t);
  const socketPath = path.join(session.cwd, "opener.sock");
  const server = net.createServer();
  await new Promise<void>((resolve) => server.listen(socketPath, resolve));
  let socket: net.Socket | undefined;
  const connected = new Promise<net.Socket>((resolve) => server.once("connection", (client) => { socket = client; resolve(client); }));
  t.after(() => { socket?.destroy(); server.close(); });
  const previousPath = process.env.PATH;
  const previousSocket = process.env.PI_SWITCH_OPENER_SOCKET;
  process.env.PATH = `${session.cwd}${path.delimiter}${previousPath || ""}`;
  process.env.PI_SWITCH_OPENER_SOCKET = socketPath;
  t.after(() => {
    if (previousPath === undefined) delete process.env.PATH; else process.env.PATH = previousPath;
    if (previousSocket === undefined) delete process.env.PI_SWITCH_OPENER_SOCKET; else process.env.PI_SWITCH_OPENER_SOCKET = previousSocket;
  });
  const quote = (text: string) => `'${text.replaceAll("'", `'"'"'`)}'`;
  fs.writeFileSync(path.join(session.cwd, process.platform === "darwin" ? "open" : "xdg-open"),
    `#!/bin/sh\nexec ${quote(process.execPath)} ${quote(fileURLToPath(new URL("./test/browser-opener-fixture.mjs", import.meta.url)))} "$@"\n`, { mode: 0o700 });
  const endpoint = await tau(t, (_req, res) => json(res, { session: { id: "long-lived", attached: { muxId: "mux-1" } }, attached: true, started: true }));
  const started = Date.now();
  const result = await (await prepareTauSwitch(session, endpoint)).start();
  assert.ok(Date.now() - started < 2_000);
  assert.doesNotMatch(result, /Browser could not be opened/);
  const client = await connected;
  const input = createInterface({ input: client });
  const received = input[Symbol.asyncIterator]();
  const info = JSON.parse((await received.next()).value!) as { pid: number; url: string };
  assert.match(info.url, /\/#session=long-lived$/);
  assert.equal((await received.next()).value, "survived");
  process.kill(info.pid, 0);
  client.write("finish\n");
  await new Promise<void>((resolve) => client.once("close", resolve));
  input.close();
});

test("source lookup requires this exact Pi claim and committed discovery, not just a claimed mux ID", (t) => {
  const sandbox = createClaimTestEnvironment();
  t.after(() => fs.rmSync(sandbox.root, { recursive: true, force: true }));
  const file = path.join(sandbox.sessions, "source.jsonl");
  fs.writeFileSync(file, "synthetic", { mode: 0o600 });
  const self = readProcessIdentity(process.pid)!;
  const handle = acquireClaim(file, { id: "mux-1", kind: "rpc", wrapper: self, pi: self, protocol: 2, socket: path.join(sandbox.root, "runtime.sock") }, sandbox.options);
  const discovery = path.join(sandbox.root, "runtime.json");
  const record: DiscoveryRecord = {
    protocol: 2, muxId: "mux-1", socket: handle.owner.socket!, pid: self.pid, piPid: self.pid, ownerIdentity: self, piIdentity: self,
    phase: "committed", cwd: sandbox.root, startedAt: "synthetic", updatedAt: "synthetic", status: "idle", blocked: null,
    session: { file, id: "source", name: null }, model: null, thinkingLevel: null, placement: "root", orchestration: null, parent: null,
  };
  writeDiscovery(discovery, record);
  const env = { ...sandbox.env, PHIMACS_MANAGED_CLAIM: JSON.stringify(handle), PIMUX_DISCOVERY: discovery };
  assert.equal(sharedMuxId(env, file), "mux-1");
  assert.equal(sharedMuxId({ PIMUX_DISCOVERY: discovery }, file), undefined, "discovery alone is not ownership");
  for (const changed of [{ ...record, protocol: 1 }, { ...record, phase: "provisional" as const }, { ...record, piPid: self.pid + 1 },
    { ...record, ownerIdentity: { ...self, startTime: `${BigInt(self.startTime) + 1n}` } }]) {
    writeDiscovery(discovery, changed);
    assert.throws(() => sharedMuxId(env, file), /ownership is unconfirmed/);
  }
  writeDiscovery(discovery, record);
  assert.throws(() => sharedMuxId({ ...env, PHIMACS_MANAGED_CLAIM: JSON.stringify({ ...handle, token: "wrong" }) }, file), /ownership is unconfirmed/);
  assert.equal(lookupClaim(file, sandbox.options)?.token, handle.token, "failed attachment does not release a live claim");
  assert.equal(fs.readFileSync(file, "utf8"), "synthetic");
  releaseClaim(handle);
});
