import * as path from "node:path";
import { fileURLToPath } from "node:url";
import { verifyHost, type HostIdentity } from "@phimacs/pimux/host";
import type { ProcessIdentity } from "@phimacs/pimux/process-identity";
import type { StartSpec } from "./host-types.ts";

/** No PATH lookup: an unmanaged Pi must explicitly select the candidate release. */
export function managedHost(env: NodeJS.ProcessEnv = process.env): HostIdentity {
  const command = env.PHIMACS_PI || (env.PHIMACS_MANAGED_CLAIM ? process.argv[1] : undefined);
  if (!command) throw new Error("Managed orchestration requires the release's absolute PHIMACS_PI executable; start Pi through the release launcher.");
  return verifyHost(command, { version: env.PHIMACS_PI_VERSION, sha256: env.PHIMACS_PI_SHA256 });
}

export function managedEnvironment(env: NodeJS.ProcessEnv = process.env): Record<string, string> {
  const host = managedHost(env);
  return { PHIMACS_PI: host.executable, PHIMACS_PI_VERSION: host.version, PHIMACS_PI_SHA256: host.sha256 };
}

export function managedPimuxExecutable(): string {
  return fileURLToPath(new URL("../bin/pimux", import.meta.resolve("@phimacs/pimux/main")));
}

/** Native hosts execute this argv verbatim; the wrapper claims before Pi opens. */
export function managedTerminalArgv(spec: Extract<StartSpec, { kind: "pi" }>, extensions: string[] = []): string[] {
  const host = managedHost({ ...process.env, ...spec.env });
  const bin = managedPimuxExecutable();
  if (!path.isAbsolute(spec.sessionFile)) throw new Error("Managed workers require an absolute session path");
  return [process.execPath, bin, "tui", "--", host.executable, "--session", spec.sessionFile, ...spec.args,
    ...extensions.flatMap((extension) => ["--extension", extension])];
}

export function processIdentity(value: unknown): ProcessIdentity | undefined {
  if (typeof value !== "object" || value === null) return undefined;
  const v = value as Record<string, unknown>;
  return Number.isSafeInteger(v.pid) && Number(v.pid) > 0 && typeof v.startTime === "string" && /^\d+$/.test(v.startTime)
    && typeof v.bootId === "string" && v.bootId.length > 0 ? v as unknown as ProcessIdentity : undefined;
}
