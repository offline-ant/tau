import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { parseSourceArchive, provision, provisionGrammars } from '../scripts/emacs-provision.mjs';

function tar(entries) {
  const records = [];
  for (const entry of entries) {
    const bytes = Buffer.from(entry.text ?? '');
    const header = Buffer.alloc(512);
    header.write(entry.name, 0, 100, 'utf8');
    header.write('0000644\0', 100, 8, 'ascii');
    header.write('0000000\0', 108, 8, 'ascii');
    header.write('0000000\0', 116, 8, 'ascii');
    header.write(bytes.length.toString(8).padStart(11, '0') + '\0', 124, 12, 'ascii');
    header.write('00000000000\0', 136, 12, 'ascii');
    header.fill(32, 148, 156);
    header.write(entry.type ?? '0', 156, 1, 'ascii');
    if (entry.link) header.write(entry.link, 157, 100, 'utf8');
    header.write('ustar\0', 257, 6, 'ascii');
    const checksum = header.reduce((sum, byte) => sum + byte, 0);
    header.write(checksum.toString(8).padStart(6, '0') + '\0 ', 148, 8, 'ascii');
    records.push(header, bytes, Buffer.alloc((512 - bytes.length % 512) % 512));
  }
  records.push(Buffer.alloc(1024));
  return zlib.gzipSync(Buffer.concat(records));
}

const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const revision = 'a'.repeat(40);
const archive = tar([{ name: 'example/LICENSE', text: 'Example license\n' }, { name: 'example/example.el', text: "(provide 'example)\n" }]);

async function writable(directory) {
  await fs.chmod(directory, 0o700);
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) if (entry.isDirectory()) await writable(path.join(directory, entry.name));
}

async function fixture(t, mutate = () => {}) {
  const temporary = await fs.mkdtemp(path.join(os.tmpdir(), 'phimacs-reference-provision-'));
  t.after(async () => { await writable(temporary); await fs.rm(temporary, { recursive: true }); });
  const lock = {
    schemaVersion: 1, emacsMinimum: '31.1', platforms: ['linux-x64'], builtins: { emacs: '31.1' },
    packages: [{ name: 'example', version: '1.0', revision, archivePrefix: 'example', url: 'https://source.invalid/archive.tar.gz', sha256: digest(archive), license: 'MIT', licenseFiles: ['LICENSE'], loadPaths: ['.'], requires: ['emacs'] }],
    native: {}, grammars: { api: 'pilish-install-essential-grammars', pilishRevision: revision, languages: ['markdown', 'markdown-inline'], sourceVersion: 'v0.5.4', sourceRevision: 'c'.repeat(40), abi: 15 },
  };
  mutate(lock);
  const inputsPath = path.join(temporary, 'inputs.json');
  await fs.writeFile(inputsPath, JSON.stringify(lock));
  return { temporary, destination: path.join(temporary, 'new-assets'), inputsPath, fetchBytes: async () => archive, platform: 'linux', arch: 'x64', native: false };
}

test('fresh locked sources are retained, extracted and sealed without home caches', async t => {
  const options = await fixture(t);
  const result = await provision(options);
  assert.equal(result.packages[0].revision, revision);
  assert.equal(result.packages[0].path, 'packages/example');
  assert.equal(result.native.status, 'not-selected');
  assert.equal(result.grammars.status, 'not-provisioned');
  const assets = path.join(options.destination, 'emacs');
  assert.equal(await fs.readFile(path.join(assets, 'packages/example/example.el'), 'utf8'), "(provide 'example)\n");
  assert.deepEqual(await fs.readFile(path.join(assets, `sources/example-${revision}.tar.gz`)), archive);
  assert.equal((await fs.stat(path.join(assets, 'packages/example'))).mode & 0o777, 0o555);
  assert.equal((await fs.stat(path.join(assets, 'packages/example/example.el'))).mode & 0o777, 0o444);
  assert.equal(JSON.parse(await fs.readFile(path.join(assets, 'provision.json'), 'utf8')).inputsSha256, result.inputsSha256);
});

test('existing destinations are refused before download and left intact', async t => {
  const options = await fixture(t);
  await fs.mkdir(options.destination);
  await fs.writeFile(path.join(options.destination, 'untouched'), 'keep');
  let requested = false;
  await assert.rejects(provision({ ...options, fetchBytes: async () => { requested = true; return archive; } }), /Destination already exists/);
  assert.equal(requested, false);
  assert.equal(await fs.readFile(path.join(options.destination, 'untouched'), 'utf8'), 'keep');
});

test('hash mismatch cleans only the new owned destination', async t => {
  const options = await fixture(t, lock => { lock.packages[0].sha256 = '0'.repeat(64); });
  await assert.rejects(provision(options), /SHA-256 mismatch/);
  await assert.rejects(fs.stat(options.destination), { code: 'ENOENT' });
  assert.ok(await fs.stat(options.inputsPath));
});

test('unsupported platform and unlocked transitive dependencies fail before writes', async t => {
  const options = await fixture(t);
  await assert.rejects(provision({ ...options, platform: 'darwin' }), /Unsupported.*platform/);
  await assert.rejects(fs.stat(options.destination), { code: 'ENOENT' });
  const missing = await fixture(t, lock => { lock.packages[0].requires.push('missing'); });
  await assert.rejects(provision(missing), /Unlocked dependency missing/);
});

test('missing licenses, revisions and required package load paths are refused', async t => {
  for (const [mutate, error] of [
    [lock => { lock.packages[0].license = 'REVIEW'; }, /Missing reviewed source license/],
    [lock => { lock.packages[0].revision = 'main'; }, /full immutable source revision/],
    [lock => { lock.packages[0].licenseFiles = ['MISSING']; }, /Missing locked license/],
    [lock => { lock.packages[0].loadPaths = ['missing']; }, /ENOENT/],
  ]) {
    const options = await fixture(t, mutate);
    await assert.rejects(provision(options), error);
    await assert.rejects(fs.stat(options.destination), { code: 'ENOENT' });
  }
});

test('unsafe paths, symlinks, hardlinks, duplicate files and corrupt headers never extract', () => {
  for (const entry of [
    { name: 'example/../../escape' },
    { name: '/example/absolute' },
    { name: 'example/dir\\escape' },
    { name: 'different/file' },
    { name: 'example/link', type: '2', link: '../../escape' },
    { name: 'example/link', type: '1' },
  ]) assert.throws(() => parseSourceArchive(tar([entry]), 'example'), /Unsafe|locked prefix|Unsupported/);
  assert.throws(() => parseSourceArchive(tar([{ name: 'example/a' }, { name: 'example/a' }]), 'example'), /Duplicate/);
  assert.throws(() => parseSourceArchive(tar([{ name: 'example/a' }, { name: 'example/a/b' }]), 'example'), /shadows/);
  const corrupt = zlib.gunzipSync(archive); corrupt[0] ^= 1;
  assert.throws(() => parseSourceArchive(zlib.gzipSync(corrupt), 'example'), /checksum/);
});

test('internal source links are materialized without creating filesystem symlinks', () => {
  const files = parseSourceArchive(tar([
    { name: 'example/CHANGELOG', type: '2', link: 'docs/changes' },
    { name: 'example/docs/changes', text: 'source history' },
  ]), 'example');
  assert.equal(files[0].data.toString(), 'source history');
  assert.throws(() => parseSourceArchive(tar([{ name: 'example/link', type: '2', link: 'missing' }]), 'example'), /Unresolved/);
  assert.throws(() => parseSourceArchive(tar([{ name: 'example/a', type: '2', link: 'b' }, { name: 'example/b', type: '2', link: 'a' }]), 'example'), /Cyclic/);
});

test('global PAX metadata is accepted but path overrides cannot escape the locked prefix', () => {
  const record = '52 comment=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n';
  assert.equal(Buffer.byteLength(record), 52);
  const withPax = tar([{ name: 'pax_global_header', type: 'g', text: record }, { name: 'example/example.el', text: 'ok' }]);
  assert.equal(parseSourceArchive(withPax, 'example')[0].path, 'example.el');
  const value = '../escape';
  let pax = `0 path=${value}\n`;
  for (let n = 0; n < 3; n++) pax = `${Buffer.byteLength(pax)} path=${value}\n`;
  assert.throws(() => parseSourceArchive(tar([{ name: 'pax', type: 'x', text: pax }, { name: 'example/file' }]), 'example'), /Unsafe/);
});

test('native bytes and source/license evidence are verified together', async t => {
  const nativeBytes = Buffer.from('synthetic native module');
  const options = await fixture(t, lock => {
    lock.native['linux-x64'] = { name: 'ghostel-module', version: '0.59.0', url: 'https://source.invalid/module', sha256: digest(nativeBytes), sources: [{ ...lock.packages[0], name: 'ghostel-source' }], redistributionReview: 'test-only synthetic module' };
  });
  const result = await provision({ ...options, native: true, fetchBytes: async url => url.endsWith('/module') ? nativeBytes : archive });
  const assets = path.join(options.destination, 'emacs');
  assert.equal(result.native.status, 'verified');
  assert.equal(result.native.sources[0].revision, revision);
  assert.equal(await fs.readFile(path.join(assets, 'ghostel/ghostel-module.version'), 'utf8'), '0.59.0\n');
  assert.deepEqual(await fs.readFile(path.join(assets, 'ghostel/ghostel-module.so')), nativeBytes);
  assert.equal(await fs.readFile(path.join(assets, 'ghostel/ghostel-source-LICENSE'), 'utf8'), 'Example license\n');
});

test('grammar phase invokes only public owning API in a fresh batch home', async t => {
  const options = await fixture(t);
  await provision(options);
  let invoked = false;
  const result = await provisionGrammars({ destination: options.destination, pilish: path.join(options.temporary, 'pinned-pilish'), spawn: (command, args, call) => {
    if (command === 'git') return { status: 0, stdout: args.includes('rev-parse') ? `${revision}\n` : '' };
    invoked = true;
    assert.equal(command, 'emacs');
    assert.ok(args.includes('-Q'));
    assert.match(args.at(-1), /pilish-install-essential-grammars/);
    assert.doesNotMatch(args.at(-1), /pilish--|treesit-language-source-alist/);
    assert.match(args.at(-1), /pilish-grammars\.el/);
    assert.notEqual(call.env.HOME, process.env.HOME);
    assert.ok(call.timeout > 0);
    // Fake owner API emits only synthetic artifacts, not personal grammar files.
    return { status: 1, stderr: 'Pinned Pilish lacks public pilish-install-essential-grammars' };
  } }).catch(error => error);
  assert.equal(invoked, true);
  assert.match(result.message, /lacks public/);
});

test('grammar corresponding source and license archives are retained before building', async t => {
  const options = await fixture(t, lock => { lock.grammars.correspondingSources = [{ ...lock.packages[0], name: 'grammar-source' }]; });
  const evidence = await provision(options);
  assert.equal(evidence.grammars.sources[0].revision, revision);
  assert.equal(evidence.grammars.sources[0].license, 'MIT');
  assert.deepEqual(await fs.readFile(path.join(options.destination, 'emacs', evidence.grammars.sources[0].archive)), archive);
});

test('native glibc version requirement is checked rather than implying musl support', async t => {
  const options = await fixture(t, lock => {
    lock.native['linux-x64'] = { name: 'ghostel-module', libc: { name: 'glibc', minimumVersion: '999.0' }, sources: [] };
  });
  await assert.rejects(provision({ ...options, native: true }), /requires glibc 999.0/);
  await assert.rejects(fs.stat(options.destination), { code: 'ENOENT' });
});

function owningReport(directory, contents = language => `synthetic-${language}`) {
  return JSON.stringify({ 'api-version': 1, 'emacs-version': '31.1', directory,
    grammars: ['markdown', 'markdown-inline'].map(language => ({ language,
      library: path.join(directory, `libtree-sitter-${language}.so`), sha256: digest(contents(language)),
      version: 'v0.5.4', revision: 'c'.repeat(40), abi: 15, 'source-directory': `tree-sitter-${language}/src` })) });
}

test('retained grammar-owner source does not inherit an enclosing Git repository', async t => {
  const options = await fixture(t, lock => { lock.grammars.pilishSourceSha256 = 'b'.repeat(64); });
  await provision(options);
  await fs.writeFile(path.join(options.temporary, '.phimacs-source.json'), JSON.stringify({ revision, sha256: 'b'.repeat(64) }));
  const result = await provisionGrammars({ destination: options.destination, pilish: options.temporary,
    spawn: command => {
      assert.notEqual(command, 'git');
      const output = path.join(options.destination, 'emacs/.grammar-provisioning/tree-sitter');
      for (const language of ['markdown', 'markdown-inline']) writeFileSync(path.join(output, `libtree-sitter-${language}.so`), `synthetic-${language}`);
      return { status: 0, stdout: owningReport(output) };
    } });
  assert.equal(result.status, 'verified');
});

test('grammar phase verifies source revision and commits both artifacts together', async t => {
  const options = await fixture(t);
  await provision(options);
  const fakeSpawn = (command, args) => {
    if (command === 'git') return { status: 0, stdout: args.includes('rev-parse') ? `${revision}\n` : '' };
    const output = path.join(options.destination, 'emacs/.grammar-provisioning/tree-sitter');
    mkdirSync(output, { recursive: true });
    for (const language of ['markdown', 'markdown-inline']) writeFileSync(path.join(output, `libtree-sitter-${language}.so`), `synthetic-${language}`);
    return { status: 0, stdout: owningReport(output), stderr: '' };
  };
  const result = await provisionGrammars({ destination: options.destination, pilish: options.temporary, spawn: fakeSpawn });
  assert.equal(result.status, 'verified');
  assert.equal(result.revision, revision);
  assert.equal(result.artifacts.length, 2);
  assert.equal(result.artifacts[0].abi, 15);
  assert.equal(result.artifacts[0].sourceRevision, 'c'.repeat(40));
  assert.equal(await fs.readFile(path.join(options.destination, 'emacs/tree-sitter/libtree-sitter-markdown.so'), 'utf8'), 'synthetic-markdown');
  const record = JSON.parse(await fs.readFile(path.join(options.destination, 'emacs/provision.json'), 'utf8'));
  assert.equal(record.grammars.status, 'verified');
  await assert.rejects(provisionGrammars({ destination: options.destination, pilish: options.temporary, spawn: fakeSpawn }), /already provisioned/);
});

test('wrong owning grammar ABI, source or checksum does not publish artifacts', async t => {
  for (const mutate of [report => { report.grammars[0].abi = 14; },
    report => { report.grammars[0].revision = 'd'.repeat(40); },
    report => { report.grammars[0].sha256 = '0'.repeat(64); }]) {
    const options = await fixture(t);
    await provision(options);
    await assert.rejects(provisionGrammars({ destination: options.destination, pilish: options.temporary,
      spawn: (command, args) => {
        if (command === 'git') return { status: 0, stdout: args.includes('rev-parse') ? `${revision}\n` : '' };
        const output = path.join(options.destination, 'emacs/.grammar-provisioning/tree-sitter');
        for (const language of ['markdown', 'markdown-inline']) writeFileSync(path.join(output, `libtree-sitter-${language}.so`), `synthetic-${language}`);
        const report = JSON.parse(owningReport(output));
        mutate(report);
        return { status: 0, stdout: JSON.stringify(report) };
      } }), /Owning grammar report mismatch/);
    assert.deepEqual(await fs.readdir(path.join(options.destination, 'emacs/tree-sitter')), []);
  }
});

test('grammar revision mismatch and incomplete output do not publish partial assets', async t => {
  const options = await fixture(t);
  await provision(options);
  const call = { destination: options.destination, pilish: options.temporary };
  await assert.rejects(provisionGrammars({ ...call, spawn: () => ({ status: 0, stdout: 'b'.repeat(40) }) }), /locked grammar-owner revision/);
  await assert.rejects(provisionGrammars({ ...call, spawn: (command, args) => {
    if (command === 'git') return { status: 0, stdout: args.includes('rev-parse') ? `${revision}\n` : '' };
    writeFileSync(path.join(options.destination, 'emacs/.grammar-provisioning/tree-sitter/libtree-sitter-markdown.so'), 'partial');
    return { status: 0, stdout: owningReport(path.join(options.destination, 'emacs/.grammar-provisioning/tree-sitter'), () => 'partial'), stderr: '' };
  } }), /did not provision required grammar markdown-inline/);
  assert.deepEqual(await fs.readdir(path.join(options.destination, 'emacs/tree-sitter')), []);
  await assert.rejects(fs.stat(path.join(options.destination, 'emacs/.grammar-provisioning')), { code: 'ENOENT' });
});
