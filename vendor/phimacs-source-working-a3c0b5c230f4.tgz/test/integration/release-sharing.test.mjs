import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { ReleaseRig, until } from '../support/release-rig.mjs';

const sourceOnly = !!process.env.PHIMACS_CLOSE_SOURCE_PREFIX;
if (sourceOnly && process.env.PHIMACS_RUNTIME_PREFIX) throw new Error('Select source-only regression or installed acceptance, not both');
const prefix = process.env.PHIMACS_CLOSE_SOURCE_PREFIX ?? process.env.PHIMACS_RUNTIME_PREFIX;
const skip = prefix ? false : 'Set PHIMACS_RUNTIME_PREFIX for installed acceptance or PHIMACS_CLOSE_SOURCE_PREFIX for explicit source-only regression';
const inputLabel = sourceOnly ? 'source-only (not installed acceptance)' : 'installed';
const createRig = () => ReleaseRig.create(prefix, { sourceOnly });
const quote = JSON.stringify;
const runtimeId = state => state.runtime['mux-id'];

async function attachBrowser(rig, sessionId) {
  await rig.navigate(rig.endpoint);
  await until(() => rig.evaluate(`!!document.querySelector('.live-tab[data-session-id="${sessionId}"]')`), 'Tau view in browser');
  await rig.click(`.live-tab[data-session-id="${sessionId}"]`);
  await until(() => rig.evaluate(`document.querySelector('.live-tab.active')?.dataset.sessionId === ${quote(sessionId)}`), 'selected Tau view');
}

function assertSameRuntime(state, receipt) {
  assert.equal(runtimeId(state), receipt.muxId);
  assert.equal(state.identity.pid, receipt.piPid);
  assert.equal(state.runtime['pi-pid'], receipt.piPid);
}

async function present(rig, text) {
  return until(() => rig.evaluate(`document.body.innerText.includes(${quote(text)})`), `browser text: ${text}`);
}

async function assertClosedViews(rig, name, sessionId) {
  const state = await until(async () => {
    const current = await rig.state(name);
    return !current.alive && current;
  }, 'authoritative closure removes Pilish chat');
  assert.equal(state.inputAlive, false, 'paired input is disposed too');
  assert.equal(state.tracked, false, 'closed agent is absent from the deck sidebar');
  assert.deepEqual(state.confirmations, [], 'Emacs Close never asks');
  await until(async () => !(await rig.api('/api/live-sessions')).data.sessions.some(item => item.id === sessionId), 'Tau removes the closed agent');
  if (rig.chromium?.exitCode === null && rig.chromium?.signalCode === null) {
    await until(() => rig.evaluate(`!document.querySelector('.live-tab[data-session-id="${sessionId}"]')`), 'Tau browser removes the closed agent');
  }
}

async function promptFromEmacs(rig, name, text) {
  await rig.el(`(release-host-prompt ${quote(name)} ${quote(text)})`);
  const state = await rig.settled(name);
  assert.equal(state.response.success, true);
  return state;
}

test(`${inputLabel} Emacs and phone Tau are symmetric, context-safe detached clients across restart and frontend rollback`, { skip, timeout: 540_000 }, async t => {
  const rig = createRig();
  t.diagnostic(`Synthetic namespace: ${rig.root}; input prefix: ${rig.release.prefix}; input status: ${rig.release.manifest.status}`);
  try {
    await rig.startTau();
    await rig.startEmacs();
    await rig.browser();

    // A real public Pilish start, not an independent socket pretending to be Emacs.
    await rig.el('(release-host-create "emacs-origin")');
    let emacs = await rig.live('emacs-origin');
    const originalIdentity = emacs.identity;
    const entry = (await rig.list()).find(item => item.muxId === runtimeId(emacs));
    assert.ok(entry && entry.phase === 'committed');
    const attached = await rig.api('/api/live-sessions/attach', { muxId: entry.muxId });
    assert.equal(attached.status, 200, JSON.stringify(attached.data));
    let view = attached.data.session;
    assertSameRuntime(emacs, view.runtime);
    await attachBrowser(rig, view.id);

    await promptFromEmacs(rig, 'emacs-origin', 'Emacs sends exactly once');
    await present(rig, 'release reply: Emacs sends exactly once');
    await rig.compose('phone sends exactly once');
    await until(async () => (await rig.state('emacs-origin')).text.includes('release reply: phone sends exactly once'), 'phone prompt renders in real Pilish');
    await present(rig, 'release reply: phone sends exactly once');
    const peer = await rig.peer(view.runtime);
    const initialMessages = await peer.request({ type: 'get_messages' });
    for (const text of ['Emacs sends exactly once', 'phone sends exactly once']) {
      assert.equal(initialMessages.data.messages.filter(message => message.role === 'user' && JSON.stringify(message.content).includes(text)).length, 1);
    }

    // One dialog is visible in both frontends; the real phone control wins once.
    const dialogStart = peer.records.length;
    await rig.el('(release-host-prompt "emacs-origin" "/release-select")');
    const dialog = await peer.wait(record => record.type === 'extension_ui_request' && record.method === 'select', 'shared dialog', dialogStart);
    await until(async () => (await rig.state('emacs-origin')).dialogs.length === 1, 'Pilish public pending dialog');
    await present(rig, 'Release choice');
    await rig.click('.dialog-option');
    await peer.wait(record => record.type === 'pimux_dialog_closed' && record.id === dialog.id, 'first-answer closure', dialogStart);
    await peer.wait(record => record.type === 'extension_ui_request' && record.message === 'release picked:first', 'winning dialog result', dialogStart);
    peer.send({ type: 'extension_ui_response', id: dialog.id, value: 'second' });
    await until(async () => (await rig.state('emacs-origin')).dialogs.length === 0, 'Pilish authoritative dialog close');
    assert.equal(peer.records.slice(dialogStart).filter(record => record.type === 'extension_ui_request' && String(record.message).startsWith('release picked:')).length, 1);

    await rig.rpc(view.id, { type: 'set_model', provider: 'release-faux-slow', modelId: 'one' });
    await until(async () => (await rig.state('emacs-origin')).model.provider === 'release-faux-slow', 'authoritative cross-frontend model change');
    await rig.el('(release-host-prompt "emacs-origin" "stream 100")');
    await peer.wait(record => record.type === 'message_update' && JSON.stringify(record).includes('word'), 'live streaming');
    await rig.compose('phone steering while streaming');
    await until(async () => (await rig.state('emacs-origin')).text.includes('release reply: phone steering while streaming'), 'steering accepted by same Pi', 60_000);
    await until(async () => !(await rig.state('emacs-origin')).busy, 'stream and steering settled', 60_000);
    await present(rig, 'release reply: phone steering while streaming');
    await rig.rpc(view.id, { type: 'set_model', provider: 'release-faux', modelId: 'two' });
    await until(async () => (await rig.state('emacs-origin')).model.id === 'two', 'second model selection');

    // Bootstrap is an authoritative flat-entry generation; no mixed disk history.
    const generation = peer.records.filter(record => record.type === 'pimux_snapshot').at(-1).generation;
    const mark = peer.records.length;
    await peer.request({ type: 'pimux_bootstrap', include: ['entries', 'messages'] });
    const snapshot = await peer.wait(record => record.type === 'pimux_snapshot' && record.generation > generation, 'new exact snapshot generation', mark);
    assert.ok(Array.isArray(snapshot.entries));
    assert.equal(snapshot.session.file, (await rig.state('emacs-origin')).file);
    await peer.wait(record => record.type === 'pimux_live' && record.generation === snapshot.generation, 'matching snapshot live boundary', mark);

    // A held provider makes global queue clear deterministic. Neither local
    // recovery nor a failed confirmation is permitted to submit anything.
    await rig.el('(release-host-prompt "emacs-origin" "hold queued")');
    await until(async () => (await rig.state('emacs-origin')).busy, 'held run busy');
    await rig.rpc(view.id, { type: 'prompt', message: 'queued shared follow-up', streamingBehavior: 'followUp' });
    await rig.rpc(view.id, { type: 'prompt', message: 'queued shared steering', streamingBehavior: 'steer' });
    await until(async () => (await rig.state('emacs-origin')).queued?.length >= 2, 'shared queue visible in Pilish');
    const queueContext = await rig.inputContext(view.id);
    const unconfirmed = await rig.api('/api/rpc', { type: 'clear_queue', sessionId: view.id, inputContext: queueContext });
    assert.equal(unconfirmed.data.success, false);
    assert.match(unconfirmed.data.error, /explicit confirmation/);
    const cleared = await rig.rpc(view.id, { type: 'clear_queue', confirmGlobal: true });
    assert.ok(JSON.stringify(cleared.data).includes('queued shared follow-up'));
    assert.ok(JSON.stringify(cleared.data).includes('queued shared steering'));
    await until(async () => !(await rig.state('emacs-origin')).queued?.length, 'global removal reaches peer');
    assert.ok(!(await rig.state('emacs-origin')).quarantine.some(item => JSON.stringify(item).includes('queued shared follow-up')), 'requester-only queue recovery is not falsely broadcast to Emacs');
    fs.writeFileSync(path.join(rig.env.PHIMACS_RELEASE_HOLD, 'queued'), 'released');
    await until(async () => !(await rig.state('emacs-origin')).busy, 'held run released');
    const afterClear = await peer.request({ type: 'get_messages' });
    assert.ok(!afterClear.data.messages.some(message => message.role === 'user' && JSON.stringify(message.content).includes('queued shared')));

    // Both a real same-file branch move and a file replacement quarantine drafts.
    await rig.el('(release-host-draft "emacs-origin" "draft bound to previous branch")');
    const history = await rig.api(`/api/live-sessions/${view.id}/snapshot`);
    assert.equal(history.status, 200);
    const target = history.data.entries.find(item => item.message?.role === 'user');
    assert.ok(target);
    await rig.rpc(view.id, { type: 'prompt', message: `/release-tree ${target.id}` });
    await until(async () => (await rig.state('emacs-origin')).quarantine.some(item => JSON.stringify(item).includes('draft bound to previous branch')), 'same-file branch draft quarantined');
    await rig.el('(release-host-draft "emacs-origin" "draft bound to previous file")');
    await rig.compose('phone draft bound to previous file', false);
    const previousFile = (await rig.state('emacs-origin')).file;
    await rig.rpc(view.id, { type: 'new_session' });
    emacs = await until(async () => { const state = await rig.state('emacs-origin'); return state.file !== previousFile && state; }, 'cross-file authoritative adoption');
    assert.equal(emacs.draft, '');
    assert.ok(emacs.quarantine.some(item => JSON.stringify(item).includes('draft bound to previous file')));
    await until(() => rig.evaluate('document.querySelector("#message-input").value === ""'), 'phone composer not reused after file change');
    assertSameRuntime(emacs, view.runtime);

    // Save local-only input, then lose every UI while an accepted run completes.
    const saved = path.join(rig.root, 'desktop.eld');
    await rig.el('(release-host-draft "emacs-origin" "persisted unsent input")');
    await rig.el(`(release-host-save "emacs-origin" ${quote(saved)})`);
    await rig.rpc(view.id, { type: 'prompt', message: 'hold zero-clients' });
    await until(async () => (await rig.state('emacs-origin')).busy, 'accepted work before disconnect');
    peer.close();
    rig.cdp.close();
    await rig.stopChild(rig.chromium);
    await rig.stopEmacs();
    await rig.stopChild(rig.tau);
    assert.equal(rig.identities.processIdentityStatus(entry.piIdentity), 'alive');
    fs.writeFileSync(path.join(rig.env.PHIMACS_RELEASE_HOLD, 'zero-clients'), 'released');
    await until(async () => (await rig.list()).find(item => item.muxId === entry.muxId)?.status === 'idle', 'zero-client accepted work completes');

    // A copied frontend release can reconnect; the existing runtime stays on its
    // original code. Restoring the original frontend is a real rollback rehearsal.
    const upgraded = await rig.copyPrefix('upgrade');
    await rig.startEmacs(upgraded);
    await rig.el(`(release-host-restore "upgraded" ${quote(saved)})`);
    let restored = await rig.live('upgraded');
    assert.deepEqual(restored.identity, originalIdentity);
    assert.equal(restored.draft, 'persisted unsent input');
    assert.ok((await rig.list()).find(item => item.muxId === entry.muxId).host.executable.startsWith(rig.release.prefix + path.sep));
    await rig.el(`(release-host-save "upgraded" ${quote(saved)})`);
    await rig.stopEmacs();
    await rig.startEmacs();
    await rig.el(`(release-host-restore "rollback" ${quote(saved)})`);
    restored = await rig.live('rollback');
    assert.deepEqual(restored.identity, originalIdentity);
    await rig.startTau();
    const reattached = await rig.api('/api/live-sessions/attach', { muxId: entry.muxId });
    assert.equal(reattached.status, 200, JSON.stringify(reattached.data));
    view = reattached.data.session;
    assertSameRuntime(restored, view.runtime);
    await rig.browser();
    await attachBrowser(rig, view.id);
    const back = await rig.peer(view.runtime);
    const messages = (await back.request({ type: 'get_messages' })).data.messages;
    assert.equal(messages.filter(message => message.role === 'user' && JSON.stringify(message.content).includes('hold zero-clients')).length, 1);
    assert.ok(!messages.some(message => message.role === 'user' && JSON.stringify(message.content).includes('persisted unsent input')));
    assert.equal((await rig.list()).length, 1, 'view restarts must not create a runtime');

    // Unsupported saved protocol refuses attachment and preserves a recoverable
    // view. A live owner is never replaced merely because its client mismatches.
    await rig.el('(release-host-disconnect "rollback")');
    await rig.el(`(release-host-restore "unsupported" ${quote(saved)} 1)`);
    const unsupported = await rig.state('unsupported');
    assert.equal(unsupported.runtime.state, 'unavailable');
    assert.equal((await rig.list()).length, 1);
    await rig.el('(release-host-disconnect "unsupported")');
    await rig.el(`(release-host-restore "stop-view" ${quote(saved)})`);
    await rig.live('stop-view');
    const stopped = await rig.api(`/api/live-sessions/${view.id}/stop`, { operationId: 'release-unconfirmed-close' });
    assert.equal(stopped.status, 200, JSON.stringify(stopped.data));
    assert.equal(stopped.data.receipt.state, 'stopped');
    await back.wait(record => record.type === 'pimux_exit', 'explicit stop reaches equal peer');
    assert.equal(rig.identities.processIdentityStatus(entry.piIdentity), 'dead');
    const repeatedStop = await rig.api(`/api/agents/${entry.muxId}/stop`, { operationId: 'release-reconcile-close' });
    assert.equal(repeatedStop.status, 200, JSON.stringify(repeatedStop.data));
    assert.deepEqual(repeatedStop.data.receipt, stopped.data.receipt);
    await assertClosedViews(rig, 'stop-view', view.id);
    await rig.el(`(release-host-restore "closed" ${quote(saved)})`);
    assert.equal((await rig.state('closed')).alive, false, 'authoritatively closed saved identity restores nil');
    assert.equal((await rig.list()).length, 0, 'closed desktop restoration never creates a writer');
    assert.deepEqual(rig.javascriptDialogs, []);

    t.diagnostic(`Passed (${inputLabel}): Emacs-origin sharing, real phone controls, streaming/steering/dialog/model, exact generations, shared queue recovery, branch/file drafts, zero clients, both frontend restarts, copied frontend reconnect/rollback, unsupported owner refusal, unconfirmed idempotent Close and offline closed-view omission.`);
  } catch (error) {
    rig.failure = error;
    throw error;
  } finally {
    await rig.cleanup();
  }
});

test(`${inputLabel} Tau creates an agent that real Pilish attaches mid-tool and deck closes everywhere`, { skip, timeout: 240_000 }, async t => {
  const rig = createRig();
  t.diagnostic(`Synthetic namespace: ${rig.root}; input status: ${rig.release.manifest.status}`);
  try {
    await rig.startTau();
    await rig.startEmacs();
    const created = await rig.api('/api/live-sessions', { cwd: rig.env.PHIMACS_RELEASE_PROJECT, model: 'release-faux/one', args: [
      '--no-extensions', '--no-skills', '--no-context-files', '--no-prompt-templates', '--extension', rig.env.PHIMACS_RELEASE_FAUX,
    ] });
    assert.equal(created.status, 200, JSON.stringify(created.data));
    const view = created.data.session;
    assert.equal(view.runtime.outcome, 'started');
    await rig.rpc(view.id, { type: 'prompt', message: 'release tool' });
    const peer = await rig.peer(view.runtime);
    await peer.wait(record => record.type === 'tool_execution_start' || (record.type === 'pimux_snapshot' && record.run?.active), 'mid-tool attachment snapshot');
    await rig.el(`(release-host-attach ${quote(view.runtime.muxId)} "tau-origin")`);
    const state = await rig.live('tau-origin');
    assertSameRuntime(state, view.runtime);
    assert.equal(state.busy, true);
    await rig.api(`/api/live-sessions/${view.id}`, undefined, 'DELETE');
    fs.writeFileSync(path.join(rig.env.PHIMACS_RELEASE_HOLD, 'tool'), 'released');
    await until(async () => (await rig.state('tau-origin')).text.includes('release tool completed'), 'tool completion survives creating Tau view loss');
    await promptFromEmacs(rig, 'tau-origin', 'Pilish continues Tau-created root');
    assert.equal((await rig.list()).length, 1);
    const reattached = await rig.api('/api/live-sessions/attach', { muxId: view.runtime.muxId });
    assert.equal(reattached.status, 200, JSON.stringify(reattached.data));
    await rig.browser();
    await attachBrowser(rig, reattached.data.session.id);
    await until(async () => (await rig.state('tau-origin')).tracked, 'real deck agent registration');
    await rig.el('(release-host-close "tau-origin" t)');
    await peer.wait(record => record.type === 'pimux_exit', 'deck Close reaches every socket peer');
    await assertClosedViews(rig, 'tau-origin', reattached.data.session.id);
    assert.equal((await rig.list()).length, 0);
    assert.deepEqual(rig.javascriptDialogs, []);
    t.diagnostic('Passed: Tau-origin real mid-tool Pilish attach, creating-view loss, continuation and unconfirmed deck Close removes every active view.');
  } catch (error) {
    rig.failure = error;
    throw error;
  } finally {
    await rig.cleanup();
  }
});

test(`${inputLabel} unconfirmed Close from either frontend removes idle, busy and dialog-blocked agents everywhere`, { skip, timeout: 360_000 }, async t => {
  const rig = createRig();
  t.diagnostic(`Synthetic namespace: ${rig.root}; input status: ${rig.release.manifest.status}; Emacs binary: ${process.env.PHIMACS_TEST_EMACS ?? 'emacs'}`);
  try {
    await rig.startTau();
    await rig.startEmacs();
    await rig.browser();
    for (const frontend of ['tau', 'emacs']) {
      for (const phase of ['idle', 'busy', 'dialog']) {
        const name = `close-${frontend}-${phase}`;
        await rig.el(`(release-host-create ${quote(name)})`);
        const emacs = await rig.live(name);
        const entry = (await rig.list()).find(item => item.muxId === runtimeId(emacs));
        const attached = await rig.api('/api/live-sessions/attach', { muxId: entry.muxId });
        assert.equal(attached.status, 200, JSON.stringify(attached.data));
        const view = attached.data.session;
        await attachBrowser(rig, view.id);
        const peer = await rig.peer(view.runtime);
        const saved = path.join(rig.root, `${name}.eld`);
        await rig.el(`(release-host-save ${quote(name)} ${quote(saved)})`);
        await until(async () => (await rig.state(name)).tracked, 'candidate deck tracks the live agent');
        if (phase === 'busy') {
          await rig.el(`(release-host-prompt ${quote(name)} ${quote(`hold ${name}`)})`);
          await until(async () => (await rig.state(name)).busy, 'busy agent before Close');
        } else if (phase === 'dialog') {
          await rig.el(`(release-host-prompt ${quote(name)} "/release-select")`);
          await peer.wait(record => record.type === 'extension_ui_request' && record.method === 'select', 'blocked agent before Close');
          await until(async () => (await rig.state(name)).dialogs.length === 1, 'Pilish shows the same open dialog');
          await present(rig, 'Release choice');
        }
        if (frontend === 'tau') {
          await rig.click(`.live-tab[data-session-id="${view.id}"] .live-tab-close`);
        } else {
          await rig.el(`(release-host-close ${quote(name)} t)`);
        }
        await peer.wait(record => record.type === 'pimux_exit', 'actual Pi exit reaches equal client');
        await assertClosedViews(rig, name, view.id);
        assert.equal(rig.identities.processIdentityStatus(entry.piIdentity), 'dead');
        await rig.el(`(release-host-restore ${quote(`${name}-offline`)} ${quote(saved)})`);
        assert.equal((await rig.state(`${name}-offline`)).alive, false, 'saved closed identity is omitted, not resumed');
        assert.equal((await rig.list()).length, 0);
        assert.deepEqual(rig.javascriptDialogs, [], 'Close never opens a browser confirmation');
        peer.close();
      }
    }
    t.diagnostic('Passed six real-Pi/faux Close directions/phases, global buffer/sidebar/tab removal, zero confirmation dialogs and offline closed-view omission.');
  } catch (error) {
    rig.failure = error;
    throw error;
  } finally {
    await rig.cleanup();
  }
});
