import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { releasePaths, cleanEnvironment, until } from '../support/release-rig.mjs';

function fixture(t) {
  const prefix = fs.mkdtempSync(path.join(os.tmpdir(), 'phimacs-release-contract-'));
  t.after(() => fs.rmSync(prefix, { recursive: true, force: true }));
  const manifest = { runtime: { pimuxProtocol: 2, detachedTargetImplemented: true },
    pi: { executable: 'node_modules/host/pi', version: '1.4.0', sha256: 'a'.repeat(64) } };
  fs.writeFileSync(path.join(prefix, 'release-manifest.json'), JSON.stringify(manifest));
  for (const relative of ['node_modules/host/pi', 'node_modules/@phimacs/pimux/bin/pimux', 'node_modules/.bin/phimacs-task-status',
    'node_modules/pi-tau-web-server/bin/tau.js', 'forks/pilish/pilish.el',
    'forks/pilish/scripts/pilish-storage.mjs', 'assets/emacs/provision.json', 'lisp/pi-deck/pi-deck.el']) {
    const file = path.join(prefix, relative);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, 'contract fixture only');
  }
  return { prefix, manifest };
}

test('release harness requires absolute complete protocol-2 installed inputs', t => {
  assert.throws(() => releasePaths(), /absolute complete installed release/);
  assert.throws(() => releasePaths('./source'), /absolute complete installed release/);
  const { prefix, manifest } = fixture(t);
  assert.equal(releasePaths(prefix).pilish, path.join(prefix, 'forks/pilish'));
  fs.writeFileSync(path.join(prefix, 'INCOMPLETE'), 'not installed');
  assert.throws(() => releasePaths(prefix), /Incomplete release/);
  fs.unlinkSync(path.join(prefix, 'INCOMPLETE'));
  manifest.runtime.pimuxProtocol = 1;
  fs.writeFileSync(path.join(prefix, 'release-manifest.json'), JSON.stringify(manifest));
  assert.throws(() => releasePaths(prefix), /phase-b prefixes/);
});

test('release harness rejects source-path escape and missing fork helper', t => {
  const { prefix, manifest } = fixture(t);
  manifest.externalForks = { pilish: { directory: '../private-sibling' } };
  fs.writeFileSync(path.join(prefix, 'release-manifest.json'), JSON.stringify(manifest));
  assert.throws(() => releasePaths(prefix), /escapes/);
  manifest.externalForks.pilish.directory = 'forks/pilish';
  fs.writeFileSync(path.join(prefix, 'release-manifest.json'), JSON.stringify(manifest));
  fs.unlinkSync(path.join(prefix, 'forks/pilish/scripts/pilish-storage.mjs'));
  assert.throws(() => releasePaths(prefix), /pilish-storage/);
});

test('source-only Close inputs cannot be mistaken for installed acceptance', t => {
  const { prefix, manifest } = fixture(t);
  assert.throws(() => releasePaths(prefix, { sourceOnly: true }), /explicit source mode/);
  manifest.status = 'source-only-close-regression';
  fs.writeFileSync(path.join(prefix, 'release-manifest.json'), JSON.stringify(manifest));
  assert.throws(() => releasePaths(prefix), /cannot establish installed acceptance/);
  const selected = releasePaths(prefix, { sourceOnly: true });
  assert.equal(selected.sourceOnly, true);
  assert.equal(selected.taskStatus, path.join(prefix, 'node_modules/.bin/phimacs-task-status'));
  fs.unlinkSync(selected.taskStatus);
  assert.throws(() => releasePaths(prefix, { sourceOnly: true }), /phimacs-task-status/);
});

test('release child environment does not inherit credentials, hosts or user discovery', () => {
  const previous = { ...process.env };
  Object.assign(process.env, { OPENAI_API_KEY: 'synthetic-secret', CLAUDE_CONFIG_DIR: '/no-user-account',
    PIMUX_DIR: '/no-production-discovery', PI_ORCHESTRATION_ENDPOINT: '/no-user-daemon',
    TAU_PASS: 'no-user-password', DISPLAY: ':0', NODE_OPTIONS: '--no-expose-wasm' });
  try {
    const root = '/tmp/phimacs-test-contract';
    const env = cleanEnvironment({ root, sessions: root + '/sessions', env: { PHIMACS_TEST_ROOT: root, PIMUX_DIR: root + '/mux' } }, {
      prefix: '/synthetic-release', pi: '/synthetic-release/pi', pimux: '/synthetic-release/pimux',
      pilish: '/synthetic-release/pilish', taskStatus: '/synthetic-release/task-status', assets: '/synthetic-release/assets', manifest: { pi: { version: '1.4.0', sha256: 'x' } },
    });
    for (const key of ['OPENAI_API_KEY', 'CLAUDE_CONFIG_DIR', 'PI_ORCHESTRATION_ENDPOINT', 'TAU_PASS', 'DISPLAY', 'NODE_OPTIONS']) assert.equal(env[key], undefined);
    assert.equal(env.PIMUX_DIR, root + '/mux');
    assert.equal(env.HOME, root + '/home');
    assert.equal(env.PI_CODING_AGENT_SESSION_DIR, root + '/sessions');
    assert.equal(env.PHIMACS_RELEASE_TASK_STATUS, '/synthetic-release/task-status');
  } finally {
    for (const key of Object.keys(process.env)) if (!(key in previous)) delete process.env[key];
    Object.assign(process.env, previous);
  }
});

test('readiness polling returns the actual event and has an actionable bound', async () => {
  assert.equal(await until(() => 'event', 'already ready', 100), 'event');
  await assert.rejects(until(() => false, 'synthetic impossible readiness', 1), /Timed out: synthetic impossible readiness/);
});
