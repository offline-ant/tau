# Cross-package integration tests

Tests that combine general extensions with orchestration belong here rather than
inside either runtime package. Tests import orchestration's declared public
contracts; `../support/orchestration.ts` exposes fixture and worker implementation
details to this test tree only. It is not a runtime package export. Production
packages and artifacts must not contain `test/support`.

After dependency hydration and compilation, run from the repository root:

```sh
node scripts/test.mjs test/integration/ask.test.ts test/integration/error-prompt.test.ts test/integration/self-compact.test.ts
node scripts/test.mjs test/integration/herdr-finish-native.test.ts test/integration/switch-native.test.ts test/integration/switch-emacs-native.test.ts test/integration/take-native.test.ts
```

The first command uses synthetic inference. The second verifies imports and
reports native lanes skipped unless their existing opt-in flags are selected.
Do not count skipped native lanes as passing end-to-end evidence.

## Shared frontend Close regression

`release-sharing.test.mjs` exercises real Pilish/deck and phone-sized Tau with
synthetic inference, including unconfirmed global Close from both frontends and
frontend-shutdown survival. The [owning harness guide](../../docs/release-acceptance-harness.md)
distinguishes final installed-release acceptance from explicit source-only inputs
and documents its isolated display and cleanup requirements.

## Native candidate inputs

Native tests retain their `PI_HERDR_FINISH_NATIVE`, `PI_SWITCH_NATIVE`,
`PI_SWITCH_EMACS_NATIVE` and `PI_TAKE_NATIVE` opt-ins. They use compiled extension
assets from this tree and explicit acquired inputs rather than sibling checkouts
or the user's home caches:

- `PI_TEST_TAU_ENTRY`: absolute path to the selected compiled Tau candidate.
  Switch tests verify that the CLI selected on PATH resolves to this exact entry.
- `PI_TEST_HERDR_INTEGRATION`: absolute path to the selected generic Herdr Pi
  integration, for native finish/take lanes.
- `PI_EMACS_ELPA`, `PI_EMACS_PILISH`, `PI_EMACS_GHOSTEL_MODULE`,
  `PI_EMACS_GRAMMARS`: absolute candidate package, fork and provisioned asset
  directories, for native Emacs switching.

The caller must supply isolated HOME/agent/session/temporary/discovery namespaces
and candidate executables on PATH before enabling native lanes. Fixed per-user
session-take and other runtime registries additionally require a separate test
UID or equivalent isolated user/filesystem sandbox. A private Emacs socket alone
is insufficient. No command above authorizes controlling existing user targets,
restarting services or submitting paid inference.
