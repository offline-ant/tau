# Fresh reference provisioning and installed-path startup evidence

## Locked inputs and release paths

`emacs/inputs.json` locks 29 public Lisp source archives, complete selected native
build-graph sources, notices, load paths and immutable hashes. No home or package-
manager cache, mutable package index, personal configuration or account state is
an input.
Emacs 31.1 supplies the declared built-in dependencies. The provisioner seals
installed sources/assets read-only and refuses an existing destination.

```sh
node scripts/emacs-provision.mjs --destination /new/versioned-assets
node scripts/emacs-provision.mjs --grammars --destination /new/versioned-assets \
  --pilish /pinned/source
```

The second phase invokes only the public
`pilish-install-essential-grammars(directory)` API. Its owning candidate is
`27fba473989ebe84241a9715d6df7491e3a0904b`, rebased on upstream
`3e7a884089faf3a3ab8ec73e3a1a057b92a756b2` (Pilish 3.4.2); retained-source archive
SHA-256 is `a3fb809d77936826b0f179a282784adfb537ff1c89496e0daaed1392c53f539f`.
The lock verifies all 24 selected top-level Lisp sources, including
`pilish-conversations.el`, and the runtime asset `scripts/pilish-storage.mjs`,
not merely self-asserted source metadata. The full retained fork archive must be
unpacked, including its scripts directory.

Pilish 3.4.2 still requires Emacs 29.1, Transient 0.9.0, magit-section 4.0.0,
md-ts-mode 0.5.0 and markdown-table-wrap 0.2.0. The selected Emacs 31.1/Transient
0.13.3, magit-section 4.7.1, md-ts-mode 0.5 and markdown-table-wrap 0.2.0 satisfy
these minima; the 29 Lisp and 11 native source selections are unchanged.

A new complete provision run rehashed the previous audited candidate's retained
source archives and Ghostel binary: 29 Lisp archives, 11 native archives, one
Markdown archive and the binary (42 acquired inputs). It freshly extracted Lisp
sources/notices and generated a new receipt bound to the changed lock; no old
receipt, installed Lisp, home cache or existing grammar binary was substituted.
The owning installer then rebuilt both grammars from the newly extracted pinned
Pilish source.

| Complete fresh input | SHA-256 |
|---|---|
| `emacs/inputs.json` | `9095a5157ebeb1405c69d59035e84379a21a90d929732c6def1c69b7942c34a2` |
| `emacs/provision.json` | `93bc24fe43340143e9f71516e1f9741ae56554347b49f4909ae001821e7b4be5` |
| Complete `emacs-assets.tar.gz` | `62726218194e8a0e1bca9f3772af1b21b8c6ae57183750ffc6eac2c0af3411bc` |

Release packers must retain:

```text
release/
  release-manifest.json
  node_modules/                 # hydrated exact host and selected packages
  lisp/pi-deck/                  # complete deck Lisp/assets
  lisp/pilish/                   # complete pinned corresponding fork source
    .phimacs-source.json         # revision + retained archive SHA-256
    scripts/pilish-storage.mjs
  emacs/config/                 # complete optional reference init/Lisp/license
  emacs/inputs.json              # build/provisioning lock
  scripts/emacs-*.mjs            # launcher, environment, setup, doctor/provisioner
assets/emacs/
  inputs.json                   # exact lock used, bound by inputsSha256
  provision.json
  packages/<name>/
  ghostel/ghostel-module.so
  ghostel/ghostel-module.version
  ghostel/<source>-<notice>
  tree-sitter/libtree-sitter-{markdown,markdown-inline}.so
  sources/<name>-<full-revision>.tar.gz
```

The assets directory may be included under the release or selected explicitly.
Its complete contents and corresponding archives must travel together. Ordinary
startup, package-only configuration and doctor never provision missing assets.

## Essential grammars: fresh actual build

The public owning installer built exactly Markdown and Markdown-inline using
**v0.5.4**, immutable source
`41ff24a6c775492c543b09228aeb98d1cd2b3a0f`, and validated both as **ABI 15** in a
fresh Emacs subprocess with absolute library overrides. Its report is validated
before installation: API version, destination, language set, source revision,
version, ABI and actual generated SHA-256 must match. No private recipe/helper,
optional language, home grammar or existing-system grammar is substituted.

| Generated artifact | SHA-256 |
|---|---|
| `libtree-sitter-markdown.so` | `d734d4556d58b9844445db9588365aef2d08da64aacfa20d5ff48624ce20c77d` |
| `libtree-sitter-markdown-inline.so` | `ffa69c844a935a3d11e7899e8c38a57694a651b64a1557d1226a05dbd6abd6f3` |
| Corresponding Markdown source archive | `9c668799d2969350ff957fa2ed5d2dc557432863193b166c8808a87615ec5596` |

`provision.json.grammars` records the owning fork/API/Emacs version, source
archives and relative generated artifact paths, hashes and ABI. Incomplete,
changed or wrong-owner reports do not publish the grammar directory. Abrupt
interruption leaves an operation for inspected recovery rather than startup
reclaiming uncertain work.

## Native source closure and remaining provenance gate

The independently downloaded **Ghostel 0.59.0** module has SHA-256
`6062a340ad850a0ce72a48ef4e21cb09133fde47c39f3660a6774f5e28bd0e02`.
It loaded in fresh batch, GUI and terminal Emacs. This prebuilt is Linux x86-64
**glibc 2.34+**, not musl; the recorded target is `x86_64-linux-gnu.2.35`.

Eleven retained source archives cover Ghostel, Ghostty, uucode, Highway, exact
Wuffs generated/preferred sources, pixel fixtures, actual simdutf 9.0.0 preferred
source, translate-c, Aro and Zig 0.16.0 runtime/compiler support. Per-file GNU,
MIT, Apache/BSD, Unicode and other included notices remain in their complete
sources. Wuffs preferred generation matches the compiled mirror; simdutf's
feature-filtered regeneration matches the vendored files except the timestamp
line. The stale Ghostty package version string is not treated as source identity.
Separate application zlib/Oniguruma are outside the selected VT build graph;
uucode's utf8proc research snippets remain in its full archive.

**Not cleared:** the upstream release digest/tag/workflow association is verified,
but there is no signed attestation or independently reviewed reproducible native
rebuild proving exact prebuilt/source correspondence. Native source retention is
not blanket licensing or redistribution approval. Upstream Lisp lexical-binding,
obsolete-macro and winum declaration warnings remain visible; they are not
suppressed or falsely described as fixed.

## Doctor and package-only behavior

Doctor verifies host version/hash, native/module loadability, both grammar ABIs,
locked source bytes and loaded API locations, protocol 2 and deck's implemented
`:detached-desktop-restore t`. Its endpoint health probe explicitly disables
alternate-editor fallback. It creates no state, downloads nothing, reads no
credentials, refreshes no authentication, starts no agent/service and reclaims no
locks. Normal reference runtime configuration includes the exact release Pi
version **and entry-point digest**.

`node scripts/emacs-setup.mjs --package-only` emits a reviewed Lisp form using
explicit dependency/source/runtime paths. It writes no settings, enables no deck
mode/reference UI/orchestration/sound, and starts no session. Existing Emacs users
choose activation themselves; the emitted form refuses an already loaded API
from outside the selected pinned source.

## Verification and classification

- 35 deterministic config/provision tests passed, zero skips: hashes, source/
  notice retention, archive safety, permissions, libc, owning API/report failures,
  package-only read-only output, source modification, ancestor-repository isolation,
  escaping executable links, supervisor and startup guards. A real setup CLI also
  created only the explicitly selected package settings with mode 0600 and left
  authentication/optional integrations disabled.
- Eight actual startup lanes passed: **package-only and full reference**, each in
  batch, 256-colour TTY, truecolour TTY and isolated Xvfb GUI. They validated real
  fork/deck capabilities, ABI-15 parsing, native module loading, expected optional
  activation and no agent/settings creation. TTY colour cells were exactly 256
  and 16777216 respectively.
- These startup lanes used a copied private candidate-07 host/runtime/deck fixture
  with the current reference configuration, latest complete retained Pilish source
  and freshly provisioned assets, not workspace symlinks or home caches. They
  certify provisioning/configuration integration, **not the final coordinated
  packed dependency graph, cross-frontend inference/worker lifetime or public
  acquisition**. Parent release integration must rerun the same lanes against the
  final actual release bytes.

```sh
PHIMACS_TEST_ASSETS=/fresh/assets/emacs \
  node --test test/reference-config.test.mjs test/reference-provision.test.mjs
PHIMACS_REFERENCE_STARTUP=1 PHIMACS_RELEASE_DIR=/installed/release \
  PHIMACS_EMACS_ASSETS=/fresh/assets/emacs \
  PHIMACS_PILISH_DIR=/installed/release/lisp/pilish \
  node --test --test-concurrency=1 test/reference-startup.test.mjs
```
