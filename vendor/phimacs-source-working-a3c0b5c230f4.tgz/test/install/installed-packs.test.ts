import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";

const prefix = process.env.PHIMACS_RUNTIME_PREFIX;
const enabled = prefix !== undefined;

function isolatedEnvironment(home: string): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = { ...process.env, HOME: home, PI_CODING_AGENT_DIR: path.join(home, "agent"), PI_OFFLINE: "1", PIMUX_DIR: path.join(home, "mux"), TMPDIR: path.join(home, "tmp") };
  fs.mkdirSync(env.TMPDIR!, { recursive: true, mode: 0o700 });
  delete env.NODE_PATH;
  delete env.NODE_OPTIONS;
  delete env.PI_REMOTE;
  delete env.PI_ORCHESTRATION_HOST;
  delete env.PI_ORCHESTRATION_ENDPOINT;
  delete env.PI_ORCHESTRATION_TARGET;
  delete env.PI_NESTED;
  return env;
}

test("installed packs import compiled exports and one physical host", { skip: !enabled && "Set PHIMACS_RUNTIME_PREFIX to an explicitly hydrated candidate" }, () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), "phimacs-installed-"));
  const target = path.resolve(prefix!);
  try {
    const probe = fs.readFileSync(fileURLToPath(new URL("./installed-probe.mjs", import.meta.url)), "utf8");
    const result = spawnSync(process.execPath, ["--input-type=module", "--eval", probe], { cwd: target, env: isolatedEnvironment(home), encoding: "utf8", timeout: 30_000 });
    assert.equal(result.status, 0, result.stderr || result.stdout);
    assert.match(result.stdout, /host identity verified/);
  } finally {
    fs.rmSync(home, { recursive: true, force: true });
  }
});

test("pimux executes below node_modules without native TypeScript loading", { skip: !enabled && "Set PHIMACS_RUNTIME_PREFIX to an explicitly hydrated candidate" }, () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), "phimacs-cli-"));
  try {
    const target = path.resolve(prefix!);
    const env = isolatedEnvironment(home);
    const result = spawnSync(process.execPath, [path.join(target, "node_modules/@phimacs/pimux/bin/pimux"), "list", "--json"], { cwd: home, env, encoding: "utf8", timeout: 30_000 });
    assert.equal(result.status, 0, result.stderr || result.stdout);
    assert.deepEqual(JSON.parse(result.stdout), []);
    assert.deepEqual(fs.existsSync(env.PIMUX_DIR!) ? fs.readdirSync(env.PIMUX_DIR!) : [], [], "list must not start a runtime");
  } finally {
    fs.rmSync(home, { recursive: true, force: true });
  }
});

test("installed worker task-status executable reads absence without creating a runtime namespace", { skip: !enabled && "Set PHIMACS_RUNTIME_PREFIX to an explicitly hydrated candidate" }, () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), "phimacs-task-status-installed-"));
  try {
    const env = isolatedEnvironment(home);
    const executable = path.join(path.resolve(prefix!), "node_modules/.bin/phimacs-task-status");
    const result = spawnSync(executable, ["--id", "unallocated-worker", "--json"], {
      cwd: home, env, encoding: "utf8", timeout: 10_000,
    });
    assert.equal(result.status, 0, result.stderr || result.stdout);
    assert.equal(JSON.parse(result.stdout), null);
    assert.equal(fs.existsSync(env.PIMUX_DIR!), false);
    assert.equal(fs.existsSync(env.PI_CODING_AGENT_DIR!), false);
  } finally { fs.rmSync(home, { recursive: true, force: true }); }
});

test("installed public sound uses only an explicitly configured local backend", { skip: !enabled && "Set PHIMACS_RUNTIME_PREFIX to an explicitly hydrated candidate" }, () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), "phimacs-sound-installed-"));
  try {
    const probe = fs.readFileSync(fileURLToPath(new URL("./installed-features-probe.mjs", import.meta.url)), "utf8");
    const result = spawnSync(process.execPath, ["--input-type=module", "--eval", probe], { cwd: path.resolve(prefix!), env: isolatedEnvironment(home), encoding: "utf8", timeout: 30_000 });
    assert.equal(result.status, 0, result.stderr || result.stdout);
    assert.match(result.stdout, /explicit local PCM\/WAV backend verified/);
  } finally { fs.rmSync(home, { recursive: true, force: true }); }
});

test("installed orchestration workers keep actual task ownership after frontend disconnect", { skip: !enabled && "Set PHIMACS_RUNTIME_PREFIX to an explicitly hydrated candidate", timeout: 180_000 }, () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), "phimacs-workers-installed-"));
  try {
    const env = isolatedEnvironment(home);
    env.PHIMACS_TEST_FAUX = fileURLToPath(new URL("../support/release-faux.ts", import.meta.url));
    const probe = fs.readFileSync(fileURLToPath(new URL("./installed-workers-probe.mjs", import.meta.url)), "utf8");
    const result = spawnSync(process.execPath, ["--input-type=module", "--eval", probe], { cwd: path.resolve(prefix!), env, encoding: "utf8" });
    assert.equal(result.status, 0, result.stderr || result.stdout);
    assert.match(result.stdout, /parent-owned worker completion\/cancellation verified/);
  } finally { fs.rmSync(home, { recursive: true, force: true }); }
});

test("all internal lock resolutions are retained local tarballs", { skip: !enabled && "Set PHIMACS_RUNTIME_PREFIX to an explicitly hydrated candidate" }, () => {
  const target = path.resolve(prefix!);
  const lock = JSON.parse(fs.readFileSync(path.join(target, "package-lock.json"), "utf8"));
  const manifest = JSON.parse(fs.readFileSync(path.join(target, "release-manifest.json"), "utf8"));
  assert.ok(!manifest.artifacts.some((item: { name: string }) => item.name === "pagent"));
  assert.equal(manifest.portablePagent, undefined);
  assert.equal(fs.existsSync(path.join(target, "node_modules/pagent")), false);
  assert.equal(fs.existsSync(path.join(target, "bin/pagent")), false);
  for (const artifact of manifest.artifacts) {
    const record = lock.packages[`node_modules/${artifact.name}`];
    assert.match(record.resolved, /^file:tarballs\//);
    assert.equal(record.link, undefined);
    assert.ok(fs.existsSync(path.join(target, artifact.file)));
  }
});
