import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { createSoundRuntime, configuredTranscriber, writeVoiceSetting } from 'pi-sound';

const agent = process.env.PI_CODING_AGENT_DIR;
const runtime = createSoundRuntime();
assert.deepEqual(runtime.backends.ids(), ['local']);
assert.equal(runtime.readSetting(agent).backend, null);
const events = { partial() {}, error(message) { throw new Error(message); } };
await assert.rejects(configuredTranscriber(agent, runtime)(events, new AbortController().signal), /disabled/);
assert.equal(fs.existsSync(path.join(agent, 'claude-agent')), false);
let requests = 0;
const server = http.createServer(async (request, response) => {
  requests++;
  assert.equal(request.url, '/v1/audio/transcriptions');
  const chunks = [];
  for await (const chunk of request) chunks.push(chunk);
  const body = Buffer.concat(chunks);
  assert.ok(body.includes(Buffer.from('RIFF')));
  assert.ok(body.includes(Buffer.from('WAVE')));
  response.setHeader('content-type', 'application/json');
  response.end(JSON.stringify({ text: ' synthetic public transcription ' }));
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
try {
  writeVoiceSetting(agent, { backend: 'local', options: { url: `http://127.0.0.1:${server.address().port}` }, mode: 'type' });
  const { backend, transcriber } = await configuredTranscriber(agent, runtime)(events, new AbortController().signal);
  assert.equal(backend, 'local');
  try {
    transcriber.write(Buffer.from([0, 0, 1, 0]));
    assert.equal(await transcriber.finish(), 'synthetic public transcription');
  } finally { transcriber.close(); }
  assert.equal(requests, 1);
  assert.equal(fs.existsSync(path.join(agent, 'claude-agent')), false);
  assert.equal(fs.statSync(path.join(agent, 'voice.json')).mode & 0o777, 0o600);
} finally { await new Promise(resolve => server.close(resolve)); }
console.log('Installed public sound is disabled by default; explicit local PCM/WAV backend verified');
