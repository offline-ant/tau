import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import ts from "typescript";

const root = fileURLToPath(new URL("../../", import.meta.url));
const workspacePaths: string[] = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8")).workspaces;
const packages = workspacePaths.map((directory) => {
  const directoryPath = path.join(root, directory);
  return { directory: directoryPath, manifest: JSON.parse(fs.readFileSync(path.join(directoryPath, "package.json"), "utf8")) };
});
const workspaceNames = new Set(packages.map(({ manifest }) => manifest.name));
const hostPeers = new Set(["@earendil-works/pi-ai", "@earendil-works/pi-coding-agent", "@earendil-works/pi-tui", "typebox"]);

function files(directory: string): string[] {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    if (["dist", "node_modules"].includes(entry.name)) return [];
    const file = path.join(directory, entry.name);
    return entry.isDirectory() ? files(file) : [file];
  });
}

function leaves(value: unknown): string[] {
  if (typeof value === "string") return [value];
  if (value && typeof value === "object") return Object.values(value).flatMap(leaves);
  return [];
}

function packageName(specifier: string): string {
  return specifier.startsWith("@") ? specifier.split("/").slice(0, 2).join("/") : specifier.split("/")[0]!;
}

test("source packages and locks contain only the supported release graph", () => {
  const sourcePackages = fs.readdirSync(path.join(root, "packages"), { withFileTypes: true })
    .filter((entry) => entry.isDirectory())
    .map((entry) => `packages/${entry.name}`).sort();
  assert.deepEqual(sourcePackages, [...workspacePaths].sort());
  const release = JSON.parse(fs.readFileSync(path.join(root, "release-manifest.json"), "utf8"));
  const lock = JSON.parse(fs.readFileSync(path.join(root, "package-lock.json"), "utf8"));
  for (const name of release.excludedProjects) {
    assert.equal(workspaceNames.has(name), false);
    assert.equal(fs.existsSync(path.join(root, "packages", name)), false);
    assert.equal(Object.hasOwn(lock.packages, `packages/${name}`), false);
    assert.equal(Object.hasOwn(lock.packages, `node_modules/${name}`), false);
    for (const { manifest } of packages) {
      for (const group of ["dependencies", "devDependencies", "peerDependencies", "optionalDependencies"]) {
        assert.equal(Object.hasOwn(manifest[group] ?? {}, name), false, `${manifest.name} depends on excluded ${name}`);
      }
    }
  }
});

test("coordinated package versions and dependency requirements are explicit", () => {
  for (const { manifest } of packages) {
    assert.equal(manifest.version, "0.1.0", manifest.name);
    for (const group of ["dependencies", "devDependencies"]) {
      for (const [name, version] of Object.entries(manifest[group] ?? {})) {
        assert.match(String(version), /^\d+\.\d+\.\d+(?:-[\w.-]+)?$/, `${manifest.name} ${name} must be exact`);
        if (workspaceNames.has(name)) assert.equal(version, "0.1.0");
      }
    }
    for (const [name, version] of Object.entries(manifest.peerDependencies ?? {})) {
      if (hostPeers.has(name)) assert.equal(version, "*", `${manifest.name} ${name} is provided by Pi`);
    }
    assert.ok(fs.existsSync(path.join(packages.find((item) => item.manifest.name === manifest.name)!.directory, "LICENSE")));
  }
});

test("runtime imports use declared exports and form an acyclic package graph", () => {
  const edges = new Map<string, Set<string>>();
  for (const { directory, manifest } of packages) {
    const dependencies = new Set(Object.keys({ ...manifest.dependencies, ...manifest.peerDependencies }));
    const outgoing = new Set<string>();
    edges.set(manifest.name, outgoing);
    for (const file of files(directory)) {
      const relative = path.relative(directory, file);
      if (!file.endsWith(".ts") || file.endsWith(".test.ts") || /^(?:test|scripts)[/\\]/.test(relative)) continue;
      const source = ts.createSourceFile(file, fs.readFileSync(file, "utf8"), ts.ScriptTarget.Latest, true);
      const visit = (node: ts.Node): void => {
        if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier && ts.isStringLiteral(node.moduleSpecifier)) {
          const specifier = node.moduleSpecifier.text;
          if (specifier.startsWith(".")) {
            assert.ok(path.resolve(path.dirname(file), specifier).startsWith(directory + path.sep), `${relative} escapes its package: ${specifier}`);
          } else if (!specifier.startsWith("node:")) {
            const name = packageName(specifier);
            assert.ok(dependencies.has(name), `${manifest.name}/${relative} has undeclared runtime import ${specifier}`);
            if (workspaceNames.has(name)) {
              outgoing.add(name);
              const target = packages.find((item) => item.manifest.name === name)!;
              const subpath = specifier === name ? "." : `.${specifier.slice(name.length)}`;
              assert.ok(Object.hasOwn(target.manifest.exports ?? {}, subpath), `${specifier} is not exported`);
            }
          }
        }
        ts.forEachChild(node, visit);
      };
      visit(source);
    }
  }
  const walk = (name: string, visiting: Set<string>, complete: Set<string>): void => {
    assert.ok(!visiting.has(name), `dependency cycle through ${name}`);
    if (complete.has(name)) return;
    visiting.add(name);
    for (const target of edges.get(name) ?? []) walk(target, visiting, complete);
    visiting.delete(name);
    complete.add(name);
  };
  const complete = new Set<string>();
  for (const name of edges.keys()) walk(name, new Set(), complete);
});

test("worker task status is an explicitly locked release executable", () => {
  const orchestration = packages.find(({ manifest }) => manifest.name === "pi-orchestration")!;
  const lock = JSON.parse(fs.readFileSync(path.join(root, "package-lock.json"), "utf8"));
  assert.equal(orchestration.manifest.bin["phimacs-task-status"], "./dist/worker-task-cli.js");
  assert.equal(lock.packages["packages/orchestration"].bin["phimacs-task-status"], "dist/worker-task-cli.js");
  const executable = path.join(orchestration.directory, orchestration.manifest.bin["phimacs-task-status"]);
  assert.ok(fs.statSync(executable).isFile());
  fs.accessSync(executable, fs.constants.X_OK);
});

test("compiled exports, Pi entry points and installed assets exist", () => {
  for (const { directory, manifest } of packages) {
    for (const asset of [...leaves(manifest.exports), ...leaves(manifest.bin), ...(manifest.pi?.extensions ?? []), ...(manifest.pi?.skills ?? [])]) {
      assert.ok(fs.existsSync(path.resolve(directory, asset)), `${manifest.name}: missing ${asset}; run npm run compile`);
    }
    assert.equal(fs.existsSync(path.join(directory, "node_modules", "@earendil-works", "pi-coding-agent")), false, `${manifest.name} must not have a nested host SDK`);
  }
  const pimux = packages.find(({ manifest }) => manifest.name === "@phimacs/pimux")!;
  assert.equal(pimux.manifest.pi, undefined, "the private companion is never an auto-discovered extension");
  assert.match(fs.readFileSync(path.join(pimux.directory, "bin", "pimux"), "utf8"), /dist\/main\.js/);
  const orchestration = path.join(root, "packages", "orchestration");
  for (const asset of ["emacs/pi-orchestration.el", "shell/osc133.bash", "shell/osc133.fish", "shell/osc133.gdb"]) {
    assert.ok(fs.existsSync(path.join(orchestration, asset)), asset);
  }
});
