import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import { setTimeout as delay } from 'node:timers/promises';
import { createClaimTestEnvironment } from '@phimacs/pimux/ownership';
import { listRuntimes, startRuntime, stopRuntime } from '@phimacs/pimux/runtime';
import { readProcessIdentity, processIdentityStatus } from '@phimacs/pimux/process-identity';
import { createWorkerArtifacts, writeWorkerRequest } from 'pi-orchestration/worker-frame';

const release = process.cwd();
const manifest = JSON.parse(fs.readFileSync(path.join(release, 'release-manifest.json')));
const sandbox = createClaimTestEnvironment();
const identities = [];
const env = { PATH: process.env.PATH, ...sandbox.env, HOME: path.join(sandbox.root, 'home'),
  TMPDIR: path.join(sandbox.root, 'tmp'), PIMUX_DIR: path.join(sandbox.root, 'mux'),
  PI_CODING_AGENT_DIR: path.join(sandbox.root, 'agent'), PI_OFFLINE: '1',
  PHIMACS_RELEASE_HOLD: path.join(sandbox.root, 'hold'), PHIMACS_PI: path.join(release, manifest.pi.executable),
  PHIMACS_PI_VERSION: manifest.pi.version, PHIMACS_PI_SHA256: manifest.pi.sha256,
  PI_ORCHESTRATION_HOST: 'emacs', PI_ORCHESTRATION_ENDPOINT: path.join(sandbox.root, 'absent-frontend.sock'),
  PI_ORCHESTRATION_PLACEMENT: 'worker', PI_ORCHESTRATION_TARGET: 'installed-worker' };
for (const value of [env.HOME, env.TMPDIR, env.PIMUX_DIR, env.PI_CODING_AGENT_DIR, env.PHIMACS_RELEASE_HOLD]) fs.mkdirSync(value, { recursive: true, mode: 0o700 });
const faux = path.join(sandbox.root, 'faux.ts');
fs.copyFileSync(process.env.PHIMACS_TEST_FAUX, faux);
const originalTmp = process.env.TMPDIR;
process.env.TMPDIR = env.TMPDIR;

async function until(predicate, message, timeoutMs = 20_000) {
  const deadline = performance.now() + timeoutMs;
  while (!predicate()) {
    assert.ok(performance.now() < deadline, message);
    await delay(20);
  }
}
async function submit(receipt, message, streamingBehavior) {
  const socket = net.connect(receipt.socket);
  await new Promise((resolve, reject) => {
    const id = `worker-${message}`;
    let pending = '';
    let sent = false;
    let snapshot;
    let settled = false;
    const timer = setTimeout(() => finish(new Error('Synthetic worker client did not reach readiness/acknowledgement')), 15_000);
    const finish = error => {
      if (settled) return;
      settled = true; clearTimeout(timer); socket.destroy();
      if (error) reject(error); else resolve();
    };
    socket.on('error', finish);
    socket.on('end', () => finish(sent ? undefined : new Error('Worker disconnected before readiness')));
    socket.on('data', chunk => {
      pending += chunk;
      for (let at; (at = pending.indexOf('\n')) >= 0;) {
        const line = pending.slice(0, at); pending = pending.slice(at + 1);
        if (!line.trim()) continue;
        let record;
        try { record = JSON.parse(line); } catch (error) { finish(error); return; }
        if (record.type === 'pimux_snapshot') snapshot = record;
        if (record.type === 'pimux_live' && record.generation === snapshot?.generation && !sent) {
          if (!snapshot.inputContext) { finish(new Error('Worker has no authoritative input context')); return; }
          sent = true;
          socket.write(JSON.stringify({ id, type: 'prompt', message, pimuxContext: { ...snapshot.inputContext },
            ...(streamingBehavior ? { streamingBehavior } : {}) }) + '\n');
        } else if (record.type === 'response' && record.id === id) {
          finish(record.success ? undefined : new Error(record.error || 'Worker command refused'));
        } else if (record.type === 'pimux_exit') finish(sent ? undefined : new Error('Worker exited before readiness'));
      }
    });
  });
  // There is intentionally no required frontend after acceptance. The task's
  // process identity/lease, not this socket's lifetime, owns the worker.
}

try {
  for (const mode of ['complete', 'cancel']) {
    const artifacts = createWorkerArtifacts();
    const parent = { process: readProcessIdentity(process.pid), taskId: `installed-${mode}` };
    assert.ok(parent.process);
    const lease = path.join(artifacts.artifactDir, 'parent-task.json');
    fs.writeFileSync(lease, JSON.stringify({ schema: 1, ...parent, state: 'active' }), { mode: 0o600 });
    const childEnv = { ...env, PHIMACS_PARENT_TASK: JSON.stringify(parent), PHIMACS_PARENT_TASK_FILE: lease };
    writeWorkerRequest(artifacts, { id: parent.taskId, task: mode === 'complete' ? 'installed worker complete' : 'hold installed-cancel', tools: [],
      model: { provider: 'release-faux', id: 'one' }, thinkingLevel: 'off', resultPath: artifacts.resultPath, statusPath: artifacts.statusPath });
    const receipt = await startRuntime({ command: env.PHIMACS_PI, cwd: sandbox.root, env: childEnv, parent,
      expectedHost: { version: manifest.pi.version, sha256: manifest.pi.sha256 },
      args: ['--mode', 'rpc', '--session', path.join(sandbox.root, 'sessions', `${mode}.jsonl`),
        '--no-extensions', '--no-skills', '--no-context-files', '--no-prompt-templates',
        '--extension', faux, '--extension', path.join(release, 'node_modules/pi-orchestration'),
        '--extension', path.join(release, 'node_modules/pi-ant/dist/extensions/tools.js'),
        '--extension', path.join(release, 'node_modules/pi-ant/dist/extensions/error-prompt.js'),
        '--provider', 'release-faux', '--model', 'one', '--thinking', 'off'] });
    const identity = readProcessIdentity(receipt.piPid);
    assert.ok(identity); identities.push(identity);
    await submit(receipt, `/worker-run ${artifacts.requestPath}`);
    if (mode === 'complete') {
      await until(() => fs.existsSync(artifacts.resultPath), 'installed worker publishes its final result with no frontend');
      const result = JSON.parse(fs.readFileSync(artifacts.resultPath));
      assert.equal(result.id, parent.taskId);
      assert.equal(result.isError, false, JSON.stringify(result));
      assert.match(result.result, /installed worker complete/);
    } else {
      await until(() => fs.existsSync(artifacts.statusPath) && JSON.parse(fs.readFileSync(artifacts.statusPath)).state === 'running', 'held worker enters task');
      await submit(receipt, '/worker-cancel', 'steer');
    }
    await until(() => processIdentityStatus(identity) === 'dead', 'installed worker actually exits after result/cancellation');
    if (mode === 'cancel') {
      assert.equal(fs.existsSync(artifacts.resultPath), false);
      assert.equal(fs.existsSync(artifacts.retrospectiveMarkdownPath), false);
      assert.equal(JSON.parse(fs.readFileSync(lease)).state, 'ended');
    }
  }
  console.log('Installed optional extensions and parent-owned worker completion/cancellation verified without frontend lifetime');
} catch (error) {
  console.error('Synthetic installed worker runtime:', JSON.stringify(listRuntimes(env)));
  for (const name of fs.readdirSync(path.join(sandbox.root, 'sessions')).filter(name => name.endsWith('.jsonl'))) {
    console.error(`Synthetic session ${name}:`, fs.readFileSync(path.join(sandbox.root, 'sessions', name), 'utf8').slice(-8000));
  }
  throw error;
} finally {
  if (originalTmp === undefined) delete process.env.TMPDIR; else process.env.TMPDIR = originalTmp;
  for (const runtime of listRuntimes(env)) await stopRuntime(runtime.muxId, { env });
  assert.ok(identities.every(identity => processIdentityStatus(identity) === 'dead'), `Uncertain worker cleanup; retained ${sandbox.root}`);
  fs.rmSync(sandbox.root, { recursive: true, force: true });
}
