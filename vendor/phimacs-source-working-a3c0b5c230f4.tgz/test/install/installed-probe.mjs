import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { findPackageJSON } from "node:module";
import { fileURLToPath } from "node:url";
import { redactEndpoint } from "@phimacs/pimux/endpoint";
import { PROTOCOL_VERSION } from "@phimacs/pimux/protocol";
import { parseToolSelection } from "pi-orchestration/session-tools";
import { readWorkerTask } from "pi-orchestration/worker-task";
import tools from "pi-ant/tools";
import * as browser from "pi-browser";
import * as sound from "pi-sound";
import * as host from "@earendil-works/pi-coding-agent";

const root = path.dirname(fileURLToPath(import.meta.url));
assert.equal(PROTOCOL_VERSION, 2);
assert.equal(redactEndpoint("https://user:secret@example.invalid/"), "https://example.invalid/");
assert.deepEqual(parseToolSelection({ enabledTools: ["read", "read"] }), ["read"]);
assert.equal(typeof readWorkerTask, "function");
fs.accessSync(path.join(root, "node_modules/.bin/phimacs-task-status"), fs.constants.X_OK);
assert.equal(typeof tools, "function");
assert.ok(Object.keys(browser).length > 0);
assert.ok(Object.keys(sound).length > 0);
assert.ok(Object.keys(host).length > 0);
const expectedHost = findPackageJSON("@earendil-works/pi-coding-agent", import.meta.url);
for (const name of ["pi-ant", "pi-orchestration", "@phimacs/pimux", "pi-browser", "pi-sound", "pi-tau-web-server"]) {
  const directory = path.join(root, "node_modules", name);
  assert.equal(fs.lstatSync(directory).isSymbolicLink(), false, name);
  assert.equal(findPackageJSON("@earendil-works/pi-coding-agent", path.join(directory, "package.json")), expectedHost, name);
  assert.equal(findPackageJSON("typebox", path.join(directory, "package.json")), path.join(root, "node_modules/typebox/package.json"), `${name}: host typebox identity`);
}
console.log("Installed compiled exports and host identity verified");
