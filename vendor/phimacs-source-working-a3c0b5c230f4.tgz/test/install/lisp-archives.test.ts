import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../../", import.meta.url));

test("Lisp archives contain source, package metadata and original licenses only", () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "phimacs-lisp-test-"));
  try {
    const result = spawnSync(process.execPath, [path.join(root, "scripts/pack-lisp.mjs"), "--destination", directory], { cwd: root, encoding: "utf8" });
    assert.equal(result.status, 0, result.stderr);
    const artifacts = JSON.parse(result.stdout) as Array<{ name: string; file: string; sha256: string }>;
    assert.deepEqual(artifacts.map(({ name }) => name), ["pi-deck", "pi-orchestration", "pi-sound"]);
    for (const artifact of artifacts) {
      const archive = path.join(directory, artifact.file);
      assert.equal(createHash("sha256").update(fs.readFileSync(archive)).digest("hex"), artifact.sha256);
      const listing = spawnSync("tar", ["-tzf", archive], { encoding: "utf8" });
      assert.equal(listing.status, 0, listing.stderr);
      assert.match(listing.stdout, new RegExp(`${artifact.name}-pkg\\.el`));
      assert.match(listing.stdout, /\/LICENSE\n/);
      assert.doesNotMatch(listing.stdout, /(?:\.elc|\.eln|\.so|(?:^|\/)test\/|-test\.el|node_modules)/);
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});
