# Reference UI/setup evidence

All inputs came from newly acquired locked sources under the ignored candidate
asset directory, not installed home packages or native caches. The user confirmed
ownership of original reference configuration code and selected MIT; third-party
licenses and corresponding-source obligations remain separate.

The reference scripts/configuration implement:

- An immutable init directory, separate private 0700 state and explicit user file.
- Exact release Pi hash/version paths; protocol-2/fork/native/grammar preflight.
- Dracula, Evil/leader keys, completion, window numbering, bottom panel, calm mode
  line and the selected Pilish/deck presentation options.
- Explicit setup with narrow existing Pi package filters; exclusive new settings
  creation, no copied credentials and optional browser/sound/private adapters off.
- Manual versus externally supervised Emacs startup, no double supervisor launch,
  identity-bound deferred replacement, owned failed-child cleanup and retained
  uncertainty. Existing unavailable endpoints are never replaced on a timeout.
- Read-only diagnosis with no provisioning, lock reclamation, alternative-editor
  fallback, provider request or credential access.

The selected command passes **28 Node tests**, including four ERT UI assertions
inside the isolated batch lane and three real display lanes:

```sh
PHIMACS_TEST_ASSETS="$PWD/.staging/reference-assets-current/emacs" \
PHIMACS_REFERENCE_DISPLAY=1 \
PHIMACS_REFERENCE_EVIDENCE="$PWD/.staging/reference-display-evidence" \
node --test test/reference-config.test.mjs test/reference-display.test.mjs \
  test/reference-provision.test.mjs
```

The display lanes used a new HOME/state, dedicated Xvfb GUI and private PTYs with
`xterm-256color` and `xterm-direct`/truecolour. GUI screenshot and three JSON receipts
are available in the ignored evidence directory. The screenshot was inspected:
dark theme, modal cursor, concise mode line and visible bottom warning panel.
Upstream source warnings are visible, not suppressed; their ownership is recorded
in the provisioning evidence. No agent, provider or user daemon was started.

The manual launcher test starts a test-owned detached inert Node child to verify
commit/disconnect semantics, then explicitly stops that child. Supervisor and
startup-failure tests use fake commands. These are not evidence of a complete
Emacs daemon restart, symmetric Pi reconnect or a full clean-reference installation.

## Integration still required

The actual fork has not yet supplied the public capability/configure-runtime and
essential-only grammar API required by `emacs/config/README.md`. The lock still
records the audited grammar-owner baseline. Update it to the reviewed candidate,
run the real grammar installer and then validate complete startup/reconnect with
its matching protocol-2 runtime and deck restart/persistence API. No missing API
is shimmed, ignored or inferred from a package version.

The root release pack must include `emacs/config`, `emacs/inputs.json`, the
`emacs-*` scripts and exact retained fork source/identity. Its final manifest needs
the exact `externalForks.pilish` pin/source hash and the implemented runtime
protocol/lifetime descriptor. The current baseline pack correctly fails these
new preflight checks. Root packaging is owned by another task.

Native linked-vendor closure and upstream warning cleanup remain final release
review gates. This evidence does not approve public publication or live cutover.
