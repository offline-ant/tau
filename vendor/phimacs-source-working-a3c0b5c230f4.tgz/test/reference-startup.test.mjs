import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { parseOptions, inspectEnvironment, childEnvironment } from '../scripts/emacs-environment.mjs';
import { packageOnlyConfiguration } from '../scripts/emacs-setup.mjs';

const selected = process.env.PHIMACS_REFERENCE_STARTUP === '1';
const root = path.resolve(import.meta.dirname, '..');
const quote = value => `'${value.replaceAll("'", "'\\''")}'`;

for (const setup of ['package-only', 'reference']) for (const display of ['batch', 'tty256', 'ttytrue', 'gui']) {
  test(`fresh release ${setup} startup on ${display}`, { skip: !selected, timeout: 90_000 }, async () => {
    const home = await fs.mkdtemp(path.join(os.tmpdir(), 'phimacs-reference-startup-'));
    try {
      const options = parseOptions(['--release', process.env.PHIMACS_RELEASE_DIR,
        '--assets', process.env.PHIMACS_EMACS_ASSETS, '--pilish', process.env.PHIMACS_PILISH_DIR,
        '--state', path.join(home, 'state')], {});
      const report = await inspectEnvironment(options);
      assert.equal(report.ok, true, JSON.stringify(report.issues));
      const generated = await packageOnlyConfiguration(options);
      const evidence = path.join(home, 'evidence.json');
      const env = childEnvironment(options, { ...process.env, HOME: home, TMPDIR: home,
        XDG_CONFIG_HOME: path.join(home, 'config'), XDG_CACHE_HOME: path.join(home, 'cache'),
        XDG_DATA_HOME: path.join(home, 'data'), EMACSLOADPATH: '', GDK_BACKEND: 'x11',
        PIMUX_DIR: path.join(home, 'mux'), PHIMACS_USER_FILE: path.join(home, 'user.el') });
      Object.assign(env, { PHIMACS_TEST_SETUP_MODE: setup, PHIMACS_TEST_DISPLAY: display,
        PHIMACS_TEST_INIT_DIR: path.join(options.release, 'emacs/config'),
        PHIMACS_PACKAGE_ONLY_FORM: generated.lisp, PHIMACS_TEST_EVIDENCE: evidence,
        TERM: display === 'ttytrue' ? 'xterm-direct' : 'xterm-256color' });
      if (display === 'ttytrue') env.COLORTERM = 'truecolor'; else delete env.COLORTERM;
      const probe = path.join(root, 'test/reference-startup.el');
      const args = ['-Q', '--no-splash', ...(display === 'batch' ? ['--batch'] : display === 'gui' ? [] : ['-nw']), '-l', probe];
      const command = display === 'gui' ? 'xvfb-run' : display === 'batch' ? options.emacs : 'script';
      const argv = display === 'gui' ? ['-a', options.emacs, ...args]
        : display === 'batch' ? args : ['-q', '-e', '-c', [options.emacs, ...args].map(quote).join(' '), '/dev/null'];
      const result = spawnSync(command, argv, { env, encoding: 'utf8', timeout: 60_000, maxBuffer: 4 * 1024 * 1024 });
      assert.equal(result.status, 0, `${result.error?.message ?? ''}\n${result.stdout}\n${result.stderr}`);
      const record = JSON.parse(await fs.readFile(evidence, 'utf8'));
      assert.equal(record.setup, setup);
      assert.equal(record.display, display);
      assert.equal(record.detachedRestore, true);
      assert.equal(record.authoritativeClose, true);
      assert.equal(record.taskStatus, path.join(options.release, 'node_modules/.bin/phimacs-task-status'));
      assert.equal(record.moduleLoaded, true);
      assert.equal(record.grammarAbi, 15);
      if (setup === 'reference') { assert.equal(record.evil, true); assert.equal(record.dark, true); }
      if (display === 'tty256') assert.equal(record.colourCells, 256);
      if (display === 'ttytrue') assert.equal(record.colourCells, 16777216);
      if (process.env.PHIMACS_REFERENCE_EVIDENCE) {
        await fs.mkdir(process.env.PHIMACS_REFERENCE_EVIDENCE, { recursive: true });
        await fs.copyFile(evidence, path.join(process.env.PHIMACS_REFERENCE_EVIDENCE, `${setup}-${display}.json`));
      }
      // No view/agent was created, no authentication is consulted and no package
      // selection is written by package-only configuration or reference startup.
      await assert.rejects(fs.stat(path.join(options.agent, 'settings.json')), { code: 'ENOENT' });
      assert.deepEqual(await fs.readdir(path.join(home, 'mux')).catch(() => []), []);
    } finally { await fs.rm(home, { recursive: true, force: true }); }
  });
}
