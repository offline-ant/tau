;;; reference-fixtures.el --- Candidate-only UI fixtures -*- lexical-binding: t; -*-
(require 'json)
(defconst phimacs-reference-test-root
  (file-name-directory (directory-file-name (file-name-directory load-file-name))))
(defun phimacs-reference-load-ui ()
  "Load the reference UI from explicitly fresh assets, without Pi or user init."
  (let* ((root phimacs-reference-test-root)
         (assets (getenv "PHIMACS_TEST_ASSETS")))
    (unless assets (error "PHIMACS_TEST_ASSETS must name freshly provisioned candidate assets"))
    (load (expand-file-name "emacs/config/early-init.el" root) nil t)
    (with-temp-buffer
      (insert-file-contents (expand-file-name "provision.json" assets))
      (let ((provision (json-parse-buffer :object-type 'alist :array-type 'list)))
        (dolist (package (alist-get 'packages provision))
          (dolist (directory (alist-get 'loadPaths package))
            (add-to-list 'load-path (expand-file-name directory assets) t)))))
    (require 'phimacs-ui)
    (phimacs-enable-ui)))
;;; reference-fixtures.el ends here
