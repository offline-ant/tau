;;; reference-startup.el --- Fresh release startup probe -*- lexical-binding: t; -*-
;; SPDX-License-Identifier: MIT
(require 'json)
(let ((setup (getenv "PHIMACS_TEST_SETUP_MODE")))
  (cond
   ((equal setup "package-only")
    (with-temp-buffer
      (insert (or (getenv "PHIMACS_PACKAGE_ONLY_FORM") (error "Missing reviewed package-only form")))
      (eval-buffer)))
   ((equal setup "reference")
    (load (expand-file-name "init.el" (getenv "PHIMACS_TEST_INIT_DIR")) nil t))
   (t (error "Select an explicit startup mode")))
  (unless (and (equal 1 (plist-get (pilish-integration-capabilities) :api-version))
               (equal 2 (plist-get (pilish-integration-capabilities) :pimux-protocol))
               (plist-get (pilish-integration-capabilities) :authoritative-close)
               (equal pilish-runtime-task-status-executable
                      (expand-file-name "node_modules/.bin/phimacs-task-status"
                                        (getenv "PHIMACS_RELEASE_DIR")))
               (plist-get (pi-deck-integration-capabilities) :detached-desktop-restore)
               (eq pilish-runtime-mode 'detached))
    (error "Missing matching public runtime/desktop capabilities"))
  (if (equal setup "package-only")
      (when (or (bound-and-true-p pi-deck-mode) (featurep 'pi-orchestration)
                (featurep 'pi-sound) (bound-and-true-p evil-mode))
        (error "Package-only configuration unexpectedly enabled optional/UI features"))
    (unless (and (bound-and-true-p pi-deck-mode) (bound-and-true-p evil-mode)
                 phimacs--pi-enabled phimacs--ui-enabled
                 (eq pilish-chat-style 'pi) (eq pilish-input-window-height 'fit)
                 (eq pilish-extension-dialog-style 'inline)
                 (eq pilish-send-while-busy 'steer)
                 (bound-and-true-p pilish-window-pairing-mode)
                 (not phimacs-enable-sound))
      (error "Reference configuration is incompletely enabled")))
  (dolist (language '(markdown markdown-inline))
    (unless (and (treesit-language-available-p language)
                 (= 15 (treesit-language-abi-version language)))
      (error "Missing required ABI-15 grammar: %s" language)))
  (with-temp-buffer
    (insert "# Fresh startup\n\n| a | b |\n| - | - |\n| **one** | two |\n")
    (md-ts-mode)
    (font-lock-ensure))
  (module-load (expand-file-name "ghostel/ghostel-module.so" (getenv "PHIMACS_EMACS_ASSETS")))
  (let ((file (getenv "PHIMACS_TEST_EVIDENCE")))
    (with-temp-file file
      (insert (json-encode `((setup . ,setup) (display . ,(getenv "PHIMACS_TEST_DISPLAY"))
                             (api . 1) (protocol . 2) (grammarAbi . 15)
                             (detachedRestore . t) (authoritativeClose . t)
                             (taskStatus . ,pilish-runtime-task-status-executable) (moduleLoaded . t)
                             (colourCells . ,(display-color-cells))
                             (dark . ,(eq frame-background-mode 'dark))
                             (evil . ,(bound-and-true-p evil-mode))))))))
(kill-emacs 0)
;;; reference-startup.el ends here
