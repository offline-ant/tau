;;; reference-ui.el --- Fresh reference UI regressions -*- lexical-binding: t; -*-
(require 'ert)
(load (expand-file-name "reference-fixtures.el" (file-name-directory load-file-name)) nil t)
(phimacs-reference-load-ui)

(ert-deftest reference-ui-enables-style-and-completion ()
  (should (equal frame-background-mode 'dark))
  (should (custom-theme-enabled-p 'dracula))
  (dolist (mode '(evil-mode evil-escape-mode global-evil-surround-mode vertico-mode
                  marginalia-mode global-corfu-mode winum-mode which-key-mode))
    (should (symbol-value mode)))
  (should (equal completion-styles '(orderless basic)))
  (should (eq (lookup-key evil-motion-state-map [escape]) #'ignore))
  (with-temp-buffer
    (evil-local-mode 1)
    (evil-insert-state)
    (should (eq (key-binding (kbd "M-m f f")) #'find-file))))

(ert-deftest reference-ui-repeat-enable-is-idempotent ()
  (let ((hooks (copy-sequence pilish-chat-mode-hook))
        (display (copy-tree display-buffer-alist)))
    (phimacs-enable-ui)
    (should (equal hooks pilish-chat-mode-hook))
    (should (equal display display-buffer-alist))))

(ert-deftest reference-ui-status-is-below-draft ()
  (with-temp-buffer
    (setq-local header-line-format '("model status"))
    (phimacs-modeline-input)
    (should (equal mode-line-format '("model status")))
    (should-not header-line-format))
  (with-temp-buffer
    (phimacs-modeline-chat)
    (should (equal mode-line-format '(" ")))))

(ert-deftest reference-ui-optionals-and-state-are-isolated ()
  (should-not phimacs-enable-sound)
  (should-not phimacs-enable-osc52)
  (should-not package-enable-at-startup)
  (should-not package-archives)
  (should (file-in-directory-p savehist-file phimacs-state-directory))
  (should-not (file-in-directory-p savehist-file phimacs-config-directory))
  (should (zerop (logand (file-modes phimacs-state-directory) #o077))))

(ert-run-tests-batch-and-exit)
