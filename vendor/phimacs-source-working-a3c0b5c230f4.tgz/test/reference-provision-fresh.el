;;; reference-provision-fresh.el --- Explicit fresh-asset probe -*- lexical-binding: t; -*-
;; Run only with PHIMACS_EMACS_ASSETS pointing at the newly provisioned tree.
(require 'json)
(setq native-comp-jit-compilation nil
      load-prefer-newer t)
(let* ((assets (or (getenv "PHIMACS_EMACS_ASSETS")
                   (error "Set PHIMACS_EMACS_ASSETS to explicitly provisioned assets")))
       (provision (with-temp-buffer
                    (insert-file-contents (expand-file-name "provision.json" assets))
                    (json-parse-buffer :object-type 'alist :array-type 'list))))
  (dolist (package (alist-get 'packages provision))
    (dolist (directory (alist-get 'loadPaths package))
      (add-to-list 'load-path (expand-file-name directory assets) t)))
  (dolist (feature '(cape cond-let consult corfu dash dracula-theme embark
                    embark-consult evil evil-collection evil-escape evil-ghostel
                    evil-surround evil-terminal-cursor-changer general ghostel
                    goto-chg llama magit magit-section marginalia markdown-mode
                    markdown-table-wrap md-ts-mode orderless vertico wgrep winum
                    with-editor))
    (require feature)
    (princ (format "Loaded %s\n" feature)))
  (unless (equal (alist-get 'status (alist-get 'native provision)) "verified")
    (error "Fresh native module was not provisioned"))
  (module-load (expand-file-name "ghostel/ghostel-module.so" assets))
  (princ "Loaded independently acquired Ghostel 0.59.0 native module\n"))
