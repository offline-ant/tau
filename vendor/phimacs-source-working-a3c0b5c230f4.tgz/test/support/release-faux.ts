import fs from "node:fs";
import path from "node:path";
import { setTimeout as delay } from "node:timers/promises";
import { fauxAssistantMessage, fauxProvider, fauxToolCall, type TranscriptContext } from "@earendil-works/pi-ai";
import { defineTool, type ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";

/** Installed-release acceptance only. Never register a network-backed provider. */
export default function releaseFaux(pi: ExtensionAPI): void {
  const holdRoot = process.env.PHIMACS_RELEASE_HOLD;
  if (!holdRoot || !holdRoot.startsWith(`${process.env.PHIMACS_TEST_ROOT}/`)) throw new Error("Synthetic hold directory is required");
  const hold = async (name: string, signal?: AbortSignal) => {
    if (!/^[a-z0-9-]+$/.test(name)) throw new Error("Invalid synthetic hold name");
    const deadline = performance.now() + 60_000;
    while (!fs.existsSync(path.join(holdRoot, name))) {
      if (performance.now() > deadline) throw new Error(`Synthetic hold timed out: ${name}`);
      await delay(20, undefined, { signal });
    }
  };
  const reply = async (context: TranscriptContext) => {
    if (context.messages.at(-1)?.role === "toolResult") return fauxAssistantMessage("release tool completed");
    const user = context.messages.findLast(message => message.role === "user");
    const text = typeof user?.content === "string" ? user.content
      : user?.content.flatMap(part => part.type === "text" ? [part.text] : []).join("\n") ?? "";
    if (text === "release tool") return fauxAssistantMessage([fauxToolCall("release_gate", {})], { stopReason: "toolUse" });
    const held = /^hold ([a-z0-9-]+)/m.exec(text);
    if (held) await hold(held[1]);
    const stream = /^stream (\d+)/.exec(text);
    return fauxAssistantMessage(stream
      ? Array.from({ length: Math.min(2000, Number(stream[1])) }, (_, index) => `word${index}`).join(" ")
      : `release reply: ${text}`);
  };
  for (const [name, tokensPerSecond] of [["release-faux", 1_000_000], ["release-faux-slow", 90]] as const) {
    const provider = fauxProvider({ provider: name, models: [{ id: "one", reasoning: true }, { id: "two", reasoning: true }], tokensPerSecond, tokenSize: { min: 1, max: 1 } });
    provider.setResponses(Array.from({ length: 200 }, () => reply));
    pi.registerProvider(provider.provider);
  }
  pi.on("before_agent_start", (_event, ctx) => {
    if (!ctx.model?.provider.startsWith("release-faux")) throw new Error("Release acceptance refuses non-faux inference");
  });
  pi.registerTool(defineTool({
    name: "release_gate", label: "Synthetic release gate", description: "Wait for the test's explicit release", parameters: Type.Object({}),
    async execute(_id, _params, signal) {
      await hold("tool", signal);
      return { content: [{ type: "text", text: "released" }], details: {} };
    },
  }));
  pi.registerCommand("release-select", {
    description: "Synthetic shared dialog",
    handler: async (_args, ctx) => {
      const answer = await ctx.ui.select("Release choice", ["first", "second"]);
      ctx.ui.notify(`release picked:${answer ?? "cancelled"}`, "info");
    },
  });
  pi.registerCommand("release-tree", {
    description: "Owning same-file tree navigation for acceptance",
    handler: async (target, ctx) => {
      const result = await ctx.navigateTree(target.trim(), { summarize: false });
      if (result.cancelled) throw new Error("Synthetic tree navigation was cancelled");
    },
  });
}
