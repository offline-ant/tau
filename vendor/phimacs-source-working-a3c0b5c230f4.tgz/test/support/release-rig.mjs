import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { setTimeout as delay } from 'node:timers/promises';

const execute = promisify(execFile);
const support = fileURLToPath(new URL('./', import.meta.url));

export async function until(predicate, label, timeout = 45_000) {
  const deadline = performance.now() + timeout;
  while (performance.now() < deadline) {
    const result = await predicate();
    if (result) return result;
    await delay(25);
  }
  throw new Error(`Timed out: ${label}`);
}

function inside(root, relative) {
  if (typeof relative !== 'string' || !relative || path.isAbsolute(relative)) throw new Error('Expected an internal relative release path');
  const resolved = path.resolve(root, relative);
  if (!resolved.startsWith(root + path.sep)) throw new Error('Release asset escapes its prefix');
  return resolved;
}

/** Installed acceptance and explicit source-only regressions never substitute inputs. */
export function releasePaths(prefix, { sourceOnly = false } = {}) {
  if (!prefix || !path.isAbsolute(prefix)) throw new Error('PHIMACS_RUNTIME_PREFIX must be an absolute complete installed release');
  prefix = fs.realpathSync(prefix);
  if (fs.existsSync(path.join(prefix, 'INCOMPLETE'))) throw new Error('Incomplete release cannot establish acceptance');
  const manifest = JSON.parse(fs.readFileSync(path.join(prefix, 'release-manifest.json'), 'utf8'));
  if ((manifest.status === 'source-only-close-regression') !== sourceOnly) {
    throw new Error('Source-only Close input requires explicit source mode and cannot establish installed acceptance');
  }
  if (manifest.runtime?.pimuxProtocol !== 2 || manifest.runtime?.detachedTargetImplemented !== true) throw new Error('Protocol-2 completed detached release required; phase-b prefixes are not acceptance inputs');
  const result = {
    prefix, manifest, sourceOnly,
    taskStatus: inside(prefix, 'node_modules/.bin/phimacs-task-status'),
    pi: inside(prefix, manifest.pi.executable),
    pimux: inside(prefix, 'node_modules/@phimacs/pimux/bin/pimux'),
    tau: inside(prefix, 'node_modules/pi-tau-web-server/bin/tau.js'),
    pilish: inside(prefix, manifest.externalForks?.pilish?.directory ?? 'forks/pilish'),
    assets: inside(prefix, manifest.reference?.assets ?? 'assets/emacs'),
  };
  for (const file of [result.pi, result.pimux, result.tau, result.taskStatus, path.join(result.pilish, 'pilish.el'),
    path.join(result.pilish, 'scripts/pilish-storage.mjs'), path.join(result.assets, 'provision.json'),
    path.join(prefix, 'lisp/pi-deck/pi-deck.el')]) {
    if (!fs.existsSync(file)) throw new Error(`Incomplete installed release asset: ${file}`);
    if (!fs.realpathSync(file).startsWith(prefix + path.sep)) throw new Error(`Installed asset resolves outside release: ${file}`);
  }
  return result;
}

export function cleanEnvironment(namespace, release) {
  // Whitelist tool prerequisites, not provider tokens, user endpoints or desktop state.
  const env = Object.fromEntries(['PATH', 'LANG', 'LC_ALL', 'SHELL', 'TERM'].filter(key => process.env[key]).map(key => [key, process.env[key]]));
  Object.assign(env, namespace.env, {
    HOME: path.join(namespace.root, 'home'), TMPDIR: path.join(namespace.root, 'tmp'),
    XDG_CONFIG_HOME: path.join(namespace.root, 'xdg-config'), XDG_CACHE_HOME: path.join(namespace.root, 'xdg-cache'),
    XDG_DATA_HOME: path.join(namespace.root, 'xdg-data'), XDG_RUNTIME_DIR: path.join(namespace.root, 'xdg-runtime'),
    PI_CODING_AGENT_DIR: path.join(namespace.root, 'agent'), PI_CODING_AGENT_SESSION_DIR: namespace.sessions,
    PHIMACS_RUNTIME_PREFIX: release.prefix, PHIMACS_RELEASE_PI: release.pi,
    PHIMACS_RELEASE_PIMUX: release.pimux, PHIMACS_RELEASE_PILISH: release.pilish,
    PHIMACS_RELEASE_TASK_STATUS: release.taskStatus,
    PHIMACS_RELEASE_ASSETS: release.assets, PHIMACS_RELEASE_FAUX: path.join(namespace.root, 'release-faux.ts'),
    PHIMACS_RELEASE_PROJECT: path.join(namespace.root, 'project'), PHIMACS_RELEASE_HOLD: path.join(namespace.root, 'hold'),
    PHIMACS_PI_VERSION: release.manifest.pi.version, PHIMACS_PI_SHA256: release.manifest.pi.sha256,
    TAU_PI_COMMAND: release.pi, TAU_HOST: '127.0.0.1', TAU_PORT: '0', TAU_HTTP_PORT: '0',
  });
  return env;
}

export class ReleaseRig {
  constructor(release, namespace, ownership, identities) {
    this.release = release; this.namespace = namespace; this.root = namespace.root;
    this.ownership = ownership; this.identities = identities;
    this.env = cleanEnvironment(namespace, release);
    this.children = new Set(); this.peers = new Set(); this.copies = [];
    this.observed = new Map(); this.log = [];
  }

  static create(prefix, options) {
    const release = releasePaths(prefix, options);
    const require = createRequire(path.join(release.prefix, 'package.json'));
    const ownership = require('@phimacs/pimux/ownership');
    const identities = require('@phimacs/pimux/process-identity');
    const namespace = ownership.createClaimTestEnvironment();
    const rig = new ReleaseRig(release, namespace, ownership, identities);
    for (const dir of ['home', 'tmp', 'xdg-config', 'xdg-cache', 'xdg-data', 'xdg-runtime', 'agent', 'project', 'hold', 'sockets']) fs.mkdirSync(path.join(rig.root, dir), { mode: 0o700 });
    fs.copyFileSync(path.join(support, 'release-faux.ts'), rig.env.PHIMACS_RELEASE_FAUX);
    fs.copyFileSync(path.join(support, 'release-host.el'), path.join(rig.root, 'release-host.el'));
    fs.writeFileSync(path.join(rig.env.PI_CODING_AGENT_DIR, 'settings.json'), JSON.stringify({
      packages: [], defaultProvider: 'release-faux', defaultModel: 'one',
      compaction: { enabled: false }, retry: { enabled: false }, tau: { authEnabled: false },
    }), { mode: 0o600 });
    return rig;
  }

  async command(command, args, { env = this.env, timeout = 45_000 } = {}) {
    return execute(command, args, { env, cwd: this.env.PHIMACS_RELEASE_PROJECT, timeout, maxBuffer: 32 * 1024 * 1024 });
  }

  child(command, args, env = this.env) {
    const child = spawn(command, args, { env, cwd: this.env.PHIMACS_RELEASE_PROJECT, stdio: ['ignore', 'pipe', 'pipe'] });
    child.log = '';
    for (const stream of [child.stdout, child.stderr]) stream.on('data', data => { child.log = (child.log + data.toString()).slice(-256 * 1024); });
    child.on('error', error => { child.failure = error; });
    this.children.add(child);
    return child;
  }

  async list() {
    assert.equal(this.env.PIMUX_DIR, path.join(this.root, 'mux'));
    const { stdout } = await this.command(this.release.pimux, ['list', '--json']);
    const entries = JSON.parse(stdout);
    for (const entry of entries) {
      assert.ok(entry.socket.startsWith(this.env.PIMUX_DIR + path.sep));
      if (entry.session?.file) assert.ok(entry.session.file.startsWith(this.namespace.sessions + path.sep));
      this.observed.set(entry.muxId, entry);
    }
    return entries;
  }

  async startTau() {
    this.tau = this.child(process.execPath, [this.release.tau]);
    const endpoint = await until(() => {
      if (this.tau.failure || this.tau.exitCode !== null || this.tau.signalCode !== null) throw new Error(`Tau startup failed: ${this.tau.log}`);
      return /Local orchestration \(loopback HTTP\): (http:\/\/127\.0\.0\.1:\d+)/.exec(this.tau.log)?.[1];
    }, 'installed Tau loopback readiness');
    this.endpoint = endpoint;
    return endpoint;
  }

  async api(route, body, method = body === undefined ? 'GET' : 'POST') {
    const response = await fetch(this.endpoint + route, { method, signal: AbortSignal.timeout(45_000),
      ...(body === undefined ? {} : { headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }) });
    const data = await response.json();
    return { status: response.status, data };
  }

  async inputContext(sessionId) {
    const snapshot = await this.api(`/api/live-sessions/${sessionId}/snapshot`);
    assert.equal(snapshot.status, 200, JSON.stringify(snapshot.data));
    const session = snapshot.data.session;
    assert.equal(session.inputReady, true, 'Compose only after Tau applied an authoritative live boundary');
    assert.ok(session.runtimeContext);
    return { agentId: session.runtime.muxId, file: session.sessionFile,
      leafId: session.leafId, runtimeContext: { ...session.runtimeContext } };
  }

  async rpc(sessionId, command) {
    // Each call composes a new intentional action. Capture once; refusal is never
    // retried against a newer branch/file and no stale supplied context is replaced.
    const inputContext = command.inputContext ?? await this.inputContext(sessionId);
    const result = await this.api('/api/rpc', { sessionId, ...command, inputContext });
    assert.equal(result.status, 200, JSON.stringify(result.data));
    assert.equal(result.data.success, true, JSON.stringify(result.data));
    return result.data;
  }

  async startEmacs(prefix = this.release.prefix) {
    const release = releasePaths(prefix, { sourceOnly: this.release.sourceOnly });
    const env = { ...this.env, PHIMACS_RUNTIME_PREFIX: prefix, PHIMACS_RELEASE_PI: release.pi,
      PHIMACS_RELEASE_PIMUX: release.pimux, PHIMACS_RELEASE_PILISH: release.pilish,
      PHIMACS_RELEASE_TASK_STATUS: release.taskStatus, PHIMACS_RELEASE_ASSETS: release.assets };
    const frameArgs = [];
    if (process.env.PHIMACS_TEST_XVFB) {
      // PGTK snapshots can require a persistent first graphical connection.
      // Own that display; never connect the test daemon to a user compositor.
      this.display = this.child(process.env.PHIMACS_TEST_XVFB, ['-displayfd', '1', '-screen', '0', '1280x900x24', '-nolisten', 'tcp']);
      const number = await until(() => {
        if (this.display.failure || this.display.exitCode !== null) throw new Error(`Private Xvfb failed: ${this.display.log}`);
        return /(?:^|\n)(\d+)\r?\n/.exec(this.display.log)?.[1];
      }, 'private Emacs display readiness');
      Object.assign(env, { DISPLAY: `:${number}`, GDK_BACKEND: 'x11' });
      frameArgs.push('--eval', '(make-frame-on-display (getenv "DISPLAY"))');
    }
    this.socket = path.join(this.root, 'sockets', `emacs-${this.children.size}`);
    this.emacs = this.child(process.env.PHIMACS_TEST_EMACS ?? 'emacs', ['-Q', `--fg-daemon=${this.socket}`, ...frameArgs, '--load', path.join(this.root, 'release-host.el')], env);
    try {
      await until(async () => {
        if (this.emacs.failure || this.emacs.exitCode !== null || this.emacs.signalCode !== null) throw new Error(`Emacs startup failed: ${this.emacs.log}`);
        if (!fs.existsSync(this.socket)) return false;
        try { return await this.el('(and (featurep \'release-host) t)'); } catch { return false; }
      }, 'Pilish/deck daemon readiness', 60_000);
    } catch (error) {
      throw new Error(`${error.message}\nEmacs output:\n${this.emacs.log}`, { cause: error });
    }
    return this.emacs;
  }

  async el(expression) {
    const wrapped = `(release-host-wire ${JSON.stringify(expression)})`;
    const { stdout } = await this.command(process.env.PHIMACS_TEST_EMACSCLIENT ?? 'emacsclient', ['--alternate-editor=false', '--socket-name', this.socket, '--eval', wrapped]);
    const encoded = JSON.parse(stdout.trim());
    return JSON.parse(Buffer.from(encoded, 'base64').toString('utf8'));
  }

  state(name) { return this.el(`(release-host-state ${JSON.stringify(name)})`); }
  async live(name) { return until(async () => { const state = await this.state(name); return state.runtime?.state === 'live' && state; }, `Pilish ${name} live`); }
  async settled(name) { return until(async () => { const state = await this.state(name); return !state.busy && state.response?.success && state; }, `Pilish ${name} settled`); }

  async stopChild(child) {
    if (!child || child.exitCode !== null || child.signalCode !== null) return;
    child.kill('SIGTERM');
    await until(() => child.exitCode !== null || child.signalCode !== null, 'owned frontend exit', 20_000);
  }

  async stopEmacs() {
    if (!this.emacs || this.emacs.exitCode !== null || this.emacs.signalCode !== null) return;
    try { await this.command(process.env.PHIMACS_TEST_EMACSCLIENT ?? 'emacsclient', ['--alternate-editor=false', '--socket-name', this.socket, '--eval', '(kill-emacs)'], { timeout: 20_000 }); }
    catch { /* The owned server may close its response transport while exiting. */ }
    await until(() => this.emacs.exitCode !== null || this.emacs.signalCode !== null, 'owned Emacs exit', 20_000);
  }

  async peer(runtime) {
    const socket = runtime.socket;
    assert.ok(socket.startsWith(this.env.PIMUX_DIR + path.sep));
    const require = createRequire(path.join(this.release.prefix, 'package.json'));
    const { isReadOnlyCommand } = require('@phimacs/pimux/protocol');
    const peer = await ReleasePeer.connect(socket, isReadOnlyCommand);
    this.peers.add(peer);
    return peer;
  }

  async browser() {
    const require = createRequire(path.join(this.release.prefix, 'package.json'));
    const { Cdp } = require('pi-browser/cdp');
    const binary = process.env.CHROMIUM_BINARY ?? '/usr/bin/chromium';
    assert.ok(path.isAbsolute(binary) && fs.existsSync(binary), 'Chromium is an explicit system prerequisite');
    this.chromium = this.child(binary, ['--headless=new', '--no-first-run', '--no-default-browser-check', '--disable-dev-shm-usage',
      '--remote-debugging-port=0', `--user-data-dir=${path.join(this.root, 'chromium')}`,
      ...(process.env.PHIMACS_TEST_CHROMIUM_NO_SANDBOX === '1' ? ['--no-sandbox'] : []), 'about:blank']);
    const endpoint = await until(() => {
      if (this.chromium.failure || this.chromium.exitCode !== null || this.chromium.signalCode !== null) throw new Error(`Chromium startup failed: ${this.chromium.log}`);
      return /DevTools listening on (ws:\/\/[^\s]+)/.exec(this.chromium.log)?.[1];
    }, 'synthetic Chromium debugging socket');
    this.cdp = await Cdp.connect(endpoint);
    const { targetId } = await this.cdp.request('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await this.cdp.request('Target.attachToTarget', { targetId, flatten: true });
    this.page = this.cdp.session(sessionId);
    await this.page.request('Page.enable');
    await this.page.request('Runtime.enable');
    await this.page.request('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 1, mobile: true });
    this.javascriptDialogs ??= [];
    this.page.onEvent((method, params) => {
      if (method === 'Page.javascriptDialogOpening') {
        this.javascriptDialogs.push(params);
        void this.page.request('Page.handleJavaScriptDialog', { accept: true }).catch(error => this.log.push(error.message));
      }
    });
    return this.page;
  }

  async evaluate(expression) {
    const result = await this.page.request('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
    if (result.exceptionDetails) throw new Error(`Browser expression failed: ${JSON.stringify(result.exceptionDetails)}`);
    return result.result?.value;
  }

  async navigate(url) {
    await this.page.request('Page.navigate', { url });
    await until(() => this.evaluate('!!document.querySelector("#message-input")'), 'Tau browser composer');
  }

  async click(selector) {
    return this.evaluate(`(() => { const node = document.querySelector(${JSON.stringify(selector)}); if (!node) throw Error('Missing control: ' + ${JSON.stringify(selector)}); node.click(); return true; })()`);
  }

  async compose(text, send = true) {
    await this.evaluate(`(() => { const node = document.querySelector('#message-input'); Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(node, ${JSON.stringify(text)}); node.dispatchEvent(new Event('input', { bubbles: true })); })()`);
    if (send) await this.click('#send-btn');
  }

  async copyPrefix(label) {
    const prefix = path.join(this.root, `frontend-${label}`);
    fs.cpSync(this.release.prefix, prefix, { recursive: true, verbatimSymlinks: true });
    this.copies.push(prefix);
    releasePaths(prefix, { sourceOnly: this.release.sourceOnly });
    return prefix;
  }

  async cleanup() {
    const errors = [];
    for (const peer of this.peers) peer.close();
    this.cdp?.close();
    try { await this.stopEmacs(); } catch (error) { errors.push(error); }
    for (const child of this.children) {
      try { await this.stopChild(child); } catch (error) { errors.push(error); }
    }
    // Enumerate only this marked namespace, also when startup failed before its
    // creating view received/saved the committed runtime receipt.
    try {
      const entries = await this.list();
      for (const entry of entries) {
        try { await this.command(this.release.pimux, ['stop', '--json', '--id', entry.muxId], { timeout: 60_000 }); }
        catch (error) { errors.push(new Error(`Cannot reconcile synthetic runtime ${entry.muxId}: ${error.message}`)); }
      }
      for (const entry of this.observed.values()) {
        for (const identity of [entry.ownerIdentity, entry.piIdentity].filter(Boolean)) {
          if (this.identities.processIdentityStatus(identity) !== 'dead') errors.push(new Error(`Synthetic process is still live/uncertain: ${JSON.stringify(identity)}`));
        }
      }
    } catch (error) { errors.push(error); }
    if (errors.length) {
      for (const [index, child] of [...this.children].entries()) fs.writeFileSync(path.join(this.root, `frontend-${index}.log`), child.log);
      throw new AggregateError([this.failure, ...errors].filter(Boolean), `Cleanup uncertain; retained evidence: ${this.root}`);
    }
    // Installed immutable source/assets can contain non-writable directories.
    // Make only this marked synthetic copy removable, without following links
    // back into the selected immutable release or a different filesystem tree.
    const makeRemovable = directory => {
      fs.chmodSync(directory, 0o700);
      for (const item of fs.readdirSync(directory, { withFileTypes: true })) {
        if (item.isDirectory() && !item.isSymbolicLink()) makeRemovable(path.join(directory, item.name));
      }
    };
    makeRemovable(this.root);
    fs.rmSync(this.root, { recursive: true, force: true });
  }
}

export class ReleasePeer {
  constructor(socket, isReadOnlyCommand) {
    this.socket = socket; this.records = []; this.pending = ''; this.nextId = 0; this.closed = false;
    this.isReadOnlyCommand = isReadOnlyCommand;
    this.ready = false; this.snapshot = null;
    socket.on('data', chunk => {
      this.pending += chunk.toString();
      let boundary;
      while ((boundary = this.pending.indexOf('\n')) >= 0) {
        const line = this.pending.slice(0, boundary).replace(/\r$/, '');
        this.pending = this.pending.slice(boundary + 1);
        if (line) {
          const record = JSON.parse(line);
          if (['pimux_gap', 'pimux_session_changed', 'pimux_tree_changed', 'pimux_snapshot_failed'].includes(record.type)) this.ready = false;
          if (record.type === 'pimux_snapshot') { this.snapshot = record; this.ready = false; }
          if (record.type === 'pimux_live' && record.generation === this.snapshot?.generation) this.ready = !!this.snapshot.inputContext;
          this.records.push(record);
        }
      }
    });
    socket.on('error', error => { this.error = error; });
    socket.on('close', () => { this.closed = true; });
  }
  static async connect(socketPath, isReadOnlyCommand) {
    const peer = new ReleasePeer(net.connect(socketPath), isReadOnlyCommand);
    await peer.wait(record => record.type === 'pimux_live', 'equal peer initial live');
    const hello = peer.records.find(record => record.type === 'pimux_hello');
    assert.equal(hello.protocol, 2);
    assert.ok(hello.capabilities.includes('contextual-input'));
    assert.equal(peer.ready, true);
    assert.equal('role' in hello, false);
    return peer;
  }
  send(command) {
    let outbound = command;
    if (!this.isReadOnlyCommand(command.type) && !command.type.startsWith('pimux_')) {
      assert.ok(this.ready && this.snapshot?.inputContext, 'Mutation requires a matching authoritative snapshot/live boundary');
      outbound = { ...command, pimuxContext: command.pimuxContext ?? { ...this.snapshot.inputContext } };
    }
    this.socket.write(JSON.stringify(outbound) + '\n');
  }
  async request(command) {
    const id = `release-peer-${++this.nextId}`;
    const start = this.records.length;
    this.send({ ...command, id });
    const response = await this.wait(record => record.type === 'response' && record.id === id, command.type, start);
    assert.equal(response.success, true, JSON.stringify(response));
    return response;
  }
  wait(predicate, label, start = 0) {
    return until(() => {
      const record = this.records.slice(start).find(predicate);
      if (record) return record;
      if (this.error) throw this.error;
      if (this.closed) throw new Error(`Peer closed before ${label}`);
      return false;
    }, label);
  }
  close() { this.socket.destroy(); }
}
