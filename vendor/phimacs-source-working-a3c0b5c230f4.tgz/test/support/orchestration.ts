/** Integration-only access to fixtures and worker implementation details.
 * Not a runtime package export and never included in release artifacts.
 */
export { forkFixture } from "../../packages/orchestration/test/fork-fixture.ts";
export {
  default as workerFrame,
  createWorkerArtifacts,
  parseWorkerResult,
  readWorkerStatus,
  writeWorkerRequest,
} from "../../packages/orchestration/worker-frame.ts";

export { parseWebEndpoint } from "../../packages/orchestration/hosts/web.ts";
export { prepareHerdrSwitch, switchEnvironment } from "../../packages/orchestration/switch-destinations.ts";
export { localTauConnection } from "../../packages/orchestration/tau-server.ts";
export {
  ownTakeSocket, takeSocket, listenTake, requestTake, listTakeCandidates,
} from "../../packages/orchestration/session-take.ts";
export type { TakeDescription } from "../../packages/orchestration/session-take.ts";
