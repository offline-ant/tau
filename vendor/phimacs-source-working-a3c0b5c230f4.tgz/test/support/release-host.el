;;; release-host.el --- Installed release acceptance peer -*- lexical-binding: t; -*-
;; SPDX-License-Identifier: MIT
;;; Commentary:
;; Test-only public API driver.  Product sources/assets are selected exclusively
;; beneath PHIMACS_RUNTIME_PREFIX; no user init or package cache is loaded.
;;; Code:
(require 'cl-lib)
(require 'json)
(require 'seq)

(defvar release-host--views (make-hash-table :test 'equal))
(defvar release-host--inputs (make-hash-table :test 'equal))
(defvar release-host--responses (make-hash-table :test 'equal))
(defvar release-host--ready (make-hash-table :test 'equal))
(defvar release-host--stops (make-hash-table :test 'equal))
(defvar release-host--confirmations nil)

(defun release-host--unexpected-confirmation (&rest arguments)
  "Record and refuse unexpected confirmation ARGUMENTS instead of hanging."
  (push (format "%S" arguments) release-host--confirmations)
  (error "Unexpected confirmation during Close regression: %S" arguments))

(dolist (function '(y-or-n-p yes-or-no-p x-popup-dialog))
  (advice-add function :before #'release-host--unexpected-confirmation))

(let* ((assets (getenv "PHIMACS_RELEASE_ASSETS"))
       (receipt (with-temp-buffer
                  (insert-file-contents (expand-file-name "provision.json" assets))
                  (json-parse-buffer :object-type 'plist))))
  (dolist (package (append (plist-get receipt :packages) nil))
    (dolist (directory (append (plist-get package :loadPaths) nil))
      (add-to-list 'load-path (expand-file-name directory assets))))
  (setq treesit-extra-load-path
        (delete-dups
         (mapcar (lambda (artifact)
                   (file-name-directory
                    (expand-file-name (plist-get artifact :path) assets)))
                 (append (plist-get (plist-get receipt :grammars) :artifacts) nil))))
  (setq ghostel-module-directory
        (file-name-directory
         (expand-file-name (plist-get (plist-get receipt :native) :path) assets))))
(add-to-list 'load-path (getenv "PHIMACS_RELEASE_PILISH"))
(add-to-list 'load-path (expand-file-name "lisp/pi-deck" (getenv "PHIMACS_RUNTIME_PREFIX")))
(setq native-comp-jit-compilation nil
      pilish-essential-grammar-action 'warn
      pilish-extension-dialog-style 'inline
      pilish-chat-style 'pi
      pilish-input-window-height 'fit
      pilish-send-while-busy 'steer
      pi-deck-state-file (expand-file-name "deck-state.eld" (getenv "PHIMACS_TEST_ROOT")))
(require 'pilish)
(require 'pi-deck)
(unless (and (equal (plist-get (pilish-integration-capabilities) :api-version) 1)
             (equal (plist-get (pilish-integration-capabilities) :pimux-protocol) 2)
             (plist-get (pilish-integration-capabilities) :authoritative-close)
             (plist-get (pi-deck-integration-capabilities) :detached-desktop-restore))
  (error "Installed release lacks the required public detached API"))
(pilish-configure-runtime :pi-executable (getenv "PHIMACS_RELEASE_PI")
                          :pimux-executable (getenv "PHIMACS_RELEASE_PIMUX")
                          :task-status-executable (getenv "PHIMACS_RELEASE_TASK_STATUS")
                          :protocol 2 :pi-version "1.4.0"
                          :pi-sha256 (getenv "PHIMACS_PI_SHA256"))
(setq pilish-extra-args
      (list "--no-extensions" "--no-skills" "--no-context-files" "--no-prompt-templates"
            "--extension" (getenv "PHIMACS_RELEASE_FAUX")
            "--provider" "release-faux" "--model" "one" "--thinking" "off"))
(pi-deck-mode 1)

(defun release-host--chat (name)
  "Return the named test view NAME or fail."
  (let ((chat (gethash name release-host--views)))
    (unless (buffer-live-p chat) (error "No live acceptance view: %s" name))
    chat))

(defun release-host-create (name)
  "Start an intentional new managed session named NAME."
  (let ((chat (pilish-start-session
               (getenv "PHIMACS_RELEASE_PROJECT") name
               :on-ready (lambda (result) (puthash name result release-host--ready)))))
    (puthash name chat release-host--views)
    name))

(defun release-host-attach (mux name)
  "Attach the existing MUX using the public API, naming its view NAME."
  (let ((runtime (seq-find (lambda (item) (equal (plist-get item :mux-id) mux))
                           (pilish-list-runtimes))))
    (unless runtime (error "Runtime is absent; attachment does not launch: %s" mux))
    (puthash name (pilish-attach-runtime runtime name) release-host--views)
    name))

(defun release-host-state (name)
  "Report only public state of the named acceptance view NAME."
  (let* ((chat (gethash name release-host--views))
         (alive (buffer-live-p chat))
         (input (if alive (pilish-session-input-buffer chat)
                  (gethash name release-host--inputs))))
    (when alive (puthash name input release-host--inputs))
    (if (not alive)
        `((alive . :json-false)
          (inputAlive . ,(if (buffer-live-p input) t :json-false))
          (tracked . ,(if (pi-deck-agent chat) t :json-false))
          (stop . ,(gethash name release-host--stops))
          (confirmations . ,(vconcat release-host--confirmations)))
      `((alive . t)
      (inputAlive . ,(if (buffer-live-p input) t :json-false))
      (tracked . ,(if (pi-deck-agent chat) t :json-false))
      (confirmations . ,(vconcat release-host--confirmations))
      (runtime . ,(pilish-session-runtime chat))
      (identity . ,(pilish-session-process-identity chat))
      (file . ,(pilish-session-file chat))
      (model . ,(pilish-session-model chat))
      (busy . ,(if (pilish-session-busy-p chat) t :json-false))
      (draft . ,(if (buffer-live-p input)
                    (with-current-buffer input (buffer-substring-no-properties (point-min) (point-max))) ""))
      (quarantine . ,(vconcat (pilish-session-quarantine chat)))
      (dialogs . ,(vconcat (pilish-session-pending-dialogs chat)))
      (queued . ,(pilish-session-queued-prompts chat))
      (ready . ,(gethash name release-host--ready))
      (response . ,(gethash name release-host--responses))
      (stop . ,(gethash name release-host--stops))
      (text . ,(with-current-buffer chat (buffer-substring-no-properties (point-min) (point-max))))))))

(defun release-host-prompt (name text &optional behavior)
  "Submit explicit TEXT from NAME with optional RPC BEHAVIOR."
  (remhash name release-host--responses)
  (pilish-submit-prompt (release-host--chat name) text
                       (lambda (response) (puthash name response release-host--responses)) behavior)
  t)

(defun release-host-draft (name text)
  "Edit the local public input buffer of NAME to TEXT, without submission."
  (with-current-buffer (pilish-session-input-buffer (release-host--chat name))
    (erase-buffer) (insert text))
  t)

(defun release-host-save (name file)
  "Save all public local desktop state of NAME into private FILE."
  (with-temp-file file
    (prin1 (pilish-session-desktop-state (release-host--chat name)) (current-buffer)))
  (set-file-modes file #o600)
  t)

(defun release-host-restore (name file &optional protocol)
  "Restore NAME from private FILE; optional PROTOCOL tests incompatible state."
  (let* ((state (with-temp-buffer (insert-file-contents file) (read (current-buffer))))
         (runtime (plist-get state :runtime)))
    (when protocol (setq runtime (plist-put runtime :protocol protocol)
                         state (plist-put state :runtime runtime)))
    (puthash name (pilish-restore-session-state state) release-host--views))
  t)

(defun release-host-disconnect (name)
  "Dispose only NAME's frontend view, as during frontend teardown."
  (pilish-disconnect-session (release-host--chat name))
  t)

(defun release-host-close (name &optional deck)
  "Close NAME everywhere without confirmation, through deck when DECK is non-nil."
  (remhash name release-host--stops)
  (let ((chat (release-host--chat name)))
    (if deck
        (let ((agent (pi-deck-agent chat)))
          (unless agent (error "Acceptance agent is not tracked by deck: %s" name))
          (pi-deck-close-agent agent))
      (pilish-close-session
       chat (lambda (error) (puthash name (or error "acknowledged") release-host--stops)))))
  t)

(defun release-host-wire (expression)
  "Return the JSON result of test EXPRESSION as one printable base64 string."
  (base64-encode-string
   (encode-coding-string (json-encode (eval (read expression) t)) 'utf-8) t))

(provide 'release-host)
;;; release-host.el ends here
