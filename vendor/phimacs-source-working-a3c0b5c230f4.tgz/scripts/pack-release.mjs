import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { packLisp } from './pack-lisp.mjs';
import { command, copyTree, digest, inventory, json, materializeBins, writeJson } from './release-files.mjs';
import { assertInternalResolutions, releaseLock } from './release-lock.mjs';
import { stageForks, stageReference } from './release-forks.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const order = ['pimux', 'orchestration', 'extensions', 'browser', 'sound'];
const selectedSources = () => Object.fromEntries(order.map(directory => [directory, inventory(path.join(root, 'packages', directory))]));

function packageInput(source, staging, tarballs, internal) {
  const manifest = json(path.join(source, 'package.json'));
  const packRoot = path.join(staging, manifest.name.replaceAll('/', '-'));
  fs.mkdirSync(packRoot);
  const [preview] = JSON.parse(command('npm', ['pack', '--dry-run', '--json', '--ignore-scripts'], source));
  for (const file of preview.files) {
    if (file.path === 'package.json' || file.path.startsWith('node_modules/') || file.path.startsWith('vendor/')) continue;
    const selected = path.resolve(source, file.path);
    if (!selected.startsWith(`${source}${path.sep}`) || fs.lstatSync(selected).isSymbolicLink()) throw new Error(`Unsafe package entry: ${file.path}`);
    copyTree(selected, path.join(packRoot, file.path));
  }
  // Development vendor packs identify the tested inputs, but release resolution
  // is coordinated here. No old embedded tarball remains in the installed pack.
  for (const name of Object.keys(manifest.dependencies ?? {})) {
    if (internal.has(name)) manifest.dependencies[name] = internal.get(name);
    else if (manifest.dependencies[name].startsWith('file:')) throw new Error(`Unreviewed external file dependency: ${name}`);
  }
  delete manifest.bundleDependencies;
  delete manifest.bundledDependencies;
  delete manifest.devDependencies;
  delete manifest.scripts;
  writeJson(path.join(packRoot, 'package.json'), manifest);
  const [receipt] = JSON.parse(command('npm', ['pack', '--offline', '--ignore-scripts', '--json', '--pack-destination', tarballs], packRoot));
  return { manifest, receipt };
}

/** Build private immutable inputs; never publish, select, start or migrate them. */
export function packRelease(destination, { offline = false, pilishSource, tauSource, emacsAssets } = {}) {
  const target = path.resolve(destination);
  if (process.platform !== 'linux' || process.arch !== 'x64') throw new Error('This release supports Linux x86-64 only');
  if (fs.existsSync(target)) throw new Error('Release destination already exists; choose a new versioned directory');
  const selection = json(path.join(root, 'release-manifest.json'));
  if (selection.runtime.pimuxProtocol !== 2 || !selection.runtime.detachedTargetImplemented) throw new Error('Incomplete detached release selection');
  const sourceBefore = selectedSources();
  fs.mkdirSync(target, { recursive: true, mode: 0o700 });
  const tarballs = path.join(target, 'tarballs');
  fs.mkdirSync(tarballs);
  const staging = fs.mkdtempSync(path.join(os.tmpdir(), 'phimacs-pack-'));
  const dependencies = { '@earendil-works/pi-coding-agent': '1.4.0', '@earendil-works/pi-agent-core': '1.4.0',
    '@earendil-works/pi-ai': '1.4.0', '@earendil-works/pi-tui': '1.4.0', typebox: '1.3.27' };
  const overrides = {};
  const artifacts = [];
  const packageEntries = {};
  try {
    const { tau, tauLock } = stageForks(target, staging, selection, { pilishSource, tauSource, offline });
    const sources = [...order.map(directory => path.join(root, 'packages', directory)), tau];
    const internal = new Map(sources.map(source => { const item = json(path.join(source, 'package.json')); return [item.name, item.version]; }));
    for (const source of sources) {
      const { manifest, receipt } = packageInput(source, staging, tarballs, internal);
      const specifier = `file:./tarballs/${receipt.filename}`;
      dependencies[manifest.name] = specifier;
      overrides[manifest.name] = specifier;
      artifacts.push({ name: manifest.name, version: manifest.version, file: `tarballs/${receipt.filename}`,
        sha256: digest(path.join(tarballs, receipt.filename)), integrity: receipt.integrity });
      packageEntries[`node_modules/${manifest.name}`] = { ...manifest, resolved: `file:tarballs/${receipt.filename}`, integrity: receipt.integrity };
    }
    const manifest = { name: 'phimacs-release', version: selection.version, private: true, type: 'module', dependencies, overrides };
    writeJson(path.join(target, 'package.json'), manifest);
    const workspaceLock = json(path.join(root, 'package-lock.json'));
    const workspaces = order.map(directory => ({ source: `packages/${directory}/`,
      installed: `node_modules/${json(path.join(root, 'packages', directory, 'package.json')).name}/` }));
    const candidateLock = releaseLock(workspaceLock, { manifest, packageEntries, workspaces, tauLock });
    assertInternalResolutions(candidateLock, artifacts);
    writeJson(path.join(target, 'package-lock.json'), candidateLock);
    command('npm', ['ci', '--ignore-scripts', '--omit=dev', '--omit=peer', ...(offline ? ['--offline'] : [])], target, { offline });
    assertInternalResolutions(json(path.join(target, 'package-lock.json')), artifacts);
    materializeBins(path.join(target, 'node_modules'));
    const lisp = packLisp(path.join(target, 'lisp/archives')).map(item => ({ ...item, file: `archives/${item.file}` }));
    for (const item of lisp) {
      const destination = path.join(target, 'lisp', item.name);
      fs.mkdirSync(destination);
      command('tar', ['-xzf', path.join(target, 'lisp', item.file), '--strip-components=1', '--no-same-owner', '-C', destination], target);
    }
    const reference = stageReference(root, target, emacsAssets, selection);
    for (const directory of ['docs', 'provenance']) copyTree(path.join(root, directory), path.join(target, directory));
    for (const file of ['README.md', 'LICENSE']) if (fs.existsSync(path.join(root, file))) copyTree(path.join(root, file), path.join(target, file));
    for (const file of ['release-launch.mjs', 'emacs-environment.mjs', 'install-release.mjs', 'install-release.sh']) copyTree(path.join(root, 'scripts', file), path.join(target, 'scripts', file));
    fs.mkdirSync(path.join(target, 'bin'));
    for (const action of ['phimacs', 'pi', 'pimux', 'pi-tau-web-server']) {
      const mode = { phimacs: '', pi: 'pi', pimux: 'pimux', 'pi-tau-web-server': 'tau' }[action];
      fs.writeFileSync(path.join(target, 'bin', action), `#!/usr/bin/env node\nimport { launch } from '../scripts/release-launch.mjs';\nawait launch(${JSON.stringify(mode)}, process.argv.slice(2));\n`, { mode: 0o755 });
    }
    const piExecutable = 'node_modules/@earendil-works/pi-coding-agent/dist/bundle/cli.js';
    const release = { ...selection, status: 'private-hydrated-candidate', platform: process.platform,
      architecture: process.arch, node: process.versions.node,
      testedToolchain: { node: process.versions.node, npm: command('npm', ['--version'], root).trim(), emacs: reference.emacsVersion },
      pi: { version: '1.4.0', executable: piExecutable, sha256: digest(path.join(target, piExecutable)),
        directory: 'node_modules/@earendil-works/pi-coding-agent',
        files: inventory(path.join(target, 'node_modules/@earendil-works/pi-coding-agent')) }, sourcePackages: sourceBefore,
      artifacts, lisp, reference, workspaceLockSha256: digest(path.join(root, 'package-lock.json')),
      tauDevelopmentLockSha256: digest(path.join(tau, 'package-lock.json')),
      lockSha256: digest(path.join(target, 'package-lock.json')),
      gates: { detachedImplementation: true, managedLaunchOwnership: true,
        universalPiStorageOwnership: false, packedAcceptanceEvidenceRequired: true, publicReleaseApproved: false } };
    if (JSON.stringify(selectedSources()) !== JSON.stringify(sourceBefore)) throw new Error('Package sources/build outputs changed during packaging; rebuild a new candidate');
    writeJson(path.join(target, 'release-manifest.json'), release);
    writeJson(path.join(target, 'integrity.json'), { schemaVersion: 1, files: inventory(target) });
    return release;
  } catch (error) {
    fs.writeFileSync(path.join(target, 'INCOMPLETE'), 'Packaging failed. This directory is not an installable release.\n');
    throw error;
  } finally {
    fs.chmodSync(staging, 0o700);
    fs.rmSync(staging, { recursive: true, force: true });
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const options = {};
  let destination;
  for (let index = 2; index < process.argv.length; index++) {
    const arg = process.argv[index];
    if (arg === '--offline') options.offline = true;
    else if (['--destination', '--pilish-source', '--tau-source', '--emacs-assets'].includes(arg)) {
      const value = process.argv[++index];
      if (!value || value.startsWith('--')) throw new Error(`Missing ${arg}`);
      if (arg === '--destination') destination = value;
      else options[{ '--pilish-source': 'pilishSource', '--tau-source': 'tauSource', '--emacs-assets': 'emacsAssets' }[arg]] = path.resolve(value);
    } else throw new Error(`Unknown option: ${arg}`);
  }
  if (!destination) throw new Error('Usage: pack-release.mjs --destination NEW --pilish-source ARCHIVE --tau-source ARCHIVE --emacs-assets DIRECTORY [--offline]');
  console.log(JSON.stringify(packRelease(destination, options), null, 2));
}
