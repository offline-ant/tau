/** Convert reviewed workspace resolutions into an installed, tarball-only graph. */
export function releaseLock(workspaceLock, { manifest, packageEntries, workspaces, tauLock }) {
  const locked = {};
  for (const [location, entry] of Object.entries(workspaceLock.packages)) {
    if (entry.link) continue;
    if (location.startsWith('node_modules/')) locked[location] = { ...entry };
    else {
      const owner = workspaces.find(({ source }) => location.startsWith(`${source}node_modules/`));
      if (owner) locked[owner.installed + location.slice(owner.source.length)] = { ...entry };
    }
  }
  if (tauLock) {
    // Tau consumes the release's canonical exact Pi host graph, not a second
    // SDK tree from its independently verified development lock. Its sole other
    // external runtime dependency retains that lock's exact own ws resolution.
    const tau = packageEntries['node_modules/pi-tau-web-server'];
    const ws = tauLock.packages['node_modules/ws'];
    if (!tau || !ws?.integrity || ws.version !== tau.dependencies.ws) throw new Error('Tau ws is not bound to its reviewed lock');
    if (tau.dependencies['@earendil-works/pi-coding-agent'] !== manifest.dependencies['@earendil-works/pi-coding-agent']) throw new Error('Tau/Pi host versions disagree');
    locked['node_modules/pi-tau-web-server/node_modules/ws'] = { ...ws };
  }
  return { name: manifest.name, version: manifest.version, lockfileVersion: 3, requires: true,
    packages: { '': { name: manifest.name, version: manifest.version, dependencies: manifest.dependencies }, ...locked, ...packageEntries } };
}

export function assertInternalResolutions(lock, artifacts) {
  const internal = new Set(artifacts.map(item => item.name));
  for (const [location, entry] of Object.entries(lock.packages)) {
    if (entry.link) throw new Error(`Workspace link in installed lock: ${location}`);
    const name = location.split('/node_modules/').at(-1).replace(/^node_modules\//, '');
    if (internal.has(name) && !/^file:tarballs\//.test(entry.resolved ?? '')) throw new Error(`Internal registry fallback: ${name}`);
    if (/\/node_modules\/@earendil-works\/pi-(coding-agent|agent-core|ai|tui)$/.test(location)) throw new Error(`Nested host SDK: ${location}`);
  }
  for (const item of artifacts) {
    if (lock.packages[`node_modules/${item.name}`]?.resolved !== `file:${item.file}`) throw new Error(`Internal artifact resolution changed: ${item.name}`);
  }
}
