#!/usr/bin/env node
/** Start a dedicated Emacs endpoint, never a provider/runtime or user service by default. */
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import { pathToFileURL } from 'node:url';
import { childEnvironment, configDirectory, inspectEnvironment, parseOptions } from './emacs-environment.mjs';

async function processStart(pid) {
  try {
    const stat = await fs.readFile(`/proc/${pid}/stat`, 'utf8');
    return stat.slice(stat.lastIndexOf(')') + 2).split(' ')[19];
  } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}

function probe(options, run = spawnSync) {
  const result = run(options.client, ['--alternate-editor=false', '--socket-name', options.socket, '--eval', 't'], {
    encoding: 'utf8', timeout: 2000,
  });
  if (result.error?.code === 'ETIMEDOUT' || result.signal) throw new Error('Emacs endpoint is unresponsive; refusing to start a replacement');
  return result.status === 0;
}

async function privateDirectory(directory) {
  try { await fs.mkdir(directory, { mode: 0o700 }); }
  catch (error) { if (error.code !== 'EEXIST') throw error; }
  const info = await fs.lstat(directory);
  if (!info.isDirectory() || info.isSymbolicLink() || info.uid !== process.getuid() || (info.mode & 0o077) !== 0) {
    throw new Error('Emacs state/socket directories must be owned by you with mode 0700');
  }
}

export async function ensureDaemon(options, { inspect = inspectEnvironment, run = spawnSync,
  spawnProcess = spawn, timeoutMs = 60_000, pause = delay } = {}) {
  const report = await inspect(options);
  if (!report.ok) throw new Error(report.issues.join('\n'));
  if (options.restartAfter) {
    if (!/^\d+$/.test(options.restartAfter) || !options.restartStart) throw new Error('Restart requires PID and its recorded --restart-start identity');
    const deadline = Date.now() + timeoutMs;
    while (await processStart(options.restartAfter) === options.restartStart) {
      if (Date.now() >= deadline) throw new Error('Old Emacs still lives; restart refused without signalling it');
      await pause(50);
    }
  }
  await fs.mkdir(path.dirname(options.state), { recursive: true });
  await privateDirectory(options.state);
  await privateDirectory(path.dirname(options.socket));
  if (probe(options, run)) return { outcome: 'connected', socket: options.socket };
  if (await fs.lstat(options.socket).catch(() => null)) throw new Error('Existing Emacs socket is unavailable; inspect its owner before cleanup');
  const lock = path.join(options.state, 'emacs-start.lock');
  try { await fs.mkdir(lock, { mode: 0o700 }); }
  catch (error) {
    if (error.code === 'EEXIST') throw new Error('Another or interrupted Emacs startup owns the lock; inspect before recovery');
    throw error;
  }
  const lockIdentity = await fs.lstat(lock);
  let child;
  let identity;
  let log;
  let committed = false;
  let supervisorAttempted = false;
  try {
    await fs.writeFile(path.join(lock, 'owner.json'), JSON.stringify({ pid: process.pid, start: await processStart(process.pid) }), { flag: 'wx', mode: 0o600 });
    if (options.mode === 'supervised') {
      if (!options.supervisor) throw new Error('Supervised mode requires an explicit --supervisor-command; no service is installed automatically');
      supervisorAttempted = true;
      const result = run(options.supervisor, options.supervisorArgs, { encoding: 'utf8', timeout: 10_000, env: childEnvironment(options) });
      if (result.error || result.status !== 0) throw new Error('Configured supervisor start command failed; no unmanaged daemon was launched. Inspect the startup lock before retrying');
    } else {
      log = await fs.open(path.join(options.state, 'emacs-start.log'), 'w', 0o600);
      child = spawnProcess(options.emacs, [`--init-directory=${configDirectory}`, `--fg-daemon=${options.socket}`], {
        detached: true, stdio: ['ignore', log.fd, log.fd], env: childEnvironment(options),
      });
      let spawnError;
      child.once('error', error => { spawnError = error; });
      await new Promise(resolve => { child.once('spawn', resolve); child.once('error', resolve); });
      if (spawnError || !child.pid) throw new Error(`Cannot launch Emacs: ${spawnError?.message ?? 'no process identity'}`);
      identity = await processStart(child.pid);
      if (!identity) throw new Error('Emacs exited before publishing its process identity; inspect emacs-start.log');
    }
    const deadline = Date.now() + timeoutMs;
    while (!probe(options, run)) {
      if (child && await processStart(child.pid) !== identity) throw new Error('Candidate Emacs exited before readiness; inspect emacs-start.log');
      if (Date.now() >= deadline) throw new Error('Emacs startup not ready before deadline; no replacement retry was attempted');
      await pause(50);
    }
    committed = true;
    child?.unref();
    return { outcome: options.mode === 'manual' ? 'started' : 'supervisor-started', socket: options.socket };
  } finally {
    if (!committed && child?.pid && identity && await processStart(child.pid) === identity) {
      // Only this uncommitted child/group is ours. Never signal a discovered peer.
      try { process.kill(-child.pid, 'SIGTERM'); } catch (error) { if (error.code !== 'ESRCH') throw error; }
      const deadline = Date.now() + 5000;
      while (await processStart(child.pid) === identity && Date.now() < deadline) await pause(50);
      if (await processStart(child.pid) === identity) throw new Error('Owned startup child is still exiting; retain the startup lock and inspect it');
    }
    await log?.close();
    // An external supervisor may still be acting after command failure/timeout.
    // Preserve uncertainty rather than treating it as proof no owner can appear.
    if (committed || !supervisorAttempted) {
      const current = await fs.lstat(lock).catch(() => null);
      if (current?.ino === lockIdentity.ino && current?.dev === lockIdentity.dev) await fs.rm(lock, { recursive: true });
    }
  }
}

export async function launch(argv) {
  const options = parseOptions(argv);
  const receipt = await ensureDaemon(options);
  if (options.noFrame) {
    if (options.json) console.log(JSON.stringify(receipt));
    return 0;
  }
  // The client keeps the caller's display/terminal, not the daemon's cleaned env.
  const result = spawnSync(options.client, ['--alternate-editor=false', '--socket-name', options.socket,
    ...(options.gui ? ['--create-frame'] : ['--tty']), ...options.clientArgs], { stdio: 'inherit' });
  if (result.error) throw result.error;
  return result.status ?? 1;
}
if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  launch(process.argv.slice(2)).then(code => { process.exitCode = code; })
    .catch(error => { console.error(error.message); process.exitCode = 1; });
}
