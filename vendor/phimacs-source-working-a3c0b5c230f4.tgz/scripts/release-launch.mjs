#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { verifyHost } from '@phimacs/pimux/host';
import { parseArgs } from '@earendil-works/pi-coding-agent';

const release = path.resolve(fileURLToPath(new URL('../', import.meta.url)));

export async function launch(action, args) {
  const manifest = JSON.parse(fs.readFileSync(path.join(release, 'release-manifest.json'), 'utf8'));
  if (fs.existsSync(path.join(release, 'INCOMPLETE')) || manifest.runtime?.pimuxProtocol !== 2) throw new Error('Select a complete supported release');
  if (!manifest.pi.files || !manifest.pi.directory) throw new Error('Release lacks the complete host integrity inventory');
  const hostRoot = path.resolve(release, manifest.pi.directory);
  if (!hostRoot.startsWith(`${release}${path.sep}`)) throw new Error('Host path escapes release');
  for (const [relative, item] of Object.entries(manifest.pi.files)) {
    const file = path.resolve(hostRoot, relative);
    if (!file.startsWith(`${hostRoot}${path.sep}`) || !fs.lstatSync(file).isFile()
        || createHash('sha256').update(fs.readFileSync(file)).digest('hex') !== item.sha256) throw new Error(`Modified host runtime file: ${relative}`);
  }
  const host = verifyHost(path.join(release, manifest.pi.executable), { version: manifest.pi.version, sha256: manifest.pi.sha256 });
  const state = process.env.PHIMACS_STATE_DIR || path.join(process.env.XDG_STATE_HOME || path.join(os.homedir(), '.local/state'), 'phimacs');
  const env = { ...process.env, PHIMACS_RELEASE_DIR: release, PHIMACS_STATE_DIR: state,
    PHIMACS_EMACS_ASSETS: path.join(release, manifest.reference.assets),
    PHIMACS_PILISH_DIR: path.join(release, manifest.externalForks.pilish.directory),
    PHIMACS_PI: host.executable, TAU_PI_COMMAND: host.executable,
    PHIMACS_PI_VERSION: host.version, PHIMACS_PI_SHA256: host.sha256,
    PHIMACS_TAU: path.join(release, 'node_modules/pi-tau-web-server/bin/tau.js'),
    PHIMACS_EMACS_LAUNCHER: path.join(release, 'scripts/emacs-launch.mjs'),
    PI_CODING_AGENT_DIR: process.env.PI_CODING_AGENT_DIR || path.join(state, 'agent') };
  if (!action) { action = args.shift() || 'emacs'; }
  let executable = process.execPath;
  let argv;
  if (['emacs', 'setup', 'doctor'].includes(action)) {
    argv = [path.join(release, 'scripts', { emacs: 'emacs-launch.mjs', setup: 'emacs-setup.mjs', doctor: 'emacs-doctor.mjs' }[action]), ...args];
  } else if (action === 'pi') {
    // Administrative read-only CLI forms do not open a session or need a claim.
    // Every serving native invocation goes through the same managed owner.
    const parsed = parseArgs(args);
    const administrative = parsed.version || parsed.help || parsed.listModels;
    argv = administrative ? [host.executable, ...args] : [path.join(release, 'node_modules/@phimacs/pimux/bin/pimux'), 'tui', '--', host.executable, ...args];
    for (const key of Object.keys(env)) if (/^(PI_ORCHESTRATION_|PI_WORKER_|PHIMACS_PARENT_TASK|PHIMACS_MANAGED_CLAIM)/.test(key)) delete env[key];
  } else if (action === 'pimux') {
    if (['start', 'tui'].includes(args[0])) {
      const separator = args.indexOf('--');
      const selected = separator >= 0 ? args[separator + 1] : undefined;
      if (!selected || fs.realpathSync(selected) !== host.executable) throw new Error('Managed release pimux must use this release\'s absolute Pi executable');
    }
    argv = [path.join(release, 'node_modules/@phimacs/pimux/bin/pimux'), ...args];
  } else if (action === 'tau') {
    if (args.some(arg => arg === '--pi-command' || arg.startsWith('--pi-command='))) throw new Error('Release Tau uses its selected immutable Pi; select another complete release instead');
    argv = [env.PHIMACS_TAU, ...args];
  }
  else throw new Error('Usage: phimacs {emacs|setup|doctor|pi|pimux|tau} [arguments]');
  const child = spawn(executable, argv, { env, stdio: 'inherit' });
  const handlers = new Map();
  for (const signal of ['SIGTERM', 'SIGINT', 'SIGHUP']) {
    const handler = () => child.kill(signal);
    handlers.set(signal, handler);
    process.on(signal, handler);
  }
  await new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('close', (code, signal) => { process.exitCode = code ?? (signal ? 128 + (signal === 'SIGINT' ? 2 : 15) : 1); resolve(); });
  }).finally(() => { for (const [signal, handler] of handlers) process.off(signal, handler); });
}
