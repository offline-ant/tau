import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';

export const digest = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
export const json = file => JSON.parse(fs.readFileSync(file, 'utf8'));
export const writeJson = (file, value) => fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`);

export function command(executable, args, cwd, { offline = false, env = {} } = {}) {
  const result = spawnSync(executable, args, { cwd, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024,
    env: { ...process.env, npm_config_ignore_scripts: 'true', ...(offline ? { npm_config_offline: 'true' } : {}), ...env } });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${executable} ${args.join(' ')} failed:\n${result.stderr || result.stdout}`);
  return result.stdout;
}

/** Copy immutable inputs without carrying source-tree or external symlinks. */
export function copyTree(source, target) {
  const identity = fs.lstatSync(source);
  if (identity.isSymbolicLink()) throw new Error(`Symlink in release input: ${source}`);
  if (identity.isDirectory()) {
    fs.mkdirSync(target, { recursive: true, mode: 0o755 });
    for (const name of fs.readdirSync(source)) copyTree(path.join(source, name), path.join(target, name));
  } else if (identity.isFile()) {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(source, target);
    fs.chmodSync(target, identity.mode & 0o111 ? 0o755 : 0o644);
  } else throw new Error('Only regular files/directories are release inputs');
}

export function inventory(directory) {
  const files = {};
  const visit = (relative = '') => {
    for (const name of fs.readdirSync(path.join(directory, relative)).sort()) {
      const entry = path.join(relative, name);
      const file = path.join(directory, entry);
      const stat = fs.lstatSync(file);
      if (stat.isDirectory()) visit(entry);
      else if (stat.isSymbolicLink()) {
        const link = fs.readlinkSync(file);
        if (path.isAbsolute(link) || !fs.realpathSync(file).startsWith(`${fs.realpathSync(directory)}${path.sep}`)) throw new Error(`Escaping release link: ${entry}`);
        files[entry] = { link };
      } else if (stat.isFile()) files[entry] = { sha256: digest(file), executable: (stat.mode & 0o111) !== 0 };
      else throw new Error(`Special file in release: ${entry}`);
    }
  };
  visit();
  return files;
}

/** Keep npm executable routing relocatable without shipping any filesystem links. */
export function materializeBins(directory) {
  const visit = current => {
    for (const name of fs.readdirSync(current)) {
      const file = path.join(current, name);
      const stat = fs.lstatSync(file);
      if (stat.isDirectory()) visit(file);
      else if (stat.isSymbolicLink()) {
        const destination = fs.realpathSync(file);
        const relative = path.relative(path.dirname(file), destination);
        if (path.basename(path.dirname(file)) !== '.bin' || !destination.startsWith(`${fs.realpathSync(directory)}${path.sep}`)
            || !/^[A-Za-z0-9@._/-]+$/.test(relative) || !fs.statSync(destination).isFile()) throw new Error(`Unsupported release link: ${file}`);
        fs.unlinkSync(file);
        fs.writeFileSync(file, `#!/bin/sh\nexec "$(dirname "$0")/${relative}" "$@"\n`, { mode: 0o755 });
      }
    }
  };
  visit(directory);
}

/** Fork archives are already bound by a reviewed full-revision SHA-256. */
export function extractPinnedArchive(archive, target, expected) {
  if (!/^[a-f0-9]{64}$/.test(expected ?? '') || digest(archive) !== expected) throw new Error('Retained source archive hash mismatch');
  const entries = command('tar', ['-tf', path.resolve(archive)], undefined).trim().split('\n');
  for (const entry of entries) {
    if (!entry || entry.startsWith('/') || entry.includes('\\') || entry.split('/').includes('..')) throw new Error('Unsafe retained source path');
  }
  fs.mkdirSync(target, { recursive: true, mode: 0o700 });
  command('tar', ['-xf', path.resolve(archive), '--no-same-owner', '--no-same-permissions', '-C', target], undefined);
  // Preserve immutable source archives byte-for-byte, but materialize internal
  // file aliases (Tau's CLAUDE.md -> AGENTS.md) in the installed source tree.
  const check = directory => {
    for (const name of fs.readdirSync(directory)) {
      const file = path.join(directory, name);
      const stat = fs.lstatSync(file);
      if (stat.isDirectory()) check(file);
      else if (stat.isSymbolicLink()) {
        const resolved = fs.realpathSync(file);
        if (!resolved.startsWith(`${fs.realpathSync(target)}${path.sep}`) || !fs.statSync(resolved).isFile()) throw new Error('Escaping or non-file source alias');
        const bytes = fs.readFileSync(resolved);
        fs.unlinkSync(file);
        fs.writeFileSync(file, bytes, { mode: fs.statSync(resolved).mode & 0o111 ? 0o755 : 0o644 });
      } else if (!stat.isFile()) throw new Error('Unsupported retained fork entry');
    }
  };
  check(target);
}
