import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const definitions = [
  { name: "pi-deck", directory: "emacs/pi-deck", description: "Spaces and an agent sidebar for Pi", requires: '((emacs "31.1") (pilish "3.1.0") (ghostel "0.59.0") (transient "0.9.0"))' },
  { name: "pi-orchestration", directory: "packages/orchestration/emacs", licenseDirectory: "packages/orchestration", description: "Pi orchestration host for Pilish and Ghostel", requires: '((emacs "31.1") (pilish "3.1.0") (ghostel "0.59.0"))' },
  { name: "pi-sound", directory: "packages/sound/emacs", licenseDirectory: "packages/sound", description: "Explicitly configured voice dictation", requires: '((emacs "30.1"))' },
];

/** Lisp source archives only: dependencies/assets are separately pinned inputs. */
export function packLisp(destination) {
  fs.mkdirSync(destination, { recursive: true });
  const staging = fs.mkdtempSync(path.join(os.tmpdir(), "phimacs-lisp-"));
  const artifacts = [];
  try {
    for (const definition of definitions) {
      const name = `${definition.name}-0.1.0`;
      const directory = path.join(staging, name);
      fs.mkdirSync(directory);
      const source = path.join(root, definition.directory);
      const sourceFiles = fs.readdirSync(source).filter((file) => file.endsWith(".el") && !file.endsWith("-test.el"));
      for (const file of sourceFiles) fs.copyFileSync(path.join(source, file), path.join(directory, file));
      fs.copyFileSync(path.join(root, definition.licenseDirectory ?? definition.directory, "LICENSE"), path.join(directory, "LICENSE"));
      const readme = path.join(root, definition.licenseDirectory ?? definition.directory, "README.md");
      if (fs.existsSync(readme)) fs.copyFileSync(readme, path.join(directory, "README.md"));
      fs.writeFileSync(path.join(directory, `${definition.name}-pkg.el`), `(define-package ${JSON.stringify(definition.name)} "0.1.0" ${JSON.stringify(definition.description)} '${definition.requires})\n`);
      const filename = `${name}.tar.gz`;
      const result = spawnSync("tar", ["--sort=name", "--mtime=@0", "--owner=0", "--group=0", "--numeric-owner", "-czf", path.resolve(destination, filename), "-C", staging, name], { encoding: "utf8" });
      if (result.error) throw result.error;
      if (result.status !== 0) throw new Error(result.stderr);
      artifacts.push({ name: definition.name, version: "0.1.0", file: filename, sha256: createHash("sha256").update(fs.readFileSync(path.join(destination, filename))).digest("hex"), dependencies: definition.requires });
    }
    return artifacts;
  } finally {
    fs.rmSync(staging, { recursive: true, force: true });
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (process.argv.length !== 4 || process.argv[2] !== "--destination") throw new Error("Usage: node scripts/pack-lisp.mjs --destination <directory>");
  console.log(JSON.stringify(packLisp(process.argv[3]), null, 2));
}
