#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { command, copyTree, digest, inventory, json } from './release-files.mjs';

export function archiveRelease(release, destination) {
  const source = path.resolve(release);
  if (fs.existsSync(path.join(source, 'INCOMPLETE'))) throw new Error('Cannot archive an incomplete candidate');
  const expected = json(path.join(source, 'integrity.json'));
  const actual = inventory(source);
  delete actual['integrity.json'];
  if (JSON.stringify(actual) !== JSON.stringify(expected.files) || Object.values(actual).some(item => item.link)) throw new Error('Release bytes differ from the link-free integrity inventory');
  const output = path.resolve(destination);
  if (fs.existsSync(output)) throw new Error('Archive destination exists');
  fs.mkdirSync(path.dirname(output), { recursive: true });
  const staging = fs.mkdtempSync(path.join(os.tmpdir(), 'phimacs-archive-'));
  try {
    copyTree(source, path.join(staging, 'phimacs'));
    command('tar', ['--format=posix', '--pax-option=exthdr.name=%d/PaxHeaders/%f,delete=atime,delete=ctime', '--sort=name', '--mtime=@0', '--owner=0', '--group=0', '--numeric-owner', '--hard-dereference', '-czf', output, '-C', staging, 'phimacs'], undefined);
    return { file: output, sha256: digest(output), bytes: fs.statSync(output).size };
  } finally { fs.rmSync(staging, { recursive: true, force: true }); }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (process.argv.length !== 6 || process.argv[2] !== '--release' || process.argv[4] !== '--destination') throw new Error('Usage: archive-release.mjs --release DIRECTORY --destination NEW.tar.gz');
  console.log(JSON.stringify(archiveRelease(process.argv[3], process.argv[5]), null, 2));
}
