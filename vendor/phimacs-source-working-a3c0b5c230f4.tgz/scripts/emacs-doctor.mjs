#!/usr/bin/env node
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { inspectEnvironment, parseOptions } from './emacs-environment.mjs';

export async function doctor(argv) {
  const options = parseOptions(argv);
  const report = await inspectEnvironment(options);
  if (options.json) console.log(JSON.stringify(report));
  else {
    for (const check of report.checks) console.log(`${check.component}: ${check.version ?? check.revision ?? 'present'}`);
    for (const issue of report.issues) console.error(`required: ${issue}`);
    console.log(`Emacs mode: ${report.mode}; endpoint: ${report.socket}`);
    console.log('Integrations: sound/browser/private adapters are not enabled by installation');
  }
  return report.ok ? 0 : 1;
}
if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  doctor(process.argv.slice(2)).then(code => { process.exitCode = code; })
    .catch(error => { console.error(error.message); process.exitCode = 1; });
}
