#!/usr/bin/env node
/** Explicit one-time Pi package selection. Never called by normal startup. */
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { inspectEnvironment, parseOptions } from './emacs-environment.mjs';

export async function initializeAgent(options, { inspect = inspectEnvironment } = {}) {
  const report = await inspect(options);
  if (!report.ok) throw new Error(report.issues.join('\n'));
  const settings = { packages: [
    { source: path.join(options.release, 'node_modules/pi-orchestration'), skills: [], prompts: [], themes: [] },
    { source: path.join(options.release, 'node_modules/pi-ant'),
      extensions: ['+dist/extensions/tools.js', '+dist/extensions/error-prompt.js'], skills: [], prompts: [], themes: [] },
  ] };
  await fs.mkdir(options.agent, { recursive: true, mode: 0o700 });
  const directory = await fs.lstat(options.agent);
  if (!directory.isDirectory() || directory.isSymbolicLink() || directory.uid !== process.getuid()
      || (directory.mode & 0o077) !== 0) throw new Error('Agent directory must be owned by you with mode 0700');
  const file = path.join(options.agent, 'settings.json');
  try { await fs.writeFile(file, `${JSON.stringify(settings, null, 2)}\n`, { flag: 'wx', mode: 0o600 }); }
  catch (error) {
    if (error.code === 'EEXIST') throw new Error('Agent settings already exist; setup never overwrites them. Review package selections manually.');
    throw error;
  }
  return { agentDirectory: options.agent, settings: file, authentication: 'explicit-user-action-required',
    optionalIntegrations: 'not-enabled' };
}
/** Emit explicit existing-Emacs configuration; do not write settings or enable modes. */
export async function packageOnlyConfiguration(options, { inspect = inspectEnvironment } = {}) {
  const report = await inspect(options);
  if (!report.ok) throw new Error(report.issues.join('\n'));
  const receipt = JSON.parse(await fs.readFile(path.join(options.assets, 'provision.json'), 'utf8'));
  const directories = [...new Set(receipt.packages.flatMap(item => item.loadPaths.map(relative => path.resolve(options.assets, relative))))];
  directories.push(options.pilish, path.join(options.release, 'lisp/pi-deck'));
  return { mode: 'package-only', activation: 'explicit-user-action-required',
    lisp: `;; Explicitly evaluate in your own configuration; no mode or session is started.\n(dolist (directory '(${directories.map(JSON.stringify).join(' ')})) (add-to-list 'load-path directory t))\n(setq treesit-extra-load-path (list ${JSON.stringify(path.join(options.assets, 'tree-sitter'))})\n      ghostel-module-directory ${JSON.stringify(path.join(options.assets, 'ghostel/'))}\n      pilish-essential-grammar-action 'warn)\n(require 'pilish)\n(unless (and (fboundp 'pilish-integration-capabilities) (file-in-directory-p (symbol-file 'pilish-configure-runtime 'defun) ${JSON.stringify(options.pilish)}) (equal 1 (plist-get (pilish-integration-capabilities) :api-version)) (equal 2 (plist-get (pilish-integration-capabilities) :pimux-protocol)) (plist-get (pilish-integration-capabilities) :authoritative-close)) (error \"Restart with the selected compatible pinned Pilish source\"))\n(pilish-configure-runtime :pi-executable ${JSON.stringify(options.pi)} :pimux-executable ${JSON.stringify(options.pimux)} :task-status-executable ${JSON.stringify(options.taskStatus)} :protocol 2 :pi-version ${JSON.stringify(options.piVersion)} :pi-sha256 ${JSON.stringify(options.piSha256)})\n(require 'pi-deck)\n;; Enable pi-deck-mode only if wanted; orchestration and sound are separate opt-ins.\n` };
}
if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  const options = parseOptions(process.argv.slice(2));
  (options.packageOnly ? packageOnlyConfiguration(options) : initializeAgent(options)).then(result => console.log(JSON.stringify(result)))
    .catch(error => { console.error(error.message); process.exitCode = 1; });
}
