import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
for (const workspace of ["@phimacs/pimux", "pi-orchestration", "pi-ant", "pi-browser", "pi-sound"]) {
  const result = spawnSync("npm", ["run", "check", "--workspace", workspace], { cwd: root, stdio: "inherit" });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}
const typecheck = spawnSync("npm", ["exec", "--", "tsc", "--noEmit", "-p", "tsconfig.json"], { cwd: root, stdio: "inherit" });
if (typecheck.error) throw typecheck.error;
if (typecheck.status !== 0) process.exit(typecheck.status ?? 1);
const result = spawnSync(process.execPath, ["--test", "test/install/contracts.test.ts"], { cwd: root, stdio: "inherit" });
if (result.error) throw result.error;
process.exitCode = result.status ?? 1;
