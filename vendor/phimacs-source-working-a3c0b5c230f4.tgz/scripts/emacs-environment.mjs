import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const configDirectory = fileURLToPath(new URL('../emacs/config/', import.meta.url));
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const exists = async file => fs.stat(file).then(() => true, () => false);

export function parseOptions(argv, env = process.env) {
  const options = { release: env.PHIMACS_RELEASE_DIR, assets: env.PHIMACS_EMACS_ASSETS,
    pilish: env.PHIMACS_PILISH_DIR, state: env.PHIMACS_STATE_DIR,
    mode: env.PHIMACS_DAEMON_MODE ?? 'manual', server: env.PHIMACS_SERVER_NAME ?? 'phimacs',
    emacs: env.PHIMACS_EMACS ?? 'emacs', client: env.PHIMACS_EMACSCLIENT ?? 'emacsclient',
    supervisor: env.PHIMACS_SUPERVISOR_COMMAND, agent: env.PHIMACS_AGENT_DIR,
    supervisorArgs: JSON.parse(env.PHIMACS_SUPERVISOR_ARGS ?? '[]'), clientArgs: [] };
  const values = { '--release': 'release', '--assets': 'assets', '--pilish': 'pilish', '--state': 'state',
    '--daemon-mode': 'mode', '--server': 'server', '--emacs': 'emacs', '--emacsclient': 'client',
    '--supervisor-command': 'supervisor', '--agent-dir': 'agent', '--restart-after': 'restartAfter', '--restart-start': 'restartStart' };
  for (let index = 0; index < argv.length; index++) {
    const arg = argv[index];
    if (arg === '--') { options.clientArgs = argv.slice(index + 1); break; }
    if (arg === '--package-only') options.packageOnly = true;
    else if (arg === '--no-frame') options.noFrame = true;
    else if (arg === '--gui') options.gui = true;
    else if (arg === '--json') options.json = true;
    else if (arg === '--supervisor-arg') {
      if (argv[index + 1] === undefined) throw new Error('Missing --supervisor-arg');
      options.supervisorArgs.push(argv[++index]);
    } else if (values[arg]) {
      if (!argv[index + 1] || argv[index + 1].startsWith('--')) throw new Error(`Missing ${arg}`);
      options[values[arg]] = argv[++index];
    } else throw new Error(`Unknown option: ${arg}`);
  }
  if (!Array.isArray(options.supervisorArgs) || !options.supervisorArgs.every(value => typeof value === 'string')) throw new Error('PHIMACS_SUPERVISOR_ARGS must be a JSON string array');
  if (!['manual', 'supervised'].includes(options.mode)) throw new Error('--daemon-mode must be manual or supervised');
  if (!/^[a-zA-Z0-9_-]+$/.test(options.server)) throw new Error('--server must be a simple dedicated name');
  for (const field of ['release', 'assets', 'pilish', 'state']) {
    if (!options[field] || !path.isAbsolute(options[field])) throw new Error(`--${field} must be an explicit absolute path`);
    options[field] = path.resolve(options[field]);
  }
  if (options.agent && !path.isAbsolute(options.agent)) throw new Error('--agent-dir must be absolute');
  options.agent = options.agent ? path.resolve(options.agent) : path.join(options.state, 'agent');
  options.socket = path.join(options.state, 'sockets', options.server);
  return options;
}

function contained(root, relative) {
  if (typeof relative !== 'string' || !relative || path.isAbsolute(relative)) throw new Error('Invalid relative release path');
  const result = path.resolve(root, relative);
  if (!result.startsWith(`${root}${path.sep}`)) throw new Error('Release path escapes its root');
  return result;
}

/** Read-only: no mkdir, downloads, credential reads, socket cleanup or inference. */
export async function inspectEnvironment(options, { run = spawnSync } = {}) {
  const issues = [];
  const checks = [];
  const readJson = async file => JSON.parse(await fs.readFile(file, 'utf8'));
  let manifest;
  let lispPaths = [];
  let provision;
  let inputs;
  try {
    manifest = await readJson(path.join(options.release, 'release-manifest.json'));
    const host = await readJson(path.join(options.release, 'node_modules/@earendil-works/pi-coding-agent/package.json'));
    if (!manifest.pi || manifest.pi.version !== host.version) throw new Error('Pi host version differs from release manifest');
    options.pi = contained(options.release, manifest.pi.executable);
    options.piVersion = manifest.pi.version;
    options.piSha256 = manifest.pi.sha256;
    if (digest(await fs.readFile(options.pi)) !== manifest.pi.sha256) throw new Error('Pi executable hash differs from release manifest');
    if (manifest.pi.files) {
      const directory = contained(options.release, manifest.pi.directory);
      for (const [relative, item] of Object.entries(manifest.pi.files)) {
        const file = contained(directory, relative);
        if (!(await fs.lstat(file)).isFile() || digest(await fs.readFile(file)) !== item.sha256) throw new Error(`Modified Pi host file: ${relative}`);
      }
      checks.push({ component: 'host-files', count: Object.keys(manifest.pi.files).length });
    }
    options.pimux = path.join(options.release, 'node_modules/@phimacs/pimux/bin/pimux');
    options.taskStatus = path.join(options.release, 'node_modules/.bin/phimacs-task-status');
    await fs.access(options.taskStatus, fs.constants.X_OK);
    await fs.access(options.pimux, fs.constants.X_OK);
    await fs.access(options.pi, fs.constants.X_OK);
    const releaseRoot = await fs.realpath(options.release);
    for (const executable of [options.pi, options.pimux, options.taskStatus]) {
      if (!(await fs.realpath(executable)).startsWith(`${releaseRoot}${path.sep}`)) throw new Error('Executable escapes the selected immutable release');
    }
    if (manifest.runtime?.pimuxProtocol !== 2 || manifest.runtime?.detachedTargetImplemented !== true) {
      issues.push('Release has no completed protocol-2 detached runtime; do not use the primary-stdio baseline');
    }
    checks.push({ component: 'release', version: manifest.version, pi: host.version, executable: options.pi });
  } catch (error) { issues.push(`Release: ${error.message}`); }
  try {
    provision = await readJson(path.join(options.assets, 'provision.json'));
    inputs = await readJson(path.join(options.assets, 'inputs.json'));
    if (provision.schemaVersion !== 1 || digest(await fs.readFile(path.join(options.assets, 'inputs.json'))) !== provision.inputsSha256) {
      throw new Error('Asset evidence does not match locked inputs');
    }
    for (const item of provision.packages) for (const relative of item.loadPaths) {
      const directory = contained(options.assets, relative);
      if (!(await fs.stat(directory)).isDirectory()) throw new Error(`Missing Lisp load path for ${item.name}`);
      lispPaths.push(directory);
    }
    for (const item of provision.grammars.artifacts ?? []) {
      if (!['markdown', 'markdown-inline'].includes(item.language) || !Number.isSafeInteger(item.abi)
          || item.path !== `tree-sitter/libtree-sitter-${item.language}.so`) throw new Error('Invalid essential grammar integrity evidence');
    }
    if (inputs.grammars?.languages && (provision.grammars.artifacts ?? []).length !== inputs.grammars.languages.length
        && provision.grammars.status === 'verified') throw new Error('Essential grammar artifact set is incomplete');
    const artifacts = [provision.native, ...(provision.grammars.artifacts ?? [])];
    for (const item of artifacts) {
      if (item.status && item.status !== 'verified') continue;
      if (!item.path || !/^[a-f0-9]{64}$/.test(item.sha256 ?? '')) throw new Error('Missing native/grammar integrity evidence');
      if (digest(await fs.readFile(contained(options.assets, item.path))) !== item.sha256) throw new Error('Native/grammar asset hash mismatch');
    }
    if (provision.native.libc) {
      const actual = process.report.getReport().header.glibcVersionRuntime?.split('.').map(Number);
      const minimum = provision.native.libc.minimumVersion.split('.').map(Number);
      if (!actual || actual[0] < minimum[0] || (actual[0] === minimum[0] && actual[1] < minimum[1])) {
        throw new Error(`Ghostel native asset requires glibc ${provision.native.libc.minimumVersion}+; musl is unsupported`);
      }
    }
    if (provision.native.status !== 'verified') issues.push('Ghostel native module not provisioned');
    if (provision.grammars.status !== 'verified') issues.push('Essential Markdown grammars not provisioned; run explicit emacs-provision.mjs --grammars with the pinned fork');
    checks.push({ component: 'assets', packages: provision.packages.map(item => ({ name: item.name, version: item.version })),
      native: provision.native.status, grammars: provision.grammars.status });
  } catch (error) { issues.push(`Assets: ${error.message}`); }
  try {
    if (!(await exists(path.join(options.pilish, 'pilish.el')))) throw new Error('Missing pinned Pilish source');
    const revision = manifest?.externalForks?.pilish?.revision;
    if (!/^[a-f0-9]{40}$/.test(revision ?? '')) throw new Error('Release lacks an exact Pilish fork pin');
    const identity = await readJson(path.join(options.pilish, '.phimacs-source.json')).catch(error => {
      if (error.code === 'ENOENT') return undefined;
      throw error;
    });
    const git = identity ? undefined : run('git', ['-c', 'core.fsmonitor=false', '-C', options.pilish, 'rev-parse', 'HEAD'], { encoding: 'utf8', timeout: 5000 });
    if (identity) {
      if (identity.revision !== revision || !/^[a-f0-9]{64}$/.test(manifest.externalForks.pilish.sourceSha256 ?? '')
          || identity.sha256 !== manifest.externalForks.pilish.sourceSha256) throw new Error('Pilish retained-source identity mismatch');
    } else if (git.status === 0) {
      if (git.stdout.trim() !== revision) throw new Error('Pilish revision differs from release manifest');
      const status = run('git', ['-c', 'core.fsmonitor=false', '-C', options.pilish, 'status', '--porcelain', '--untracked-files=no'], { encoding: 'utf8', timeout: 5000 });
      if (status.status !== 0 || status.stdout.trim()) throw new Error('Pinned Pilish source has local modifications');
    } else throw new Error('Pilish requires a clean pinned Git tree or verified retained-source identity');
    if (inputs?.grammars?.pilishRevision && inputs.grammars.pilishRevision !== revision) throw new Error('Pilish fork and grammar-owner pins disagree');
    for (const [relative, expected] of Object.entries(inputs?.grammars?.pilishSourceFiles ?? {})) {
      const file = contained(options.pilish, relative);
      if (!(await fs.lstat(file)).isFile() || digest(await fs.readFile(file)) !== expected) throw new Error(`Pinned Pilish source bytes changed: ${relative}`);
    }
    if (inputs?.grammars?.pilishSourceFiles && !(await exists(path.join(options.pilish, 'scripts/pilish-storage.mjs')))) throw new Error('Pilish managed storage helper is absent');
    checks.push({ component: 'pilish', revision, path: options.pilish });
  } catch (error) { issues.push(`Pilish: ${error.message}`); }
  const version = run(options.emacs, ['-Q', '--batch', '--eval', '(princ (format "%s %s %s" emacs-version (fboundp (quote module-load)) (treesit-available-p)))'],
    { encoding: 'utf8', timeout: 10_000, env: { ...process.env, EMACSLOADPATH: '' } });
  const match = version.stdout?.trim().match(/^(\d+\.\d+(?:\.\d+)?) t t$/);
  if (version.error || version.status !== 0 || !match || Number(match[1].split('.')[0]) < 31
      || (match[1].startsWith('31.') && Number(match[1].split('.')[1]) < 1)) {
    issues.push('Emacs 31.1+ with native modules and tree-sitter is required');
  } else {
    checks.push({ component: 'emacs', version: match[1] });
    const native = provision?.native.status === 'verified' ? contained(options.assets, provision.native.path) : undefined;
    const grammars = provision?.grammars.status === 'verified' ? provision.grammars.artifacts ?? [] : [];
    const expression = `(progn (setq native-comp-jit-compilation nil pilish-essential-grammar-action 'warn) (require 'pilish) (require 'pi-deck)
      (unless (and (fboundp 'pilish-integration-capabilities) (fboundp 'pilish-configure-runtime) (fboundp 'pi-deck-integration-capabilities)) (error "Missing Phimacs public Pilish/deck integration API"))
      (unless (and (file-in-directory-p (symbol-file 'pilish-configure-runtime 'defun) ${JSON.stringify(options.pilish)})
                   (file-in-directory-p (symbol-file 'pi-deck-integration-capabilities 'defun) ${JSON.stringify(path.join(options.release, 'lisp/pi-deck'))})) (error "Loaded integration API comes from outside selected release sources"))
      (pilish-configure-runtime :pi-executable ${JSON.stringify(options.pi)} :pimux-executable ${JSON.stringify(options.pimux)} :task-status-executable ${JSON.stringify(options.taskStatus)} :protocol 2 :pi-version ${JSON.stringify(options.piVersion)} :pi-sha256 ${JSON.stringify(options.piSha256)})
      ${native ? `(module-load ${JSON.stringify(native)})` : ''}
      ${grammars.map(item => `(let ((treesit-extra-load-path nil) (treesit-load-name-override-list '(( ${item.language} ${JSON.stringify(contained(options.assets, item.path).replace(/\.so$/, ''))} ${JSON.stringify('tree_sitter_' + item.language.replaceAll('-', '_'))})))) (unless (and (treesit-language-available-p '${item.language}) (= (treesit-language-abi-version '${item.language}) ${Number(item.abi ?? inputs?.grammars?.abi ?? 15)})) (error "Required grammar ABI unavailable")))`).join('\n')}
      (let ((cap (pilish-integration-capabilities)) (deck (pi-deck-integration-capabilities))) (princ (format "%s %s %s %s %s" (plist-get cap :api-version) (plist-get cap :pimux-protocol) (plist-get deck :api-version) (plist-get deck :detached-desktop-restore) (plist-get cap :authoritative-close)))))`;
    const api = run(options.emacs, ['-Q', '--batch', ...lispPaths.flatMap(directory => ['-L', directory]),
      '-L', options.pilish, '-L', path.join(options.release, 'lisp/pi-deck'), '--eval', expression], { encoding: 'utf8', timeout: 10_000 });
    const capabilities = api.stdout?.trim().split(/\s+/) ?? [];
    if (api.error || api.status !== 0 || capabilities[0] !== '1' || capabilities[1] !== '2') {
      issues.push('Pilish/deck public integration API unavailable or mismatched; acquire the pinned candidate fork and Lisp archives');
    } else {
      checks.push({ component: 'pilish-api', version: '1 / protocol 2' });
      if (capabilities[4] !== 't') issues.push('Pilish lacks authoritative Close; select the matching candidate fork');
      else checks.push({ component: 'close-api', version: 'authoritative Close / task cleanup', executable: options.taskStatus });
      if (capabilities[2] !== '1' || capabilities[3] !== 't') issues.push('Pi-deck lacks verified detached desktop restoration; finish owning runtime/view integration');
      else checks.push({ component: 'deck-api', version: '1 / detached desktop restore' });
    }
  }
  const endpoint = await fs.lstat(options.socket).catch(() => null);
  if (endpoint) {
    if (!endpoint.isSocket() || endpoint.uid !== process.getuid() || (endpoint.mode & 0o077) !== 0) issues.push('Configured Emacs endpoint has unsafe ownership/type/permissions');
    else {
      const health = run(options.client, ['--alternate-editor=false', '--socket-name', options.socket, '--eval', 't'], { encoding: 'utf8', timeout: 2000 });
      checks.push({ component: 'endpoint', state: health.status === 0 ? 'responsive' : 'unavailable' });
      if (health.status !== 0) issues.push('Configured Emacs endpoint is unavailable; doctor never restarts or reclaims it');
    }
  } else checks.push({ component: 'endpoint', state: 'not-started' });
  if (Number(process.versions.node.split('.')[0]) < 24) issues.push('Node 24+ is required');
  if (process.platform !== 'linux') issues.push('The supported reference environment is Linux-first');
  if (await exists(options.state)) {
    const state = await fs.lstat(options.state);
    if (!state.isDirectory() || state.isSymbolicLink() || state.uid !== process.getuid() || (state.mode & 0o077) !== 0) issues.push('State directory must be your own non-symlink 0700 directory');
  }
  return { ok: issues.length === 0, checks, issues, mode: options.mode, socket: options.socket,
    optional: { sound: 'off-unless-user-configured', browser: 'off-unless-user-configured', privateAdapters: 'not-loaded' } };
}

export function childEnvironment(options, env = process.env) {
  const result = { ...env };
  for (const name of Object.keys(result)) {
    if (/^(HERDR_|TMUX|PILISH_|PI_ORCHESTRATION_|PI_WORKER_)/.test(name)
        || (name.startsWith('PIMUX_') && name !== 'PIMUX_DIR')
        || ['DISPLAY', 'WAYLAND_DISPLAY', 'SESSION_MANAGER', 'DBUS_SESSION_BUS_ADDRESS', 'EMACSLOADPATH', 'PI_REMOTE'].includes(name)) delete result[name];
  }
  Object.assign(result, { PHIMACS_RELEASE_DIR: options.release, PHIMACS_EMACS_ASSETS: options.assets,
    PHIMACS_PILISH_DIR: options.pilish, PHIMACS_STATE_DIR: options.state,
    PHIMACS_SERVER_NAME: options.server, PHIMACS_SERVER_SOCKET: options.socket,
    PHIMACS_DAEMON_MODE: options.mode, PHIMACS_AGENT_DIR: options.agent,
    PHIMACS_EMACS: options.emacs, PHIMACS_EMACSCLIENT: options.client,
    PHIMACS_SUPERVISOR_ARGS: JSON.stringify(options.supervisorArgs),
    PI_CODING_AGENT_DIR: options.agent, PI_CODING_AGENT_SESSION_DIR: path.join(options.agent, 'sessions'),
    PHIMACS_EMACS_LAUNCHER: fileURLToPath(new URL('./emacs-launch.mjs', import.meta.url)),
    PHIMACS_PI: options.pi,
    PHIMACS_TAU: path.join(options.release, 'node_modules/pi-tau-web-server/bin/tau.js'),
    TAU_PI_COMMAND: options.pi });
  if (options.piVersion) result.PHIMACS_PI_VERSION = options.piVersion;
  if (options.piSha256) result.PHIMACS_PI_SHA256 = options.piSha256;
  if (options.supervisor) result.PHIMACS_SUPERVISOR_COMMAND = options.supervisor;
  return result;
}
