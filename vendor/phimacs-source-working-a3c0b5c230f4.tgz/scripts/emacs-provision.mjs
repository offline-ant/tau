#!/usr/bin/env node
/**
 * Explicit provisioning, never run from Emacs startup.
 *
 * node scripts/emacs-provision.mjs --destination /new/release-assets
 * node scripts/emacs-provision.mjs --grammars --destination /release-assets --pilish /pinned/pilish
 *
 * Layout: destination/emacs/{packages,ghostel,tree-sitter,sources,provision.json}.
 * Raw source archives and their licenses remain with installed code. No package
 * lifecycle scripts, home caches, mutable archive indexes or user init are used.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const DEFAULT_INPUTS = fileURLToPath(new URL('../emacs/inputs.json', import.meta.url));
const MAX_ARCHIVE_BYTES = 128 * 1024 * 1024;
const MAX_UNPACKED_BYTES = 512 * 1024 * 1024;
const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

function requireText(value, description) {
  if (typeof value !== 'string' || !value) throw new Error(`Missing ${description}`);
  return value;
}

function relativePath(value) {
  requireText(value, 'archive path');
  if (value.includes('\\') || value.includes('\0') || path.posix.isAbsolute(value)
      || /^[a-z]:/i.test(value) || value.split('/').includes('..')) {
    throw new Error(`Unsafe archive path: ${value}`);
  }
  return value.replace(/\/$/, '');
}

function octal(header, start, end) {
  const value = header.subarray(start, end).toString('ascii').replace(/\0.*$/s, '').trim();
  if (value && !/^[0-7]+$/.test(value)) throw new Error('Unsupported tar numeric encoding');
  const number = parseInt(value || '0', 8);
  if (!Number.isSafeInteger(number) || number < 0) throw new Error('Invalid tar number');
  return number;
}

function paxEntries(bytes) {
  const result = {};
  for (let offset = 0; offset < bytes.length;) {
    const end = bytes.indexOf(32, offset);
    const length = Number(bytes.subarray(offset, end).toString());
    if (end < offset || !Number.isSafeInteger(length) || length <= end - offset + 1
        || offset + length > bytes.length || bytes[offset + length - 1] !== 10) {
      throw new Error('Invalid tar PAX header');
    }
    const record = bytes.subarray(end + 1, offset + length - 1).toString('utf8');
    const equals = record.indexOf('=');
    if (equals < 1) throw new Error('Invalid tar PAX attribute');
    result[record.slice(0, equals)] = record.slice(equals + 1);
    offset += length;
  }
  return result;
}

/** Validate the complete archive before creating any package files. */
export function parseSourceArchive(bytes, prefix) {
  relativePath(prefix);
  const tar = zlib.gunzipSync(bytes, { maxOutputLength: MAX_UNPACKED_BYTES });
  const files = [];
  const seen = new Set();
  let attributes = {};
  let ended = false;
  for (let offset = 0; offset + 512 <= tar.length;) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every(byte => byte === 0)) { ended = true; break; }
    let checksum = 0;
    for (let index = 0; index < 512; index++) checksum += index >= 148 && index < 156 ? 32 : header[index];
    if (checksum !== octal(header, 148, 156)) throw new Error('Invalid tar header checksum');
    const string = (start, end) => header.subarray(start, end).toString('utf8').replace(/\0.*$/s, '');
    const size = octal(header, 124, 136);
    const data = tar.subarray(offset + 512, offset + 512 + size);
    if (data.length !== size) throw new Error('Truncated tar entry');
    offset += 512 + Math.ceil(size / 512) * 512;
    const type = string(156, 157) || '0';
    if (type === 'g') {
      const global = paxEntries(data);
      if (global.path || global.linkpath || global.size) throw new Error('Unsupported global tar path override');
      continue;
    }
    if (type === 'x') { attributes = paxEntries(data); continue; }
    if (type !== '0' && type !== '5' && type !== '2') throw new Error(`Unsupported tar entry type ${type}`);
    const metadata = attributes;
    attributes = {};
    const name = relativePath(metadata.path ?? [string(345, 500), string(0, 100)].filter(Boolean).join('/'));
    if (metadata.size !== undefined && Number(metadata.size) !== size) throw new Error('Unsupported tar PAX size override');
    if (name === prefix && type === '5') continue;
    if (!name.startsWith(`${prefix}/`)) throw new Error(`Archive does not match locked prefix ${prefix}`);
    const relative = relativePath(name.slice(prefix.length + 1));
    if (!relative || seen.has(relative)) throw new Error(`Duplicate archive path: ${relative}`);
    seen.add(relative);
    let link;
    if (type === '2') {
      const target = requireText(metadata.linkpath ?? string(157, 257), 'symlink target');
      if (target.includes('\\') || target.includes('\0') || path.posix.isAbsolute(target) || /^[a-z]:/i.test(target)) throw new Error('Unsafe archive symlink');
      link = path.posix.normalize(path.posix.join(path.posix.dirname(relative), target));
      if (link === '..' || link.startsWith('../')) throw new Error('Unsafe escaping archive symlink');
    }
    files.push({ path: relative, directory: type === '5', executable: (octal(header, 100, 108) & 0o111) !== 0, data, link });
  }
  if (!ended || files.length === 0) throw new Error('Empty or incomplete source archive');
  const fileNames = new Set(files.filter(file => !file.directory).map(file => file.path));
  for (const file of files) {
    let parent = path.posix.dirname(file.path);
    while (parent !== '.') {
      if (fileNames.has(parent)) throw new Error(`Archive file shadows a parent directory: ${parent}`);
      parent = path.posix.dirname(parent);
    }
  }
  // Materialize internal file links instead of creating filesystem symlinks.
  // Archives remain byte-for-byte retained as corresponding source.
  for (const file of files) {
    if (file.link === undefined) continue;
    const traversed = new Set([file.path]);
    let target = file;
    while (target.link !== undefined) {
      if (traversed.has(target.link)) throw new Error('Cyclic archive symlink');
      traversed.add(target.link);
      const next = files.find(item => item.path === target.link);
      if (!next || next.directory) throw new Error('Unresolved archive file symlink');
      target = next;
    }
    file.data = target.data;
    file.executable = target.executable;
  }
  return files;
}

async function download(url) {
  const parsed = new URL(url);
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password) throw new Error('Source URLs must use credential-free HTTPS');
  const response = await fetch(url, { signal: AbortSignal.timeout(120_000) });
  if (!response.ok) throw new Error(`Download failed (${response.status}): ${url}`);
  if (new URL(response.url).protocol !== 'https:') throw new Error('Refusing non-HTTPS download redirect');
  const length = Number(response.headers.get('content-length'));
  if (length > MAX_ARCHIVE_BYTES) throw new Error('Download exceeds the asset size limit');
  const chunks = [];
  let total = 0;
  for await (const chunk of response.body) {
    total += chunk.length;
    if (total > MAX_ARCHIVE_BYTES) throw new Error('Download exceeds the asset size limit');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function lockedBytes(input, fetchBytes) {
  if (!/^[a-f0-9]{64}$/.test(input.sha256)) throw new Error(`Missing SHA-256 for ${input.name}`);
  const bytes = Buffer.from(await fetchBytes(requireText(input.url, 'immutable source URL')));
  if (bytes.length > MAX_ARCHIVE_BYTES || sha256(bytes) !== input.sha256) throw new Error(`SHA-256 mismatch for ${input.name}`);
  return bytes;
}

async function extract(files, directory) {
  await fs.mkdir(directory, { recursive: true, mode: 0o700 });
  for (const file of files) {
    const target = path.join(directory, file.path);
    if (file.directory) await fs.mkdir(target, { recursive: true, mode: 0o700 });
    else {
      await fs.mkdir(path.dirname(target), { recursive: true, mode: 0o700 });
      await fs.writeFile(target, file.data, { flag: 'wx', mode: file.executable ? 0o755 : 0o644 });
    }
  }
}

async function seal(directory) {
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) await seal(file);
    else {
      const mode = (await fs.stat(file)).mode;
      await fs.chmod(file, mode & 0o111 ? 0o555 : 0o444);
    }
  }
  await fs.chmod(directory, 0o555);
}

async function unseal(directory) {
  await fs.chmod(directory, 0o700);
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    if (entry.isDirectory()) await unseal(path.join(directory, entry.name));
  }
}

function validateInputs(inputs, platform, arch) {
  if (inputs.schemaVersion !== 1 || !Array.isArray(inputs.packages)) throw new Error('Unsupported Emacs input lock schema');
  if (!inputs.platforms.includes(`${platform}-${arch}`)) throw new Error(`Unsupported Emacs asset platform: ${platform}-${arch}`);
  const names = new Set();
  for (const item of inputs.packages) {
    if (!/^[a-z0-9][a-z0-9-]*$/.test(item.name) || names.has(item.name)) throw new Error('Invalid or duplicate package name');
    names.add(item.name);
    if (!/^[a-f0-9]{40}$/.test(item.revision)) throw new Error(`A full immutable source revision is required for ${item.name}`);
    if (!item.license || item.license === 'REVIEW') throw new Error(`Missing reviewed source license for ${item.name}`);
    for (const subdir of item.loadPaths) if (subdir !== '.') relativePath(subdir);
  }
  for (const item of inputs.packages) for (const dependency of item.requires ?? []) {
    if (!names.has(dependency) && !Object.hasOwn(inputs.builtins, dependency)) throw new Error(`Unlocked dependency ${dependency} required by ${item.name}`);
  }
  for (const source of [...Object.values(inputs.native).flatMap(native => native.sources), ...(inputs.grammars.correspondingSources ?? [])]) {
    if (!/^[a-z0-9][a-z0-9-]*$/.test(source.name) || !/^[a-f0-9]{40}$/.test(source.revision)
        || !source.license || source.license === 'REVIEW') throw new Error('Native sources require safe names, exact revisions and reviewed licenses');
    relativePath(source.archivePrefix);
    for (const license of source.licenseFiles) relativePath(license);
  }
}

/** Installs only to a new destination; injected downloader is for deterministic tests/offline callers. */
export async function provision({ destination, inputsPath = DEFAULT_INPUTS, fetchBytes = download,
  platform = process.platform, arch = process.arch, native = true } = {}) {
  const target = path.resolve(requireText(destination, '--destination'));
  const lockBytes = await fs.readFile(inputsPath);
  const inputs = JSON.parse(lockBytes);
  validateInputs(inputs, platform, arch);
  await fs.mkdir(path.dirname(target), { recursive: true, mode: 0o700 });
  try { await fs.mkdir(target, { mode: 0o700 }); }
  catch (error) {
    if (error.code === 'EEXIST') throw new Error(`Destination already exists; select a new versioned directory: ${target}`);
    throw error;
  }
  const identity = await fs.lstat(target);
  const staging = path.join(target, '.provisioning');
  const emacs = path.join(staging, 'emacs');
  try {
    await fs.mkdir(path.join(emacs, 'sources'), { recursive: true, mode: 0o700 });
    await fs.mkdir(path.join(emacs, 'packages'), { mode: 0o700 });
    await fs.mkdir(path.join(emacs, 'tree-sitter'), { mode: 0o700 });
    const evidence = { schemaVersion: 1, inputsSha256: sha256(lockBytes), emacsMinimum: inputs.emacsMinimum,
      platform: `${platform}-${arch}`, packages: [], native: { status: native ? 'provisioning' : 'not-selected' },
      grammars: { status: 'not-provisioned', api: inputs.grammars.api, instruction: 'Run the explicit --grammars phase with the pinned Pilish source.' } };
    for (const item of inputs.packages) {
      const bytes = await lockedBytes(item, fetchBytes);
      const files = parseSourceArchive(bytes, item.archivePrefix);
      const sourceName = `${item.name}-${item.revision}.tar.gz`;
      await fs.writeFile(path.join(emacs, 'sources', sourceName), bytes, { flag: 'wx', mode: 0o644 });
      for (const licenseFile of item.licenseFiles) {
        if (!files.some(file => !file.directory && file.path === licenseFile)) throw new Error(`Missing locked license ${licenseFile} in ${item.name}`);
      }
      const packagePath = `packages/${item.name}`;
      await extract(files, path.join(emacs, packagePath));
      for (const subdir of item.loadPaths) {
        if (!(await fs.stat(path.join(emacs, packagePath, subdir))).isDirectory()) throw new Error(`Missing load path for ${item.name}: ${subdir}`);
      }
      evidence.packages.push({ name: item.name, version: item.version, path: packagePath,
        loadPaths: item.loadPaths.map(subdir => path.posix.join(packagePath, subdir)), revision: item.revision,
        license: item.license, licenseFiles: item.licenseFiles, sourceArchive: `sources/${sourceName}`, sha256: item.sha256 });
    }
    const grammarSources = [];
    for (const source of inputs.grammars.correspondingSources ?? []) {
      const bytes = await lockedBytes(source, fetchBytes);
      const files = parseSourceArchive(bytes, source.archivePrefix);
      for (const license of source.licenseFiles) {
        if (!files.some(file => !file.directory && file.path === license)) throw new Error(`Missing grammar source license ${license}`);
      }
      const sourceName = `${source.name}-${source.revision}.tar.gz`;
      await fs.writeFile(path.join(emacs, 'sources', sourceName), bytes, { flag: 'wx', mode: 0o644 });
      grammarSources.push({ name: source.name, revision: source.revision, archive: `sources/${sourceName}`, sha256: source.sha256, license: source.license });
    }
    evidence.grammars.sources = grammarSources;
    if (native) {
      const input = inputs.native[`${platform}-${arch}`];
      if (!input) throw new Error('No locked Ghostel native asset for this platform');
      if (input.libc) {
        const actual = process.report.getReport().header.glibcVersionRuntime;
        const required = input.libc.minimumVersion.split('.').map(Number);
        const found = actual?.split('.').map(Number);
        if (input.libc.name !== 'glibc' || !found || found[0] < required[0] || (found[0] === required[0] && found[1] < required[1])) {
          throw new Error(`Ghostel native asset requires glibc ${input.libc.minimumVersion}+; musl is unsupported`);
        }
      }
      const directory = path.join(emacs, 'ghostel');
      await fs.mkdir(directory, { mode: 0o700 });
      const bytes = await lockedBytes(input, fetchBytes);
      await fs.writeFile(path.join(directory, 'ghostel-module.so'), bytes, { flag: 'wx', mode: 0o644 });
      await fs.writeFile(path.join(directory, 'ghostel-module.version'), `${input.version}\n`, { flag: 'wx', mode: 0o644 });
      const sources = [];
      for (const source of input.sources) {
        const sourceBytes = await lockedBytes(source, fetchBytes);
        const files = parseSourceArchive(sourceBytes, source.archivePrefix);
        const sourceName = `${source.name}-${source.revision}.tar.gz`;
        await fs.writeFile(path.join(emacs, 'sources', sourceName), sourceBytes, { flag: 'wx', mode: 0o644 });
        const notices = files.filter(file => !file.directory && source.licenseFiles.includes(file.path));
        if (notices.length !== source.licenseFiles.length) throw new Error(`Missing native source license for ${source.name}`);
        for (const file of notices) {
          const name = file.path.replaceAll('/', '_');
          await fs.writeFile(path.join(directory, `${source.name}-${name}`), file.data, { flag: 'wx', mode: 0o644 });
        }
        sources.push({ name: source.name, revision: source.revision, archive: `sources/${sourceName}`, sha256: source.sha256, license: source.license });
      }
      evidence.native = { status: 'verified', version: input.version, path: 'ghostel/ghostel-module.so',
        sha256: input.sha256, sources, libc: input.libc, sourceClosure: input.sourceClosure, redistributionReview: input.redistributionReview };
      await seal(directory);
    }
    await seal(path.join(emacs, 'packages'));
    await seal(path.join(emacs, 'sources'));
    await fs.writeFile(path.join(emacs, 'inputs.json'), lockBytes, { flag: 'wx', mode: 0o444 });
    await fs.writeFile(path.join(emacs, 'provision.json'), `${JSON.stringify(evidence, null, 2)}\n`, { flag: 'wx', mode: 0o444 });
    await fs.rename(emacs, path.join(target, 'emacs'));
    await fs.rmdir(staging);
    return evidence;
  } catch (error) {
    const current = await fs.lstat(target).catch(() => null);
    if (current?.ino === identity.ino && current?.dev === identity.dev) {
      await unseal(target);
      await fs.rm(target, { recursive: true });
    }
    throw error;
  }
}

/** Calls only the owning public Pilish API, never copies its recipes or runs personal init. */
export async function provisionGrammars({ destination, pilish, emacsCommand = 'emacs', spawn = spawnSync } = {}) {
  const assets = path.join(path.resolve(requireText(destination, '--destination')), 'emacs');
  const source = path.resolve(requireText(pilish, '--pilish'));
  const inputs = JSON.parse(await fs.readFile(path.join(assets, 'inputs.json'), 'utf8'));
  const evidencePath = path.join(assets, 'provision.json');
  const evidence = JSON.parse(await fs.readFile(evidencePath, 'utf8'));
  if (evidence.grammars.status === 'verified') throw new Error('Essential grammars are already provisioned; choose a new release to rebuild');
  const installer = requireText(inputs.grammars.api, 'owning essential grammar installer API');
  if (!/^pilish-[a-z-]+$/.test(installer)) throw new Error('Invalid public Pilish installer name');
  const revision = requireText(inputs.grammars.pilishRevision, 'pinned Pilish grammar-owner revision');
  if (!/^[a-f0-9]{40}$/.test(revision)) throw new Error('Pilish grammar-owner revision must be a full immutable commit');
  const identityBytes = await fs.readFile(path.join(source, '.phimacs-source.json'), 'utf8').catch(error => {
    if (error.code === 'ENOENT') return undefined;
    throw error;
  });
  const git = identityBytes ? undefined : spawn('git', ['-c', 'core.fsmonitor=false', '-C', source, 'rev-parse', 'HEAD'], { encoding: 'utf8', timeout: 10_000 });
  if (identityBytes) {
    const identity = JSON.parse(identityBytes);
    if (identity.revision !== revision || !/^[a-f0-9]{64}$/.test(inputs.grammars.pilishSourceSha256 ?? '')
        || identity.sha256 !== inputs.grammars.pilishSourceSha256) throw new Error('Pilish retained-source identity does not match the input lock');
  } else if (git.status === 0 && !git.error) {
    if (git.stdout.trim() !== revision) throw new Error('Pilish source does not match the locked grammar-owner revision');
    const status = spawn('git', ['-c', 'core.fsmonitor=false', '-C', source, 'status', '--porcelain', '--untracked-files=no'], { encoding: 'utf8', timeout: 10_000 });
    if (status.error || status.status !== 0 || status.stdout.trim()) throw new Error('Pilish grammar owner must be a clean pinned source tree');
  } else throw new Error('Pilish requires a pinned clean Git tree or verified .phimacs-source.json metadata');
  for (const [relative, expected] of Object.entries(inputs.grammars.pilishSourceFiles ?? {})) {
    relativePath(relative);
    const file = path.join(source, relative);
    if (!(await fs.lstat(file)).isFile() || sha256(await fs.readFile(file)) !== expected) throw new Error(`Pinned Pilish source bytes changed: ${relative}`);
  }
  const lease = path.join(assets, '.grammar-provisioning');
  try { await fs.mkdir(lease, { mode: 0o700 }); }
  catch (error) {
    if (error.code === 'EEXIST') throw new Error('Another or interrupted grammar operation owns this release; inspect it before recovery');
    throw error;
  }
  const scratch = await fs.mkdtemp(path.join(os.tmpdir(), 'phimacs-grammar-'));
  const grammarDirectory = path.join(lease, 'tree-sitter');
  try {
    await fs.mkdir(grammarDirectory, { mode: 0o700 });
    if ((await fs.readdir(path.join(assets, 'tree-sitter'))).length !== 0) throw new Error('Unrecorded grammar assets already exist; choose a new release or inspect recovery');
    const expression = `(progn (setq native-comp-jit-compilation nil) (require 'json) (load ${JSON.stringify(path.join(source, 'pilish-grammars.el'))} nil t t) (unless (fboundp '${installer}) (error "Pinned Pilish lacks public ${installer}; acquire the compatible Phimacs fork")) (princ (json-encode (${installer} ${JSON.stringify(grammarDirectory)}))))`;
    const env = { ...process.env, HOME: scratch, XDG_CACHE_HOME: path.join(scratch, 'cache'), XDG_CONFIG_HOME: path.join(scratch, 'config'), XDG_DATA_HOME: path.join(scratch, 'data') };
    delete env.EMACSLOADPATH;
    const result = spawn(emacsCommand, ['-Q', '--batch', '-L', source, '--eval', expression], {
      env, encoding: 'utf8', timeout: 300_000,
    });
    if (result.error || result.status !== 0) throw new Error(`Essential grammar provisioning failed: ${result.error?.message ?? result.stderr ?? 'Emacs exited unsuccessfully'}`);
    const report = JSON.parse(result.stdout ?? '');
    if (report['api-version'] !== 1 || path.resolve(report.directory ?? '') !== grammarDirectory
        || !Array.isArray(report.grammars) || report.grammars.length !== inputs.grammars.languages.length) {
      throw new Error('Invalid essential grammar owning API report');
    }
    const artifacts = [];
    for (const language of inputs.grammars.languages) {
      const file = `libtree-sitter-${language}.so`;
      const bytes = await fs.readFile(path.join(grammarDirectory, file)).catch(() => { throw new Error(`Pilish did not provision required grammar ${language}`); });
      const built = report.grammars.find(item => item.language === language);
      if (!built || path.resolve(built.library ?? '') !== path.join(grammarDirectory, file)
          || built.sha256 !== sha256(bytes) || (inputs.grammars.sourceRevision && built.revision !== inputs.grammars.sourceRevision)
          || (inputs.grammars.sourceVersion && built.version !== inputs.grammars.sourceVersion)
          || (inputs.grammars.abi && built.abi !== inputs.grammars.abi)) throw new Error(`Owning grammar report mismatch for ${language}`);
      artifacts.push({ language, path: `tree-sitter/${file}`, sha256: built.sha256,
        abi: built.abi, sourceRevision: built.revision, sourceVersion: built.version, sourceDirectory: built['source-directory'] });
    }
    await fs.rmdir(path.join(assets, 'tree-sitter'));
    await fs.rename(grammarDirectory, path.join(assets, 'tree-sitter'));
    evidence.grammars = { status: 'verified', api: installer, apiVersion: report['api-version'], emacsVersion: report['emacs-version'], revision,
      source: 'explicit-pinned-Pilish', sources: evidence.grammars.sources, artifacts };
    const temporary = `${evidencePath}.${crypto.randomUUID()}.tmp`;
    await fs.writeFile(temporary, `${JSON.stringify(evidence, null, 2)}\n`, { flag: 'wx', mode: 0o444 });
    await fs.rename(temporary, evidencePath);
    await seal(path.join(assets, 'tree-sitter'));
    return evidence.grammars;
  } finally {
    await fs.rm(lease, { recursive: true, force: true });
    await fs.rm(scratch, { recursive: true, force: true });
  }
}

async function main(argv) {
  const options = {};
  let grammars = false;
  for (let index = 0; index < argv.length; index++) {
    const arg = argv[index];
    if (arg === '--grammars') grammars = true;
    else if (arg === '--without-native') options.native = false;
    else if (arg === '--destination' || arg === '--inputs' || arg === '--pilish' || arg === '--emacs') {
      const value = argv[++index];
      if (!value || value.startsWith('--')) throw new Error(`Missing value for ${arg}`);
      options[{ '--destination': 'destination', '--inputs': 'inputsPath', '--pilish': 'pilish', '--emacs': 'emacsCommand' }[arg]] = value;
    } else throw new Error(`Unknown option: ${arg}`);
  }
  console.log(JSON.stringify(grammars ? await provisionGrammars(options) : await provision(options)));
}

if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  main(process.argv.slice(2)).catch(error => { console.error(error.message); process.exitCode = 1; });
}
