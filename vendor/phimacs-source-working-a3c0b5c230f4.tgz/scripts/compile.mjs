import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
for (const workspace of ["@phimacs/pimux", "pi-orchestration", "pi-ant", "pi-browser", "pi-sound"]) {
  const result = spawnSync("npm", ["run", "compile", "--workspace", workspace], { cwd: root, stdio: "inherit" });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}
