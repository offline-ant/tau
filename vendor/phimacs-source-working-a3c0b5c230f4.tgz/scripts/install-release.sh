#!/bin/sh
# Offline bootstrap. The supplied digest must come from a separately trusted receipt.
set -eu
if [ "$#" -lt 3 ]; then
  printf '%s\n' 'Usage: install-release.sh ARCHIVE SHA256 NEW_DESTINATION [--select LINK]' >&2
  exit 2
fi
archive=$1
expected=$2
destination=$3
shift 3
case "$archive" in /*) ;; *) archive="$PWD/$archive" ;; esac
case "$expected" in *[!a-f0-9]*|'') printf '%s\n' 'Invalid SHA-256' >&2; exit 2 ;; esac
[ "${#expected}" -eq 64 ] || exit 2
actual=$(sha256sum "$archive")
[ "${actual%% *}" = "$expected" ] || { printf '%s\n' 'Release archive SHA-256 mismatch' >&2; exit 1; }
node -e 'if(Number(process.versions.node.split(".")[0])<24)process.exit(1)' || { printf '%s\n' 'Node 24+ is required' >&2; exit 1; }
staging=$(mktemp -d "${TMPDIR:-/tmp}/phimacs-bootstrap.XXXXXX")
trap 'chmod -R u+w "$staging"; rm -rf -- "$staging"' EXIT HUP INT TERM
# Link-free release format. Validate all names/types before GNU tar extraction.
tar -tf "$archive" > "$staging/names"
while IFS= read -r entry; do
  case "$entry" in phimacs/|phimacs/*) ;; *) printf '%s\n' 'Unsafe release archive prefix' >&2; exit 1 ;; esac
  case "/$entry" in */../*|*/..|*\\*) printf '%s\n' 'Unsafe release archive path' >&2; exit 1 ;; esac
done < "$staging/names"
tar -tvf "$archive" > "$staging/types"
while IFS= read -r entry; do
  case "$entry" in -r*|dr*) ;; *) printf '%s\n' 'Release archive must contain only regular files/directories' >&2; exit 1 ;; esac
done < "$staging/types"
tar -xf "$archive" --no-same-owner --no-same-permissions -C "$staging"
node "$staging/phimacs/scripts/install-release.mjs" --archive "$archive" --sha256 "$expected" --destination "$destination" "$@"
