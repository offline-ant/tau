#!/usr/bin/env node
/** Run deck-only lifecycle tests from explicit, freshly provisioned inputs. */
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const assets = process.env.PHIMACS_TEST_ASSETS;
const pilish = process.env.PHIMACS_TEST_PILISH;
if (!assets || !pilish) throw new Error('Set PHIMACS_TEST_ASSETS to fresh provisioned assets and PHIMACS_TEST_PILISH to the candidate fork');
const receipt = JSON.parse(await fs.readFile(path.join(assets, 'provision.json'), 'utf8'));
const home = await fs.mkdtemp(path.join(os.tmpdir(), 'phimacs-deck-check-'));
try {
  const loads = receipt.packages.flatMap(pkg => pkg.loadPaths.map(directory => path.resolve(assets, directory)));
  const args = ['-Q', '--batch', ...loads.flatMap(directory => ['-L', directory]), '-L', path.resolve(pilish),
    '-L', path.join(root, 'emacs/pi-deck'), '-L', path.join(root, 'packages/orchestration/emacs'),
    '--eval', `(setq load-prefer-newer t native-comp-jit-compilation nil ghostel-module-directory ${JSON.stringify(path.join(assets, 'ghostel/'))} treesit-extra-load-path (list ${JSON.stringify(path.join(assets, 'tree-sitter'))}))`];
  if (process.argv.includes('--compile')) {
    args.push('--eval', '(setq byte-compile-error-on-warn t)', '-f', 'batch-byte-compile',
      ...(await fs.readdir(path.join(root, 'emacs/pi-deck'))).filter(file => file.endsWith('.el')).map(file => path.join(root, 'emacs/pi-deck', file)));
  } else if (process.argv.includes('--existing')) {
    const selector = process.argv[process.argv.indexOf('--existing') + 1];
    if (!selector || selector.startsWith('--')) throw new Error('--existing requires an explicit ERT selector');
    args.push('-L', path.join(root, 'emacs/pi-deck/test'), '-l', 'pi-deck-test',
      '--eval', `(ert-run-tests-batch-and-exit ${JSON.stringify(selector)})`);
  } else {
    args.push('-l', path.join(root, 'test/reference-deck-lifecycle.el'));
  }
  const result = spawnSync(process.env.EMACS ?? 'emacs', args, {
    encoding: 'utf8', timeout: 120_000, maxBuffer: 8 * 1024 * 1024,
    env: { ...process.env, HOME: home, XDG_CONFIG_HOME: path.join(home, 'config'), EMACSLOADPATH: '',
      DISPLAY: '', WAYLAND_DISPLAY: '', GDK_BACKEND: 'x11', PI_CODING_AGENT_DIR: path.join(home, 'agent'),
      PI_CODING_AGENT_SESSION_DIR: path.join(home, 'sessions'), PIMUX_DIR: path.join(home, 'mux') },
  });
  process.stdout.write(result.stdout ?? '');
  process.stderr.write(result.stderr ?? '');
  if (result.error) throw result.error;
  process.exitCode = result.status ?? 1;
} finally { await fs.rm(home, { recursive: true, force: true }); }
