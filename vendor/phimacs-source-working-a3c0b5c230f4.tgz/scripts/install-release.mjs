#!/usr/bin/env node
/** Offline, scripts-disabled installation of already hydrated release bytes. */
import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { parseSourceArchive } from './emacs-provision.mjs';

const digest = bytes => createHash('sha256').update(bytes).digest('hex');

function archiveFiles(archive, expected) {
  const bytes = fs.readFileSync(archive);
  if (!/^[a-f0-9]{64}$/.test(expected ?? '') || digest(bytes) !== expected) throw new Error('Release archive SHA-256 mismatch');
  const files = parseSourceArchive(bytes, 'phimacs');
  if (files.some(file => file.link !== undefined || file.path === 'INCOMPLETE')) throw new Error('Release must contain no links or incomplete marker');
  const integrity = files.find(file => file.path === 'integrity.json' && !file.directory);
  if (!integrity) throw new Error('Missing release integrity inventory');
  const recorded = JSON.parse(integrity.data);
  if (recorded.schemaVersion !== 1) throw new Error('Unsupported integrity schema');
  const actual = files.filter(file => !file.directory && file.path !== 'integrity.json');
  if (actual.length !== Object.keys(recorded.files).length) throw new Error('Release file set differs from integrity inventory');
  for (const file of actual) {
    const entry = recorded.files[file.path];
    if (!entry || entry.sha256 !== digest(file.data) || entry.executable !== file.executable) throw new Error(`Release integrity mismatch: ${file.path}`);
  }
  const manifest = JSON.parse(files.find(file => file.path === 'release-manifest.json')?.data ?? '{}');
  if (manifest.schemaVersion !== 1 || manifest.runtime?.pimuxProtocol !== 2 || manifest.platform !== process.platform
      || manifest.architecture !== process.arch || Number(process.versions.node.split('.')[0]) < 24) throw new Error('Unsupported release/platform/Node version');
  return { files, manifest };
}

function seal(directory, root = false) {
  for (const name of fs.readdirSync(directory)) {
    const file = path.join(directory, name);
    const stat = fs.lstatSync(file);
    if (stat.isDirectory()) seal(file);
    else if (stat.isFile()) fs.chmodSync(file, stat.mode & 0o111 ? 0o555 : 0o444);
    else throw new Error('Installed releases contain no symlinks or special files');
  }
  if (!root) fs.chmodSync(directory, 0o555);
}

export function selectRelease(release, link) {
  const target = path.resolve(release);
  const selected = path.resolve(link);
  const manifest = JSON.parse(fs.readFileSync(path.join(target, 'release-manifest.json'), 'utf8'));
  if (fs.existsSync(path.join(target, 'INCOMPLETE')) || manifest.runtime?.pimuxProtocol !== 2) throw new Error('Cannot select an incomplete/unsupported release');
  const parent = fs.lstatSync(path.dirname(selected));
  if (!parent.isDirectory() || parent.uid !== process.getuid() || (parent.mode & 0o022)) throw new Error('Release selector parent must be owned and not writable by others');
  const lock = `${selected}.select.lock`;
  const descriptor = fs.openSync(lock, 'wx', 0o600);
  const temporary = `${selected}.${randomUUID()}.tmp`;
  try {
    fs.writeFileSync(descriptor, `${process.pid}\n`);
    const current = fs.lstatSync(selected, { throwIfNoEntry: false });
    if (current && !current.isSymbolicLink()) throw new Error('Refusing to overwrite a non-symlink release selector');
    fs.symlinkSync(target, temporary);
    fs.renameSync(temporary, selected);
  } finally {
    fs.closeSync(descriptor);
    fs.rmSync(temporary, { force: true });
    fs.unlinkSync(lock);
  }
  return { release: target, link: selected };
}

export function installRelease({ archive, sha256, destination, select } = {}) {
  if (!archive || !destination) throw new Error('--archive and --destination are required');
  const { files, manifest } = archiveFiles(path.resolve(archive), sha256);
  const target = path.resolve(destination);
  fs.mkdirSync(path.dirname(target), { recursive: true, mode: 0o700 });
  fs.mkdirSync(target, { mode: 0o700 }); // Exclusive version reservation; never overwrites an existing release.
  const marker = path.join(target, 'INCOMPLETE');
  fs.writeFileSync(marker, 'Installation is incomplete; do not launch/select this directory.\n', { flag: 'wx', mode: 0o600 });
  for (const file of files) {
    const output = path.join(target, file.path);
    if (file.directory) fs.mkdirSync(output, { recursive: true, mode: 0o700 });
    else {
      fs.mkdirSync(path.dirname(output), { recursive: true, mode: 0o700 });
      fs.writeFileSync(output, file.data, { flag: 'wx', mode: file.executable ? 0o755 : 0o644 });
    }
  }
  seal(target, true);
  fs.unlinkSync(marker); // Commit only after every installed file/subdirectory is sealed.
  fs.chmodSync(target, 0o555);
  if (select) selectRelease(target, select);
  return { version: manifest.version, release: target, sha256, selected: select ? path.resolve(select) : null,
    status: manifest.status, publicReleaseApproved: false };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const options = {};
    for (let index = 2; index < process.argv.length; index++) {
      const key = { '--archive': 'archive', '--sha256': 'sha256', '--destination': 'destination', '--select': 'select' }[process.argv[index]];
      const value = process.argv[++index];
      if (!key || !value || value.startsWith('--')) throw new Error('Usage: install-release.mjs --archive FILE --sha256 HASH --destination NEW [--select LINK]');
      options[key] = value;
    }
    console.log(JSON.stringify(installRelease(options), null, 2));
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
