import fs from 'node:fs';
import path from 'node:path';
import { command, copyTree, digest, extractPinnedArchive, json, writeJson } from './release-files.mjs';

export function stageForks(target, staging, selection, { pilishSource, tauSource, offline }) {
  for (const [name, archive] of [['pilish', pilishSource], ['tau', tauSource]]) {
    if (!archive) throw new Error(`A retained ${name} source archive is required`);
    const pin = selection.externalForks[name];
    const retained = path.join(target, pin.sourceArchive);
    fs.mkdirSync(path.dirname(retained), { recursive: true });
    fs.copyFileSync(archive, retained);
    const destination = name === 'pilish' ? path.join(target, pin.directory) : path.join(staging, 'tau');
    extractPinnedArchive(retained, destination, pin.sourceSha256);
    writeJson(path.join(destination, '.phimacs-source.json'), { revision: pin.revision, sha256: pin.sourceSha256 });
  }
  const tau = path.join(staging, 'tau');
  const tauLock = json(path.join(tau, 'package-lock.json'));
  // Reviewed development lock, including local generic vendor inputs. These are
  // build-time types/assets only; final runtime edges use this release's packs.
  command('npm', ['ci', '--ignore-scripts', ...(offline ? ['--offline'] : [])], tau, { offline });
  const compiler = path.join(tau, 'node_modules/typescript/bin/tsc');
  command(process.execPath, [compiler, '-p', 'tsconfig.server.json'], tau);
  command(process.execPath, [compiler, '-p', 'tsconfig.public.json'], tau);
  command(process.execPath, ['scripts/copy-katex.ts'], tau);
  command(process.execPath, ['scripts/copy-highlight.ts'], tau);
  fs.chmodSync(path.join(tau, 'bin/tau.js'), 0o755);
  return { tau, tauLock };
}

export function stageReference(root, target, assets, selection) {
  if (!assets) throw new Error('Fresh provisioned --emacs-assets directory is required');
  const inputsFile = path.join(root, 'emacs/inputs.json');
  const evidence = json(path.join(assets, 'provision.json'));
  const inputs = json(inputsFile);
  if (evidence.platform !== `${process.platform}-${process.arch}`) throw new Error('Emacs assets do not match the release platform');
  if (evidence.inputsSha256 !== digest(inputsFile) || digest(path.join(assets, 'inputs.json')) !== digest(inputsFile)) throw new Error('Emacs assets use a different input lock');
  if (evidence.native.status !== 'verified' || evidence.grammars.status !== 'verified'
      || evidence.grammars.revision !== selection.externalForks.pilish.revision) throw new Error('Native/essential assets are not verified against the selected fork');
  const records = [...evidence.packages, ...evidence.native.sources, ...(evidence.grammars.sources ?? []), evidence.native, ...evidence.grammars.artifacts];
  for (const item of records) {
    const relative = item.sourceArchive ?? item.archive ?? item.path;
    if (!relative || path.isAbsolute(relative) || relative.split('/').includes('..') || digest(path.join(assets, relative)) !== item.sha256) throw new Error('Emacs retained source/generated asset hash mismatch');
  }
  if (inputs.grammars.pilishRevision !== selection.externalForks.pilish.revision
      || inputs.grammars.pilishSourceSha256 !== selection.externalForks.pilish.sourceSha256) throw new Error('Grammar owner and release fork disagree');
  const output = path.join(target, 'assets/emacs');
  copyTree(assets, output);
  // Build scratch paths have no installed meaning and must not leak into packs.
  for (const artifact of evidence.grammars.artifacts) delete artifact.sourceDirectory;
  writeJson(path.join(output, 'provision.json'), evidence);
  copyTree(path.join(root, 'emacs/config'), path.join(target, 'emacs/config'));
  fs.copyFileSync(inputsFile, path.join(target, 'emacs/inputs.json'));
  fs.mkdirSync(path.join(target, 'scripts'), { recursive: true });
  for (const name of fs.readdirSync(path.join(root, 'scripts'))) {
    if (name.startsWith('emacs-') && name.endsWith('.mjs')) copyTree(path.join(root, 'scripts', name), path.join(target, 'scripts', name));
  }
  return { assets: 'assets/emacs', config: 'emacs/config', pilish: selection.externalForks.pilish.directory,
    inputLock: 'emacs/inputs.json', inputLockSha256: digest(inputsFile),
    lispSources: evidence.packages.length, nativeSources: evidence.native.sources.length,
    emacsVersion: evidence.grammars.emacsVersion,
    nativeSourceCorrespondence: evidence.native.sourceClosure.prebuiltCorrespondence,
    grammars: evidence.grammars.artifacts.map(({ language, sha256, abi }) => ({ language, sha256, abi })) };
}
