# Phimacs

An integrated Pi workspace: Emacs project spaces, orchestration, shared RPC
transport, browser tools and optional sound. Pagent remains a separate prototype;
it is not part of the Phimacs product or release.

**Private release candidate, not approved for publication or live cutover.**
Protocol-2 detached roots, symmetric Pilish/Tau clients, managed claims and an
isolated reference/package-only Emacs setup are implemented. Install complete
hashed artifacts, not source-checkout links. Security, licensing and owning Pi API
limits remain explicit in [execution](docs/execution.md); do not replace an active
installation without the separately approved migration.

## Development

Linux, Node 24 and Emacs 31.1+ are the initial target.

```sh
npm ci --ignore-scripts
npm run compile
npm run check
node scripts/test.mjs path/to/specific.test.ts
```

Compile before checks that consume another package's declarations. No startup or
installation lifecycle scripts provision native assets or access private accounts.

- [Architecture](docs/architecture.md)
- [Installation candidate and packs](docs/install.md)
- [Development and source ownership](docs/development.md)
- [Runtime lifecycle](docs/lifecycle.md)
- [Migration and rollback boundary](docs/migration.md)
- [Provenance](provenance/README.md)

Existing package, command and Lisp feature names are retained. Installing a package
does not authorize enabling all extensions or integrations. Pilish and Tau remain
separate pinned forks. Private providers and native-token/device adapters are not
part of this source or its artifacts.

Original package licenses/notices remain applicable. Root MIT covers new original
Phimacs tooling, not a relicensing of dependencies or bundled GPL components.
