# Architecture

```text
pi-ant -> pi-orchestration -> @phimacs/pimux
Tau -> @phimacs/pimux + pi-sound + exact Pi host
pi-deck -> pinned Pilish + Ghostel + Transient
Pilish --Unix socket--+-- detached pimux -- exact release Pi
Tau    --Unix socket--+
```

Protocol 2 has no primary/creator role. Each RPC agent has one detached owner,
equal bounded socket clients and atomic managed claims. One unconfirmed Close
stops the exact agent and removes its active views across frontends. Frontend
shutdown, restart and connection loss only disconnect; zero-client roots keep
draining accepted work. No central scheduler, automatic runtime restart or input
replay is installed. Workers remain parent-process/task-owned; their Close awaits
final task cleanup through orchestration. Panels remain host-native; owning process
exit triggers identity-checked native cleanup, not a shared-RPC lifetime.

Pi host peers remain `*`; the candidate targets exact SDK/Pi 1.5.0 and
physical host/typebox identity. `session-tools` belongs to orchestration and the
dependency-free claim/endpoint primitives to pimux. Cross-package runtime imports
use declared exports. Pagent is an excluded independent prototype, not a release
package or a dependency of this graph.

The release resolves every internal package through audited local tarballs. Tau's
independent lock supplies its exact ws; its SDK resolves to the canonical release
host graph, never a duplicate SDK. Original vendor packs remain in retained Tau
source for provenance, not as stale installed runtime dependencies.

Public sound uses explicitly registered backend/capture/output drivers and is off
until configured. No private providers, native tokens or ambient personal-device
selection occur. Browser/sound/orchestration activation is separately opt-in.

Claims cover cooperating managed paths, not arbitrary raw Pi/editor writes. Pi
1.5 lacks owning APIs for universal storage safety and safe native writer transfer;
unsafe transfers refuse instead of opening a second writer. See lifecycle and
execution gates for the supported boundary.
