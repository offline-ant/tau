# Pi host dependency security review

## Decision

The candidate selects the published **Pi 1.5.0**, with **undici 8.12.3** and
**minimatch 11.0.3** in its scripts-disabled hydrated graph. Use the owning release,
not external overrides on the old host. Root and Tau locks contain the reviewed
versions; no broad minimatch major-version override is introduced.

**Bundled-host security acceptance remains open.** The actual published CLI/RPC
still embeds these libraries. Inspection finds the bounded SSE parser and cached
matcher in its shared chunk, but metadata, recognizable fixes and a clean npm
audit do not establish all behavioral gates below. Do not rewrite bundles or
quietly substitute the unbundled entry point. No global/live host was changed.

## Inspected selection and actual reachability

| Component | Exact candidate version |
|---|---|
| Pi coding-agent | 1.5.0 |
| undici external dependency | 8.12.3 |
| minimatch external dependency | 11.0.3 |
| nonrecursive-glob-match | 1.0.3 |
| brace-expansion | 5.0.12 |

Both transport/matcher targets support Node 24. The compatibility review covers
undici releases from 8.10.2 through 8.12.3, and minimatch 10.2.6 through 11.0.3.

### Unbundled HTTP consumer

`@earendil-works/pi-coding-agent/dist/core/http-dispatcher.js` imports `* as
undici`. Its complete implementation uses:

- `Client(origin, options)` and `Pool(origin, { ...options, factory })`;
- `EnvHttpProxyAgent`, with `allowH2:false`, `proxyTunnel:true`, configurable
  `bodyTimeout`/`headersTimeout`, custom client/origin factories and
  `connect.autoSelectFamilyAttemptTimeout:2000`;
- `setGlobalDispatcher` and optional `install()` to keep global fetch and its
  dispatcher on one implementation;
- EventEmitter `error` listeners, while preserving a deliberately replaced global
  fetch rather than overwriting it on repeated configuration.

CLI setup configures this dispatcher before provider requests. Management,
provider and extension requests using the installed global fetch therefore share
this transport boundary. Pi does not directly configure a shared-cache/redirect
interceptor, custom certificate callback, EventSource or undici WebSocket in this
module. That reduces direct reachability of some advisories; it does not justify
redistributing the affected library or asserting arbitrary extensions cannot use
those APIs. No Phimacs package directly imports undici/minimatch at this boundary.

### Unbundled glob consumers

Only named `minimatch(path, pattern, options?)` is imported by the inspected Pi
consumers. No use of removed regex/AST APIs was found there.

- `dist/core/model-resolver.js`: model scoping tests both `provider/id` and bare id
  with `{ nocase:true }`, after exact-id handling and thinking-suffix parsing.
- `dist/core/package-manager.js`: `matchesAnyPattern` tests normalized relative
  path, basename and absolute POSIX path; `SKILL.md` also matches its parent
  directory. Calls use default matcher options. Pi interprets include, `!`
  exclude, exact `+` include and exact `-` exclude itself; the force rules do not
  call minimatch. These functions drive manifest/user filters and autoload policy.
- Package glob expansion additionally uses Node's `fs.globSync`; overriding npm
  minimatch does **not** update or alter that distinct Node implementation.

The complete package-manager implementation was read, not merely its imports.
The consumers do not depend on minimatch's internal `set` representation,
`makeRe`, `AST`, `regexp`, `matchOne`, `slashSplit` or other removed APIs.

### Embedded runtime copies: independent acceptance boundary

The selected package's `bin.pi` points to `dist/bundle/cli.js`; its RPC entry is
`dist/bundle/rpc-entry.js`. Their shared `chunk-44DLKSKE.js` contains embedded
undici modules, the bounded SSE parser and the cached minimatch implementation.
A TypeScript-AST scan of every bundled JS module found no static external undici
or minimatch import. External lock resolution cannot establish their versions or
remediate their bytes independently.

Test both the unbundled SDK consumers and actual bundled entry points. Retain the
published package integrity and complete host-file inventory in the release
receipt. Recognizable patched implementations are useful inspection evidence,
not a substitute for the runtime/security matrix below.

## Release-note review and compatibility assessment

### undici 8.12.2

The [complete 8.12.2 release notes](https://github.com/nodejs/undici/releases/tag/v8.12.2)
and [security-patch comparison](https://github.com/nodejs/undici/compare/v8.12.1...v8.12.2)
were read. They address eight issues:

1. TLS 1.2 certificate-changing renegotiation process crash
   ([GHSA-qrxm-fqhp-jwvm](https://github.com/advisories/GHSA-qrxm-fqhp-jwvm)).
2. `Agent` dropping function-valued TLS options during JSON cloning
   ([GHSA-2m5v-pch6-74hx](https://github.com/advisories/GHSA-2m5v-pch6-74hx)).
3. Cross-origin redirect/shared-cache confusion
   ([GHSA-4w7w-5xrc-9h26](https://github.com/advisories/GHSA-4w7w-5xrc-9h26)).
4. Excessive content-encoding chains causing unhandled internal stream errors
   ([GHSA-xjj6-f33q-929c](https://github.com/advisories/GHSA-xjj6-f33q-929c)).
5. Decompression callback exceptions escaping per-request error handling
   ([GHSA-55wc-3pg8-jfw6](https://github.com/advisories/GHSA-55wc-3pg8-jfw6)).
6. Mixed-case SRI algorithm bypass
   ([GHSA-f72v-6w45-q472](https://github.com/advisories/GHSA-f72v-6w45-q472)).
7. Unbounded retained SSE parser state
   ([GHSA-4qv8-2p9j-2685](https://github.com/advisories/GHSA-4qv8-2p9j-2685)).
8. Unbounded WebSocket automatic PONG buffering
   ([GHSA-9fm3-97px-rjf6](https://github.com/advisories/GHSA-9fm3-97px-rjf6)).

Public dispatcher construction/methods used by Pi remain present. The patch
preserves top-level `tls` options separately from JSON-cloned options. Its public
type/documentation change clarifies that EventSource `maxEventSize` now limits
retained metadata, unfinished lines, data-field count and buffered chunk count;
`0` explicitly disables these limits. Workloads relying on previously unbounded
SSE events can now fail, intentionally. Do not disable the limits as a workaround.

The complete intervening release notes were also read:
[8.11.0](https://github.com/nodejs/undici/releases/tag/v8.11.0),
[8.11.1](https://github.com/nodejs/undici/releases/tag/v8.11.1),
[8.11.2](https://github.com/nodejs/undici/releases/tag/v8.11.2),
[8.12.0](https://github.com/nodejs/undici/releases/tag/v8.12.0) and
[8.12.1](https://github.com/nodejs/undici/releases/tag/v8.12.1).
Relevant behavioral changes include NO_PROXY wildcard matching, proxy Host-header
handling, repeated content-encoding/header handling, native-fetch compression
bridging, redirect large-body completion, retry/abort/connection-close settlement,
204/304 connection handling and stricter unsupported FormData body validation.
HTTP/2 fixes mostly lie outside Pi's explicit `allowH2:false` configuration, but
independent SDK/extension callers still require normal regression coverage.
The experimental HTTP parser is not a requested configuration change.

### undici 8.12.3

The [complete 8.12.3 notes](https://github.com/nodejs/undici/releases/tag/v8.12.3)
add HTTP/2 timeout connection replacement and queued Pool async-context
preservation, plus development/documentation changes. Pi sets `allowH2:false`;
the Pool change still merits request-lifecycle coverage. This target includes
the 8.12.2 security fixes; no HTTP/2 configuration change is introduced here.

### minimatch 11.0.3

No GitHub release body is published for this tag. The authoritative
[complete v11.0.3 changelog](https://github.com/isaacs/minimatch/blob/v11.0.3/changelog.md)
and [v10.2.6-to-v11.0.3 comparison](https://github.com/isaacs/minimatch/compare/v10.2.6...v11.0.3)
were reviewed. Version 11 is a real major change, not a blind security patch:

- Path segments use `@isaacs/nonrecursive-glob-match` rather than RegExp.
- Regex/AST APIs and several previously exposed internal methods/options are
  removed; `Minimatch.set` contains matcher objects instead of regexes.
- Empty final path portions no longer match empty-producing extglobs; e.g.
  `a/b/` does not match `a/b/?(x)` or `a/b/*(x)`.
- Multiple-globstar and partial matching bugs are fixed; Windows root/UNC handling
  changes (outside initial Linux support) and Unicode normalization becomes an
  explicit option.
- v11.0.1 bounds globparts amplification and quadratic preprocessing
  ([GHSA-g3hv-75wg-m249](https://github.com/advisories/GHSA-g3hv-75wg-m249)).
  v11.0.2 updates the matcher to correct POSIX `[:print:]`
  ([upstream #309](https://github.com/isaacs/minimatch/pull/309)).
  v11.0.3 adds bounded matcher caching/performance corrections.

Choose **11.0.3**, rather than stopping at the first non-advised 11.0.1. Its named
boolean matcher and `nocase` option match Pi's inspected surface; changes to actual
pattern results still need the matrix below. Lock and retain notices for the new
`@isaacs/nonrecursive-glob-match` dependency (required range `^1.0.3`) and
`brace-expansion` (`^5.0.12`). Both minimatch and the new matcher use BlueOak-1.0.0;
preserve those grants rather than relabel them as Phimacs MIT code.

## Selected host policy

Exact Pi 1.5.0 package pins and their lock own the dependency selection; no
external security overrides are needed. The release pack derives its Pi
requirements and receipt version from `release-manifest.json`. Its existing
inventory/hash safeguards apply to every shipped host chunk.

Registry integrity evidence for the selected external bytes:

- undici 8.12.3:
  `sha512-+fdndUTwBP86cVjihTp21hZHo7d6oj1c/47XPA3lL8mM0XHs+C4EkcjmgRsFnFk2f/UONGDy9ItBItmXsLOQHw==`
- minimatch 11.0.3:
  `sha512-iny/40PEGkNJQ5/Pv6z3nm6FbRAby32GeZRjCUJk2WnNDbgPSTcdI+DDvLqsgBdD4cD5sMtMheqPPnehCCa8Nw==`

Preserve upstream licenses, including BlueOak-1.0.0 matcher grants. Final
committed Tau source/archive selection and immutable-release acceptance remain
pending; source validation does not supply that provenance.

## Required acceptance tests

Run in disposable child processes with cleared proxy/auth variables, synthetic
HOME/agent directories and a private network namespace with loopback only. Use
local HTTP/TLS/CONNECT fixtures and faux models; no real provider/login requests.
Test the **unbundled SDK and actual shipped bundled CLI/RPC independently**.

1. **Resolution/artifact contract:** assert exact external versions from Pi's
   resolution context, no nested old copies, lock integrity and retained licenses.
   For bundled hosts, require rebuilt-source/bundle dependency evidence; a zero
   npm-audit result cannot stand in for this check.
2. **Pi dispatcher:** exercise Client and Pool factory paths, configure/reconfigure
   timeout settings (including disabled), retain a caller-replaced fetch, and prove
   normal installed global fetch decodes a local gzip JSON/chunked response.
   Cancel mid-stream and close a fixture connection abruptly: requests must settle
   without an uncaught dispatcher error or a process left running.
3. **Proxy policy:** local CONNECT proxy records that explicit HTTP_PROXY and
   HTTPS_PROXY routes still tunnel with Pi's `proxyTunnel:true`; test NO_PROXY exact
   host, suffix/wildcard and port matches/nonmatches, including `*`. Assert the
   intended target/Host header and no accidentally direct or external request.
   Changed wildcard results need explicit expected assertions, not snapshot waiver.
4. **Request lifecycle:** delayed headers and stalled body hit their configured
   idle timeouts; periodically arriving body chunks do not turn idle timeout into
   an absolute deadline. Abort and redirect-with-large-body requests settle exactly
   once. Verify local 204/304 responses do not poison the next pooled request.
5. **Security regressions:** use local fixtures for an excessive content-encoding
   chain, a custom TLS certificate-check callback that deliberately rejects, and
   wrong-host TLS certificate/renegotiation failures. Expected outcomes are bounded
   per-request errors, never process crashes or disabled certificate checks.
   Reuse upstream tests for SSE retained-state limits, PONG backpressure, mixed-case
   SRI, redirect-cache origin isolation and decompression callback throws if those
   APIs enter the selected artifact; adapting a test is not proof before execution.
6. **Model matching:** call `resolveModelScopeFromModels` with fake models only.
   Cover provider-qualified and bare patterns, nocase, `*`, `?`, character classes,
   braces, literal bracketed IDs, thinking suffixes, ambiguity and no-match warnings.
   Assert chosen IDs/order/diagnostics, not just that minimatch imports successfully.
7. **Package filters:** resolve a synthetic local package/manifest through
   `DefaultPackageManager` with only local resources and PI_OFFLINE. Cover nested
   extensions, basename/relative/absolute patterns, `SKILL.md` parent matches,
   include/exclude and exact `+`/`-` precedence, disabled autoload and dot paths.
   Assert which resources are enabled so a major matcher change cannot silently
   activate an excluded extension. Node `globSync` and npm minimatch are separate
   test cases.
8. **Matcher boundary:** assert intentional empty-segment extglob behavior and
   POSIX printable character classes. Run the upstream preprocessing-amplification
   reproducer in a memory/time-bounded child, not the main test runner; test the
   nonrecursive matcher on deep/repeated patterns without freezing the suite.
9. Run root typechecks, focused relevant existing tests and final dependency audit
   after the exact changes. An unrelated upstream/embedded limitation is an explicit
   blocked gate, not an excuse to suppress warnings or claim a fixed host.

## Validation status

Scripts-disabled root and Tau hydration report zero npm vulnerabilities.
Phimacs compiles/type-checks against 1.5.0; focused faux SDK/UI/orchestration,
isolated native terminal and managed-runtime tests exercise the selected host.
These checks do not cover the full HTTP/proxy/TLS/matcher security matrix above,
which remains required before closing the bundled-host release gate.
