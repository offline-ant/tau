# Private release installation

These are private tested-candidate tools, not approval for public release or live
cutover. Linux x86-64, Node 24+, Emacs 31.1+ with modules/tree-sitter and **glibc
2.34+** are required for the selected native asset. Musl is not supported. No
installer edits `~/.emacs.d`, global Pi, credentials, user services or existing
conversation files. No runtime installation uses npm lifecycle scripts/network.

## Build the complete candidate

After acquiring the exact source archives recorded in `release-manifest.json`:

```sh
npm ci --ignore-scripts
npm run compile
npm run check
node scripts/emacs-provision.mjs --destination /new/assets
node scripts/emacs-provision.mjs --grammars --destination /new/assets \
  --pilish /verified/pinned/pilish-source
node scripts/pack-release.mjs --destination /new/hydrated-release \
  --pilish-source /retained/pilish-source.tar.gz \
  --tau-source /retained/tau-source.tar \
  --emacs-assets /new/assets/emacs --offline
node scripts/archive-release.mjs --release /new/hydrated-release \
  --destination /new/phimacs-linux-x64.tar.gz
```

Provisioning is explicit, fresh and input-locked: 29 Lisp sources, matching Ghostel
module/corresponding source closure and exactly the two essential grammars through
Pilish's public owning API. It never borrows personal caches. Normal startup,
package-only setup and doctor never download/install missing dependencies.

Packaging requires each fork's `candidateReady` selection before copying sources
or hydrating dependencies. Changed host requirements need matching committed fork
archives and hashes; dirty source snapshots qualify only for explicit source tests.
Packaging verifies retained fork hashes, compiles Tau from its retained source
with its reviewed scripts-disabled lock, and repacks all selected inputs together.
Every internal resolution uses the final local tarballs; old Tau vendor tarballs
are excluded from the installed graph. The complete hydrated tree has no symlinks,
nested host SDK copies or source-checkout dependency. Corresponding Pilish/native
source, licenses, both locks and per-file integrity travel with the runtime.
`--offline` requires the reviewed build dependencies already acquired in npm's cache;
the resulting complete artifact needs no dependency resolution at installation.

## Offline immutable installation and selection

```sh
sh /download/install-release.sh /download/phimacs-linux-x64.tar.gz \
  VERIFIED_ARCHIVE_SHA256 /owned/releases/candidate-001
/owned/releases/candidate-001/bin/phimacs doctor --state /owned/phimacs-state
/owned/releases/candidate-001/bin/phimacs setup --state /owned/phimacs-state
/owned/releases/candidate-001/bin/phimacs emacs --state /owned/phimacs-state
```

Acquire the bootstrap script and archive through the approved release receipt;
verify both digests separately. The bootstrap verifies the archive and extracts
only validated regular files/directories into a private temporary directory, then
runs the bundled Node installer. An installed release can install an update with
its own `scripts/install-release.mjs`, without a source checkout. The installer
verifies the entire archive before reserving a new version, refuses an existing
destination, writes no external settings and seals installed files read-only.
An interrupted destination retains `INCOMPLETE` and cannot launch. Optional
`--select /owned/current` atomically changes only an explicit owned symlink;
non-symlink selectors are preserved. No release is deleted or runtime restarted.
Selecting a retained compatible release is the frontend rollback mechanism.

`bin/phimacs` selects `emacs`, `setup`, `doctor`, managed native `pi`, `pimux`,
or `tau`. All managed starts bind the same absolute release Pi and digest.
The default private agent/state path is under the selected Phimacs state directory;
use explicit settings/authentication rather than copying another installation.
Reference setup enables only its documented core extension selection. Browser,
sound and private providers remain off until deliberately configured. Tau requires
explicit nonempty credentials, or explicit authentication disablement for a local
fixture; there are no built-in credentials. It binds loopback by default.

## Existing Emacs users

```sh
/owned/releases/candidate-001/bin/phimacs setup --package-only \
  --state /owned/phimacs-state
```

This read-only command emits the exact load-path/runtime configuration Lisp form.
Review it in your own configuration; it does not enable deck/reference UI,
orchestration or sound and starts no session. The same release includes independent
Lisp archives under `lisp/archives/`, unpacked deck/orchestration/sound and complete
pinned Pilish source. Stock MELPA Pilish is not an interchangeable dependency.

## Acceptance

See [installed symmetric acceptance](release-acceptance-harness.md). Package-only
and reference startup, actual packed dependencies and runtime sharing are separate
lanes; a skipped lane is not evidence. Doctor reports missing/modified inputs
without repairing them, refreshing auth, reclaiming locks or restarting services.

Pagent is an independent throwaway prototype and is excluded from Phimacs
packages, launchers, artifacts and acceptance. Browser/audio integrations remain
explicit options of the supported product.

Public acquisition and live migration remain blocked by the execution gates,
including bundled-host security, Tau licensing and native correspondence review.
