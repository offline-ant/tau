import { stripVTControlCharacters } from "node:util";

// Fixed display fillers selected from historical task openings, not runtime statistics.
const fillers = new Set(["only", "read-only", "separate", "new", "subtask", "independent", "genuinely", "a", "the"]);

/** A short display title, never a worker's operational/recovery identity. */
export function workerTitle(task: string): string {
  const opening = stripVTControlCharacters(task).replace(/\r\n?/g, "\n")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, "")
    .split("\n")
    .map((line) => line.replace(/^\s*(?:#{1,6}\s+|>\s*|[-*+]\s+|\d+[.)]\s+)/, "")
      .replace(/!?\[([^\]]+)\]\([^)]*\)/g, "$1")
      .replace(/`([^`]+)`/g, "$1")
      .replace(/(?<![\p{L}\p{N}_/\\])(\*{1,2})([^*]+)\1(?![\p{L}\p{N}_.])/gu, "$2")
      .replace(/(?<![\p{L}\p{N}_/\\])(_{1,2})([^_]+)\1(?![\p{L}\p{N}_.])/gu, "$2")
      .replace(/(?<![\p{L}\p{N}_/\\])(~{1,2})([^~]+)\1(?![\p{L}\p{N}_.])/gu, "$2")
      .trim())
    .find((line) => /[\p{L}\p{N}]/u.test(line) && !/^(`{3,}|~{3,})/.test(line)) ?? "";
  // Sentence punctuation must be followed by whitespace/end, not a filename suffix.
  const excerpt = opening.split(/[.!?]+(?=\s|$)/, 1)[0].trim();
  const tokens = excerpt.split(/\s+/).map((token) => {
    const [, prefix, word, suffix] = /^([("'\[{]*)(.*?)([)"'\]},;:!?]*)$/.exec(token)!;
    const filename = word.split(/[/\\]/).filter(Boolean).at(-1) ?? word;
    // Slash-separated concepts (do/delegate, request/response) are not paths.
    const filesystemPath = /[/\\]/.test(word) && !/^[a-z][a-z\d+.-]*:\/\//i.test(word)
      && (/^(?:[a-z]:)?[/\\]|^(?:\.{1,2}|~)[/\\]/i.test(word) || /\.[\p{L}\p{N}_,+-]+$/u.test(filename));
    return { text: filesystemPath ? prefix + filename + suffix : token,
      filler: !filesystemPath && fillers.has(word.toLowerCase()) };
  });
  const title = tokens.filter((token) => !token.filler).map((token) => token.text).join(" ")
    || tokens.map((token) => token.text).join(" ") || "Worker";
  const characters = Array.from(title);
  if (characters.length <= 60) return title;
  let shortened = characters.slice(0, 59).join("");
  const boundary = shortened.lastIndexOf(" ");
  if (boundary > 0) shortened = shortened.slice(0, boundary);
  return `${shortened}…`;
}
