import assert from "node:assert/strict";
import test from "node:test";
import { workerTitle } from "./worker-title.ts";

const examples = [
  ["Separate READ-ONLY source-contract investigation for STORAGE HOST observability. Do not edit.", "source-contract investigation for STORAGE HOST observability"],
  ["Review only /tmp/tester-installer/report.md for factual consistency. Then report.", "Review report.md for factual consistency"],
  ["Implement only NEW port/storage/reader.c,h + fixtures/reader_fixture.c", "Implement reader.c,h + reader_fixture.c"],
  ["Independent subtask: genuinely investigate the new sidebar", "investigate sidebar"],
  ["Review not-only and renewal without changing no-op tests", "Review not-only and renewal without changing no-op tests"],
  ["Investigate do/delegate worker naming", "Investigate do/delegate worker naming"],
  ["Review request/response ownership and stop/restart handling", "Review request/response ownership and stop/restart handling"],
  ["Review UI/UX and src/components without changes", "Review UI/UX and src/components without changes"],
  ["\n\n## **Review** _only_ `src/new/only.test.ts`\nDo not edit files.", "Review only.test.ts"],
  ["\u001b[31mReview\u001b[0m\t the\u0000 sidebar\u202e\r\nThen test.", "Review sidebar"],
  ["Review [the sidebar](https://example.test/sidebar) and `new_file.ts`.", "Review sidebar and new_file.ts"],
  ["Review src/__init__.py and __init__.py without _changing_ tests", "Review __init__.py and __init__.py without changing tests"],
  ["Review only C:\\source\\new\\reader.test.ts and ./fixtures/a.json.", "Review reader.test.ts and a.json"],
  ["Review ~/docs/new and /tmp/only; preserve src/a.", "Review new and only; preserve src/a"],
  ["Review (src/new/api.ts), then test.", "Review (api.ts), then test"],
  ["Check report.test.ts! Then investigate errors.", "Check report.test.ts"],
  ["Review https://example.test/new/api.ts without access.", "Review https://example.test/new/api.ts without access"],
  ["```text\nReview the sidebar\n```", "Review sidebar"],
  ["---\n> Review the sidebar\nThen test.", "Review sidebar"],
  ["The only separate independent subtask", "The only separate independent subtask"],
  ["   \n\u001b[31m\u001b[0m\n***", "Worker"],
] as const;

for (const [task, expected] of examples) {
  test(`worker title: ${JSON.stringify(task)}`, () => {
    assert.equal(workerTitle(task), expected);
  });
}

test("worker titles truncate at word boundaries within 60 characters", () => {
  assert.equal(workerTitle("Review controller lifecycle routing and synchronization before release across hosts"),
    "Review controller lifecycle routing and synchronization…");
  assert.equal(workerTitle("x".repeat(60)), "x".repeat(60));
  assert.equal(workerTitle("x".repeat(61)), `${"x".repeat(59)}…`);
  const title = workerTitle("界".repeat(61));
  assert.equal(Array.from(title).length, 60);
  assert.equal(title, `${"界".repeat(59)}…`);
  assert.equal(workerTitle("𠮷".repeat(61)), `${"𠮷".repeat(59)}…`);
});
