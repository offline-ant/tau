import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import { createHash, randomUUID } from "node:crypto";
import { parseArgs } from "@earendil-works/pi-coding-agent";
import { canonicalSessionPath } from "./ownership.ts";

export const SUPPORTED_PI_VERSION = "1.5.0";
export interface HostIdentity { executable: string; version: string; sha256: string }

/** Validate the immutable release's actual Pi entry point, not a PATH/global CLI. */
export function verifyHost(command: string, expected: { version?: string; sha256?: string } = {}): HostIdentity {
  if (!path.isAbsolute(command)) throw new Error("Managed Pi must be an absolute release executable, not a PATH command");
  const executable = fs.realpathSync.native(command);
  if (!fs.statSync(executable).isFile()) throw new Error("Pi executable must be a regular file");
  fs.accessSync(executable, fs.constants.R_OK | fs.constants.X_OK);
  let dir = path.dirname(executable);
  let version: string | undefined;
  for (;;) {
    const manifest = path.join(dir, "package.json");
    if (fs.existsSync(manifest)) {
      const pkg = JSON.parse(fs.readFileSync(manifest, "utf8")) as { name?: string; version?: string };
      if (pkg.name === "@earendil-works/pi-coding-agent") { version = pkg.version; break; }
    }
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  if (version !== (expected.version ?? SUPPORTED_PI_VERSION)) throw new Error(`Unsupported Pi host: expected ${expected.version ?? SUPPORTED_PI_VERSION}, found ${version ?? "unknown"}`);
  const bytes = fs.readFileSync(executable);
  if (bytes.subarray(0, bytes.indexOf(10)).toString("utf8") !== "#!/usr/bin/env node") throw new Error("Managed Pi must be the supported Node entry point");
  const sha256 = createHash("sha256").update(bytes).digest("hex");
  if (expected.sha256 && sha256 !== expected.sha256) throw new Error("Pi executable differs from the release integrity manifest");
  return { executable, version, sha256 };
}

export function servesRpc(args: readonly string[]): boolean {
  const parsed = parseArgs([...args]);
  return parsed.mode === "rpc" && !parsed.help && !parsed.version && parsed.listModels === undefined && !parsed.export;
}

export function intendedSessionFile(args: readonly string[], cwd: string): string | null {
  const value = parseArgs([...args]).session;
  if (!value || !(value.includes("/") || value.includes("\\") || value.endsWith(".jsonl"))) return null;
  return path.resolve(cwd, value.startsWith("~/") ? path.join(os.homedir(), value.slice(2)) : value);
}

/** Use Pi's public parser, never raw flag-index guesses which can mistake option values for flags. */
export function withExactOption(args: readonly string[], option: "session" | "export", value: string): string[] {
  const separator = args.indexOf("--");
  const result = separator < 0 ? [...args, `--${option}`, value]
    : [...args.slice(0, separator), `--${option}`, value, ...args.slice(separator)];
  const before = parseArgs([...args]);
  const after = parseArgs(result);
  const shape = (parsed: ReturnType<typeof parseArgs>): string => JSON.stringify({ ...parsed, [option]: undefined, unknownFlags: [...parsed.unknownFlags] });
  if (after[option] !== value || shape(before) !== shape(after)) throw new Error("Managed arguments require explicit option values before the exact session/export operand");
  return result;
}

/** Selection is read-only and exact. Native selectors must resolve before managed launch. */
export function exactSessionArgs(args: readonly string[], cwd: string, env: NodeJS.ProcessEnv, allowInitialMessages = false): { args: string[]; file: string } {
  const parsed = parseArgs([...args]);
  if (parsed.diagnostics.some((item) => item.type === "error")) throw new Error("Invalid Pi arguments; resolve diagnostics before managed launch");
  if (parsed.noSession || parsed.continue || parsed.resume || parsed.fork) {
    throw new Error("Managed launch requires an exact persistent --session path; resolve continue/resume/fork selectors before launch");
  }
  if (!allowInitialMessages && (parsed.messages.length || parsed.fileArgs.length || parsed.print)) throw new Error("Managed RPC startup accepts no initial messages; submit input explicitly after pimux_live");
  let file = intendedSessionFile(args, cwd);
  if (!file && parsed.session !== undefined) throw new Error("Resolve the session ID to an exact absolute path before managed launch");
  if (!file) {
    const base = parsed.sessionDir ? path.resolve(cwd, parsed.sessionDir)
      : env.PHIMACS_TEST_ROOT ? path.join(env.PHIMACS_TEST_ROOT, "sessions")
        : env.PI_CODING_AGENT_SESSION_DIR || path.join(env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent"), "sessions", "phimacs");
    fs.mkdirSync(base, { recursive: true, mode: 0o700 });
    file = path.join(base, `${Date.now()}-${randomUUID()}.jsonl`);
  }
  const canonical = canonicalSessionPath(file);
  return { args: withExactOption(args, "session", canonical), file: canonical };
}
