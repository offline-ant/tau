import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import test, { type TestContext } from "node:test";
import { fauxAssistantMessage, fauxProvider, fauxToolCall, InMemoryCredentialStore, type ToolResultMessage } from "@earendil-works/pi-ai";
import {
  createAgentSession, createCodemodeExtension, DefaultResourceLoader, initTheme, ModelRuntime, SessionManager, SettingsManager,
  type AgentToolResult, type ExtensionFactory,
} from "@earendil-works/pi-coding-agent";
import { createRemoteToolDefinitions } from "../../orchestration/remote-tools.ts";
import { RemoteSession } from "../../orchestration/remote-session.ts";
import { installSshStub } from "../../orchestration/test/ssh-stub.ts";
import { TOOL_SELECTION_ENTRY } from "pi-orchestration/session-tools";
import execLints from "./exec-lints.ts";
import pythonExtension from "./python.ts";
import toolsExtension from "./tools.ts";

initTheme("dark");

function text(result: { content: ToolResultMessage["content"] }): string {
  return result.content.filter((item) => item.type === "text").map((item) => item.text).join("\n");
}

type CapturedResult = ToolResultMessage & Pick<AgentToolResult, "structuredContent">;

async function fixture(t: TestContext, options: { extensions?: ExtensionFactory[]; saved?: readonly string[]; branch?: readonly string[] } = {}) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "pi-python-test-"));
  const agentDir = path.join(directory, "agent");
  fs.mkdirSync(agentDir);
  const previous = process.env.PI_CODING_AGENT_DIR;
  process.env.PI_CODING_AGENT_DIR = agentDir;
  t.after(() => {
    if (previous === undefined) delete process.env.PI_CODING_AGENT_DIR;
    else process.env.PI_CODING_AGENT_DIR = previous;
    fs.rmSync(directory, { recursive: true, force: true });
  });
  if (options.saved) fs.writeFileSync(path.join(agentDir, "tool-selection.json"), JSON.stringify({ enabledTools: options.saved }));
  const provider = fauxProvider({ provider: "python-test", tokensPerSecond: 1_000_000 });
  const modelRuntime = await ModelRuntime.create({
    credentials: new InMemoryCredentialStore(), modelsPath: null,
    modelsStorePath: path.join(agentDir, "models-store.json"), allowModelNetwork: false,
  });
  const settingsManager = SettingsManager.inMemory({ compaction: { enabled: false }, retry: { enabled: false } });
  const loader = new DefaultResourceLoader({
    cwd: directory, agentDir, settingsManager, noExtensions: true, noSkills: true,
    noContextFiles: true, noPromptTemplates: true, noThemes: true,
    extensionFactories: [(pi) => { pi.registerProvider(provider.provider); },
      pythonExtension, createCodemodeExtension({ models: false }), toolsExtension, ...(options.extensions ?? [])],
  });
  await loader.reload();
  const sessionManager = SessionManager.create(directory, path.join(directory, "sessions"));
  if (options.branch) sessionManager.appendCustomEntry(TOOL_SELECTION_ENTRY, { enabledTools: options.branch });
  const created = await createAgentSession({
    cwd: directory, agentDir, modelRuntime, settingsManager, resourceLoader: loader,
    model: provider.getModel(), thinkingLevel: "off", sessionManager,
  });
  const session = created.session;
  t.after(() => session.dispose());
  assert.deepEqual(created.extensionsResult.errors, []);
  const errors: string[] = [];
  const structured = new Map<string, AgentToolResult["structuredContent"]>();
  session.subscribe((event) => {
    if (event.type === "tool_execution_end") structured.set(event.toolCallId, event.result.structuredContent);
  });
  await session.bindExtensions({ mode: "print", onError: (error) => errors.push(error.error) });
  await modelRuntime.setRuntimeApiKey(provider.provider.id, "fixture-key");
  await modelRuntime.getAvailable();
  t.after(() => assert.deepEqual(errors, []));
  let call = 0;
  async function run(args: Parameters<typeof fauxToolCall>[1], name = "python"): Promise<CapturedResult> {
    const id = `call-${++call}`;
    provider.setResponses([
      fauxAssistantMessage(fauxToolCall(name, args, { id }), { stopReason: "toolUse" }),
      fauxAssistantMessage("done"),
    ]);
    await session.prompt("Run the scripted test tool call.");
    const result = sessionManager.getBranch().flatMap((entry) =>
      entry.type === "message" && entry.message.role === "toolResult" && entry.message.toolCallId === id ? [entry.message] : []).at(-1);
    assert.ok(result);
    // Structured values are available to callers/events, not saved in the model transcript.
    return { ...result, structuredContent: structured.get(id) };
  }
  return { directory, session, run };
}

interface PythonOutput {
  output: string;
  truncated: boolean;
  full_output_path?: string;
  exit_code: number;
  wall_time_seconds: number;
}

function output(result: CapturedResult): PythonOutput {
  assert.ok(result.structuredContent);
  return result.structuredContent as unknown as PythonOutput;
}

test("python is enabled by default in /tools; exact saved and branch selections override it", { timeout: 15_000 }, async (t) => {
  for (const [label, options, expected] of [
    ["default", {}, true],
    ["saved opt-out", { saved: ["bash"] }, false],
    ["saved opt-in", { saved: ["bash", "python"] }, true],
    ["branch opt-out", { saved: ["bash", "python"], branch: ["bash"] }, false],
  ] as const) await t.test(label, async (child) => {
    const f = await fixture(child, options);
    assert.equal(f.session.getActiveToolNames().includes("python"), expected);
  });
});

test("source survives shell metacharacters and heredoc collisions; cwd and globals are per call", { timeout: 15_000 }, async (t) => {
  const f = await fixture(t);
  const payload = "quotes ' \" $HOME $(touch shell-injected) `touch shell-injected` \\ 界面\nPI_PYTHON\nPI_PYTHON_\nend";
  const first = await f.run({ code: `import os\nx = 42\nprint(r"""${payload}""")\nprint(os.getcwd())` });
  assert.equal(first.isError, false);
  assert.equal(output(first).output, `${payload}\n${f.directory}\n`);
  assert.equal(fs.existsSync(path.join(f.directory, "shell-injected")), false);
  const next = await f.run({ code: "print('x' in globals(), 'os' in globals())" });
  assert.equal(output(next).output, "False False\n");
  assert.deepEqual(fs.readdirSync(f.directory).sort(), ["agent", "sessions"]);
});

test("uv uses an existing project environment without syncing dependencies, loading env files or writing bytecode", { timeout: 15_000 }, async (t) => {
  const f = await fixture(t);
  const venv = spawnSync("uv", ["venv", "--offline", "--no-python-downloads", ".venv"], { cwd: f.directory, encoding: "utf8", timeout: 5_000 });
  assert.equal(venv.status, 0, venv.stderr);
  fs.writeFileSync(path.join(f.directory, "pyproject.toml"), '[project]\nname = "python-tool-fixture"\nversion = "0.0.0"\ndependencies = ["pi-python-test-must-not-be-installed==0.0.0"]\n');
  fs.writeFileSync(path.join(f.directory, ".env"), "PI_PYTHON_TEST_ENV_FILE=loaded\n");
  fs.writeFileSync(path.join(f.directory, "fixture_module.py"), "value = 42\n");
  const result = await f.run({ code: "import os, sys, fixture_module\nprint(sys.prefix)\nprint(fixture_module.value)\nprint(os.environ.get('PI_PYTHON_TEST_ENV_FILE', 'not loaded'))" });
  assert.equal(result.isError, false, text(result));
  assert.equal(output(result).output, `${path.join(f.directory, ".venv")}\n42\nnot loaded\n`);
  assert.equal(fs.existsSync(path.join(f.directory, "uv.lock")), false);
  assert.equal(fs.existsSync(path.join(f.directory, "__pycache__")), false);
});

test("a missing project environment stays absent; a missing interpreter fails without downloading Python", { timeout: 15_000 }, async (t) => {
  const f = await fixture(t);
  fs.writeFileSync(path.join(f.directory, "pyproject.toml"), '[project]\nname = "python-tool-fixture"\nversion = "0.0.0"\nrequires-python = ">=3.8"\n');
  const result = await f.run({ code: "print(42)" });
  assert.equal(fs.existsSync(path.join(f.directory, ".venv")), false);
  assert.equal(fs.existsSync(path.join(f.directory, "uv.lock")), false);
  assert.equal(result.isError, false, text(result));
  fs.writeFileSync(path.join(f.directory, ".python-version"), "9.99.99\n");
  const missing = await f.run({ code: "print(42)" });
  assert.equal(missing.isError, true);
  assert.match(text(missing), /9\.99\.99|not found|download|offline/i);
  assert.equal(fs.existsSync(path.join(f.directory, ".venv")), false);
});

test("Python failures retain exit codes and nested shell permission failures remain errors", { timeout: 15_000 }, async (t) => {
  let deny = false;
  const f = await fixture(t, { extensions: [(pi) => {
    pi.on("tool_call", (event) => event.toolName === "bash" && deny ? { block: true, reason: "fixture denied nested shell" } : undefined);
  }] });
  const failed = await f.run({ code: "import sys\nprint('partial')\nsys.exit(7)" });
  assert.equal(failed.isError, true);
  assert.equal(output(failed).exit_code, 7);
  assert.equal(output(failed).output, "partial\n");
  const syntax = await f.run({ code: "if :" });
  assert.equal(syntax.isError, true);
  assert.match(text(syntax), /SyntaxError/);
  deny = true;
  const denied = await f.run({ code: "print(42)" });
  assert.equal(denied.isError, true);
  assert.match(text(denied), /fixture denied nested shell/);
  assert.equal(denied.structuredContent, undefined);
  deny = false;
  f.session.setActiveToolsByName(["python"]);
  const disabled = await f.run({ code: "print(42)" });
  assert.equal(disabled.isError, true);
  assert.match(text(disabled), /bash/);
});

test("the existing file-rewrite reminder runs on nested Python execution before any file changes", { timeout: 15_000 }, async (t) => {
  const f = await fixture(t, { extensions: [execLints] });
  fs.writeFileSync(path.join(f.directory, "file.txt"), "before");
  const code = "from pathlib import Path\np = Path('file.txt')\np.write_text(p.read_text().replace('before', 'after'))";
  const blocked = await f.run({ code });
  assert.equal(blocked.isError, true);
  assert.match(text(blocked), /Use `edit` for existing files/);
  assert.equal(fs.readFileSync(path.join(f.directory, "file.txt"), "utf8"), "before");
  const retried = await f.run({ code });
  assert.equal(retried.isError, false, text(retried));
  assert.equal(fs.readFileSync(path.join(f.directory, "file.txt"), "utf8"), "after");
});

test("codemode receives structured Python success and failure results through both levels of tool calls", { timeout: 15_000 }, async (t) => {
  const f = await fixture(t);
  f.session.setActiveToolsByName([...f.session.getActiveToolNames(), "codemode"]);
  const result = await f.run({ code: `const good = await tools.python({code: "print(6 * 7)"});
const bad = await tools.python({code: "raise ValueError('fixture failure')"});
return {answer: good.output.trim(), success: good.exit_code, failure: bad.exit_code, traceback: bad.output.includes('ValueError')};` }, "codemode");
  assert.equal(result.isError, false, text(result));
  assert.match(text(result), /"answer":"42"/);
  assert.match(text(result), /"success":0/);
  assert.match(text(result), /"failure":1/);
  assert.match(text(result), /"traceback":true/);
});

test("large output retains shell limits, full-output recovery and the structured output bound", { timeout: 15_000 }, async (t) => {
  const f = await fixture(t);
  const result = await f.run({ code: "print('x' * 1100000)" });
  assert.equal(result.isError, false);
  const data = output(result);
  assert.equal(data.truncated, true);
  assert.ok(Buffer.byteLength(data.output) < 1_050_000);
  assert.ok(text(result).length < 53_000);
  assert.ok(data.full_output_path);
  t.after(() => fs.rmSync(data.full_output_path!, { force: true }));
  assert.equal(fs.statSync(data.full_output_path).size, 1_100_001);
  assert.match(text(result), /Full output:/);
});

test("timeouts and cancellation stop a running Python snippet through the shell lifecycle", { timeout: 15_000 }, async (t) => {
  const f = await fixture(t);
  const timed = await f.run({ code: "import threading\nthreading.Event().wait()", timeout: 0.05 });
  assert.equal(timed.isError, true);
  assert.match(text(timed), /timed out/);
  let aborted: Promise<void> | undefined;
  const unsubscribe = f.session.subscribe((event) => {
    if (event.type === "tool_execution_update" && event.toolName === "python" && text(event.partialResult).includes("python-ready") && !aborted) {
      aborted = f.session.abort();
    }
  });
  t.after(unsubscribe);
  const cancelled = await f.run({ code: "import threading\nprint('python-ready', flush=True)\nthreading.Event().wait()", timeout: 5 });
  assert.ok(aborted, "streaming output triggers cancellation, not a fixed delay");
  await aborted;
  assert.equal(cancelled.isError, true);
  assert.match(text(cancelled), /aborted/i);
});

test("Python follows the actual remote shell backend and never falls back locally on connection failure", { timeout: 15_000 }, async (t) => {
  const stub = installSshStub(t);
  let target = `box:${stub.home}`;
  const f = await fixture(t, { extensions: [(pi) => {
    const local = createRemoteToolDefinitions(new RemoteSession(target), stub.root).find((tool) => tool.name === "bash")!;
    pi.registerTool({ ...local, async execute(id, args, signal, update, ctx) {
      const remote = createRemoteToolDefinitions(new RemoteSession(target), stub.root).find((tool) => tool.name === "bash")!;
      return remote.execute(id, args, signal, update, ctx);
    } });
  }] });
  const remote = await f.run({ code: "import os\nprint(os.getcwd())\nfrom pathlib import Path\nPath('remote-marker').touch()" });
  assert.equal(remote.isError, false, text(remote));
  assert.equal(output(remote).output, `${stub.home}\n`);
  assert.ok(fs.existsSync(path.join(stub.home, "remote-marker")));
  assert.equal(fs.existsSync(path.join(f.directory, "remote-marker")), false);
  target = `down:${stub.home}`;
  const down = await f.run({ code: "from pathlib import Path\nPath('local-fallback').touch()" });
  assert.equal(down.isError, true);
  assert.match(text(down), /SSH connection to down failed/);
  assert.equal(fs.existsSync(path.join(f.directory, "local-fallback")), false);
  assert.equal(fs.existsSync(path.join(stub.home, "local-fallback")), false);
});
