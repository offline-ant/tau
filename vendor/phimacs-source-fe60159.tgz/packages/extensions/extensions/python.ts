// Stateless Python snippets executed through the session's existing shell tool.
import { createBashToolDefinition, type ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";

export default function pythonExtension(pi: ExtensionAPI): void {
  pi.registerTool({
    name: "python",
    label: "Python",
    defaultActive: true,
    description: "Run a Python snippet in a fresh process in the current working directory, including on the session's remote host. " +
      "Use print() for results; variables and imports do not persist between calls. Uses uv to select an installed interpreter, " +
      "including the existing project environment, without creating environments, syncing dependencies or downloading Python. " +
      "Requires uv, an installed Python, and the bash tool enabled. " +
      "Has the same filesystem/network permissions as bash; this is not a sandbox. " +
      "Returns combined stdout/stderr, exit status and elapsed time; output limits and cancellation are the same as bash.",
    promptSnippet: "Execute short Python snippets for computation and data analysis",
    promptGuidelines: [
      "Use python for short computations and data analysis, codemode for tool orchestration, and bash for commands and saved scripts.",
      "Use read for inspecting files and edit/write for file changes so their normal feedback and lint results are preserved; python does not replace them.",
      "Use wait for readiness instead of Python sleeps or polling. Install/manage Python dependencies explicitly through uv, not from a snippet.",
    ],
    parameters: Type.Object({
      code: Type.String({ description: "Python source code, not a shell command. Use print() to return values." }),
      timeout: Type.Optional(Type.Number({ exclusiveMinimum: 0, description: "Timeout in seconds (optional, no default timeout)" })),
    }),
    outputSchema: createBashToolDefinition(process.cwd()).outputSchema,
    reachesTools: () => ["bash"],
    async execute(_toolCallId, { code, timeout }, signal, onUpdate, ctx) {
      // A quoted, collision-free heredoc preserves source without shell expansion.
      // Resolve only: `uv run --no-sync` can still create a missing project environment.
      const lines = new Set(code.split("\n"));
      let delimiter = "PI_PYTHON";
      while (lines.has(delimiter)) delimiter += "_";
      const command = `python=$(uv python find --offline --no-python-downloads) || exit $?\nexec "$python" -u -B - <<'${delimiter}'\n${code}\n${delimiter}`;
      const outcome = await ctx.executeTool("bash", { command, ...(timeout === undefined ? {} : { timeout }) }, { signal, onUpdate });
      // Pi accounts for nested tool usage itself.
      return { ...outcome.result, usage: undefined, isError: outcome.isError };
    },
  });
}
