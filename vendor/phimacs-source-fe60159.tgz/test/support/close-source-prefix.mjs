import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../../', import.meta.url));
const digest = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');

/** Source-only integration input. Never an archive, installation or release pin. */
export function stageCloseSources(destination, { pilish, tau, assets }) {
  for (const [name, directory] of Object.entries({ destination, pilish, tau, assets })) {
    if (!directory || !path.isAbsolute(directory)) throw new Error(`Provide absolute ${name}`);
  }
  if (fs.existsSync(destination)) throw new Error('Source test destination already exists');
  for (const file of [path.join(pilish, 'pilish-runtime-task.el'), path.join(tau, 'bin/worker-task-evidence.js'),
    path.join(root, 'packages/orchestration/dist/worker-task-cli.js'), path.join(assets, 'provision.json')]) {
    if (!fs.existsSync(file)) throw new Error(`Compile/acquire explicit candidate input first: ${file}`);
  }
  fs.mkdirSync(destination, { recursive: true, mode: 0o700 });
  const copy = (from, to, options = {}) => fs.cpSync(from, to, { recursive: true, dereference: true, ...options });
  const modules = path.join(destination, 'node_modules');
  copy(path.join(root, 'node_modules'), modules, { filter: source => path.basename(source) !== '.cache' });
  const targetTau = path.join(modules, 'pi-tau-web-server');
  fs.mkdirSync(targetTau);
  for (const entry of ['package.json', 'bin', 'public', 'src/pi-extension']) copy(path.join(tau, entry), path.join(targetTau, entry));
  // Tau's reviewed native dependency stays exact; internal packages come from
  // this candidate's root graph, never Tau's stale development vendor copies.
  copy(path.join(tau, 'node_modules/ws'), path.join(targetTau, 'node_modules/ws'));
  const lisp = path.join(destination, 'forks/pilish');
  fs.mkdirSync(lisp, { recursive: true });
  for (const file of fs.readdirSync(pilish).filter(file => file.endsWith('.el'))) copy(path.join(pilish, file), path.join(lisp, file));
  copy(path.join(pilish, 'scripts/pilish-storage.mjs'), path.join(lisp, 'scripts/pilish-storage.mjs'));
  for (const [source, target] of [['emacs/pi-deck', 'lisp/pi-deck'], ['packages/orchestration/emacs', 'lisp/pi-orchestration']]) {
    copy(path.join(root, source), path.join(destination, target), { filter: source => !source.endsWith('.elc') && !source.endsWith('.eln') });
  }
  copy(assets, path.join(destination, 'assets/emacs'));
  const bins = {
    pi: '../@earendil-works/pi-coding-agent/dist/bundle/cli.js',
    pimux: '../@phimacs/pimux/bin/pimux',
    'phimacs-task-status': '../pi-orchestration/dist/worker-task-cli.js',
  };
  for (const [name, target] of Object.entries(bins)) {
    const file = path.join(modules, '.bin', name);
    fs.rmSync(file, { force: true });
    fs.writeFileSync(file, `#!/bin/sh\nexec node "$(dirname "$0")/${target}" "$@"\n`, { mode: 0o755 });
  }
  const piExecutable = 'node_modules/@earendil-works/pi-coding-agent/dist/bundle/cli.js';
  fs.writeFileSync(path.join(destination, 'package.json'), JSON.stringify({ name: 'phimacs-close-source-regression', private: true, type: 'module' }));
  const manifest = {
    status: 'source-only-close-regression',
    runtime: { pimuxProtocol: 2, detachedTargetImplemented: true },
    pi: { executable: piExecutable, version: '1.5.0', sha256: digest(path.join(destination, piExecutable)) },
    sourceInputs: { phimacs: root, pilish, tau, retainedAssets: assets },
  };
  fs.writeFileSync(path.join(destination, 'release-manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
  return manifest;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const options = {};
  let destination;
  for (let index = 2; index < process.argv.length; index += 2) {
    const name = process.argv[index];
    const value = process.argv[index + 1];
    if (!['--destination', '--pilish', '--tau', '--assets'].includes(name) || !value) throw new Error('Expected --destination DIR --pilish DIR --tau DIR --assets DIR');
    if (name === '--destination') destination = path.resolve(value);
    else options[name.slice(2)] = path.resolve(value);
  }
  console.log(JSON.stringify(stageCloseSources(destination, options), null, 2));
}
