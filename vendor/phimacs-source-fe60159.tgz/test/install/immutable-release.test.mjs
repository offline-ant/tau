import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { inventory } from '../../scripts/release-files.mjs';

const prefix = process.env.PHIMACS_RUNTIME_PREFIX;
const enabled = process.env.PHIMACS_INSTALLED_RELEASE === '1' && prefix;

function unseal(directory) {
  fs.chmodSync(directory, 0o700);
  for (const item of fs.readdirSync(directory, { withFileTypes: true })) if (item.isDirectory()) unseal(path.join(directory, item.name));
}
function environment(home) {
  return { PATH: process.env.PATH, HOME: home, TMPDIR: home, PI_OFFLINE: '1',
    PHIMACS_STATE_DIR: path.join(home, 'state'), PI_CODING_AGENT_DIR: path.join(home, 'agent'), PIMUX_DIR: path.join(home, 'mux') };
}

test('actual offline-installed release is immutable/link-free and launchers/doctor/package-only setup are read-only', { skip: !enabled, timeout: 90_000 }, () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'phimacs-immutable-probe-'));
  try {
    assert.equal(fs.statSync(prefix).mode & 0o222, 0);
    const files = inventory(prefix);
    assert.equal(Object.values(files).some(item => item.link), false);
    for (const relative of Object.keys(files)) assert.equal(fs.statSync(path.join(prefix, relative)).mode & 0o222, 0, relative);
    const env = environment(home);
    const version = spawnSync(path.join(prefix, 'bin/pi'), ['--version'], { env, encoding: 'utf8', timeout: 20_000 });
    assert.equal(version.status, 0, version.stderr);
    assert.equal(version.stdout.trim(), '1.5.0');
    const doctor = spawnSync(path.join(prefix, 'bin/phimacs'), ['doctor', '--json'], { env, encoding: 'utf8', timeout: 30_000 });
    assert.equal(doctor.status, 0, doctor.stdout + doctor.stderr);
    const report = JSON.parse(doctor.stdout);
    assert.equal(report.ok, true);
    assert.ok(report.checks.some(item => item.component === 'host-files' && item.count > 1));
    const setup = spawnSync(path.join(prefix, 'bin/phimacs'), ['setup', '--package-only'], { env, encoding: 'utf8', timeout: 30_000 });
    assert.equal(setup.status, 0, setup.stdout + setup.stderr);
    assert.match(setup.stdout, /pilish-configure-runtime/);
    assert.ok(setup.stdout.includes('node_modules/.bin/phimacs-task-status'));
    assert.ok(report.checks.some(item => item.component === 'close-api'));
    assert.equal(fs.existsSync(env.PI_CODING_AGENT_DIR), false);
    assert.equal(fs.existsSync(env.PHIMACS_STATE_DIR), false);
    assert.equal(fs.existsSync(env.PIMUX_DIR), false);
  } finally { fs.rmSync(home, { recursive: true, force: true }); }
});

test('a modified host chunk refuses before even administrative launch or session allocation', { skip: !enabled, timeout: 90_000 }, () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'phimacs-host-tamper-'));
  try {
    const copy = path.join(home, 'release');
    fs.cpSync(prefix, copy, { recursive: true });
    unseal(copy);
    const manifest = JSON.parse(fs.readFileSync(path.join(copy, 'release-manifest.json'), 'utf8'));
    const chunk = Object.keys(manifest.pi.files).find(relative => relative.startsWith('dist/bundle/chunks/') && relative.endsWith('.js'));
    assert.ok(chunk);
    const file = path.join(copy, manifest.pi.directory, chunk);
    fs.chmodSync(file, 0o644);
    fs.appendFileSync(file, '\n// synthetic tampering\n');
    const env = environment(home);
    const result = spawnSync(path.join(copy, 'bin/pi'), ['--version'], { env, encoding: 'utf8', timeout: 20_000 });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /Modified host runtime file/);
    assert.equal(fs.existsSync(env.PI_CODING_AGENT_DIR), false);
    assert.equal(fs.existsSync(env.PIMUX_DIR), false);
  } finally { unseal(home); fs.rmSync(home, { recursive: true, force: true }); }
});
