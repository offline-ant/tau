import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { releaseLock, assertInternalResolutions } from '../../scripts/release-lock.mjs';
import { stageForks } from '../../scripts/release-forks.mjs';
import { inventory, materializeBins, writeJson } from '../../scripts/release-files.mjs';
import { archiveRelease } from '../../scripts/archive-release.mjs';
import { installRelease, selectRelease } from '../../scripts/install-release.mjs';

function unseal(directory) {
  if (!fs.existsSync(directory)) return;
  fs.chmodSync(directory, 0o700);
  for (const item of fs.readdirSync(directory, { withFileTypes: true })) if (item.isDirectory()) unseal(path.join(directory, item.name));
}

function fixture(directory) {
  fs.mkdirSync(path.join(directory, 'bin'), { recursive: true });
  writeJson(path.join(directory, 'release-manifest.json'), { schemaVersion: 1, version: '0.1.0',
    platform: process.platform, architecture: process.arch, runtime: { pimuxProtocol: 2 }, status: 'private-fixture' });
  fs.writeFileSync(path.join(directory, 'bin/probe'), '#!/usr/bin/env node\nconsole.log("offline fixture");\n', { mode: 0o755 });
  const longPath = path.join(directory, 'long-' + 'x'.repeat(110), 'nested-' + 'y'.repeat(110) + '.json');
  fs.mkdirSync(path.dirname(longPath));
  writeJson(longPath, { pax: true });
  writeJson(path.join(directory, 'integrity.json'), { schemaVersion: 1, files: inventory(directory) });
}

test('release lock preserves nested workspace deps and exact Tau ws without a second SDK', () => {
  const seed = { packages: { '': {}, 'node_modules/ws': { version: '8.22.1' },
    'node_modules/pi-browser': { link: true }, 'packages/browser/node_modules/ws': { version: '8.19.0' },
    'node_modules/@earendil-works/pi-coding-agent': { version: '1.4.0' } } };
  const manifest = { name: 'candidate', version: '0.1.0', dependencies: { '@earendil-works/pi-coding-agent': '1.4.0' } };
  const packageEntries = { 'node_modules/pi-browser': { resolved: 'file:tarballs/browser.tgz', version: '0.1.0' },
    'node_modules/pi-tau-web-server': { resolved: 'file:tarballs/tau.tgz', dependencies: { ws: '8.21.3', '@earendil-works/pi-coding-agent': '1.4.0' } } };
  const lock = releaseLock(seed, { manifest, packageEntries, workspaces: [{ source: 'packages/browser/', installed: 'node_modules/pi-browser/' }],
    tauLock: { packages: { 'node_modules/ws': { version: '8.21.3', integrity: 'sha512-fixture' } } } });
  assert.equal(lock.packages['node_modules/pi-browser/node_modules/ws'].version, '8.19.0');
  assert.equal(lock.packages['node_modules/pi-tau-web-server/node_modules/ws'].version, '8.21.3');
  const artifacts = [{ name: 'pi-browser', file: 'tarballs/browser.tgz' }, { name: 'pi-tau-web-server', file: 'tarballs/tau.tgz' }];
  assertInternalResolutions(lock, artifacts);
  lock.packages['node_modules/pi-browser'].resolved = 'https://registry.invalid/pi-browser';
  assert.throws(() => assertInternalResolutions(lock, artifacts), /fallback/);
});

test('nested host SDK and mismatched fork host locks refuse', () => {
  assert.throws(() => assertInternalResolutions({ packages: { 'node_modules/tau/node_modules/@earendil-works/pi-ai': {} } }, []), /Nested host/);
  assert.throws(() => releaseLock({ packages: {} }, { manifest: { dependencies: {} }, workspaces: [],
    packageEntries: { 'node_modules/pi-tau-web-server': { dependencies: { ws: '8.21.3', '@earendil-works/pi-coding-agent': '1.4.0' } } },
    tauLock: { packages: { 'node_modules/ws': { version: '8.21.3', integrity: 'sha512-fixture' } } } }), /host versions/);
});

test('unready fork selection refuses before copying archives or hydrating dependencies', () => {
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'phimacs-unready-fork-'));
  try {
    const selection = { externalForks: { pilish: { candidateReady: true }, tau: { candidateReady: false } } };
    assert.throws(() => stageForks(temporary, temporary, selection, {}), /ready tau source selection/);
    assert.deepEqual(fs.readdirSync(temporary), []);
  } finally { fs.rmSync(temporary, { recursive: true, force: true }); }
});

test('npm bin materialization preserves relative ESM resolution without links', () => {
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'phimacs-bin-test-'));
  try {
    fs.mkdirSync(path.join(temporary, 'node_modules/.bin'), { recursive: true });
    fs.mkdirSync(path.join(temporary, 'node_modules/tool'));
    fs.writeFileSync(path.join(temporary, 'node_modules/tool/value.mjs'), 'export default 7;\n');
    fs.writeFileSync(path.join(temporary, 'node_modules/tool/cli.mjs'), '#!/usr/bin/env node\nimport value from "./value.mjs"; console.log(value);\n', { mode: 0o755 });
    fs.symlinkSync('../tool/cli.mjs', path.join(temporary, 'node_modules/.bin/tool'));
    materializeBins(path.join(temporary, 'node_modules'));
    const result = spawnSync(path.join(temporary, 'node_modules/.bin/tool'), [], { encoding: 'utf8' });
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stdout.trim(), '7');
    assert.equal(Object.values(inventory(temporary)).some(item => item.link), false);
  } finally { fs.rmSync(temporary, { recursive: true, force: true }); }
});

test('offline archive install verifies before reserving, seals bytes and atomically selects/rolls back', () => {
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'phimacs-install-test-'));
  try {
    const source = path.join(temporary, 'source');
    fixture(source);
    const archive = archiveRelease(source, path.join(temporary, 'candidate.tar.gz'));
    const first = path.join(temporary, 'versions/first');
    assert.throws(() => installRelease({ archive: archive.file, sha256: '0'.repeat(64), destination: first }), /SHA-256/);
    assert.equal(fs.existsSync(first), false);
    const selector = path.join(temporary, 'current');
    installRelease({ archive: archive.file, sha256: archive.sha256, destination: first, select: selector });
    assert.equal(fs.readlinkSync(selector), first);
    assert.equal(fs.statSync(first).mode & 0o222, 0);
    assert.equal(Object.values(inventory(first)).some(item => item.link), false);
    assert.throws(() => installRelease({ archive: archive.file, sha256: archive.sha256, destination: first }), /EEXIST/);
    const result = spawnSync(path.join(first, 'bin/probe'), [], { encoding: 'utf8', env: { PATH: process.env.PATH, HOME: temporary, npm_config_offline: 'true' } });
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stdout.trim(), 'offline fixture');
    const second = path.join(temporary, 'versions/second');
    installRelease({ archive: archive.file, sha256: archive.sha256, destination: second, select: selector });
    assert.equal(fs.readlinkSync(selector), second);
    selectRelease(first, selector);
    assert.equal(fs.readlinkSync(selector), first);
    fs.writeFileSync(path.join(temporary, 'not-a-selector'), 'preserve');
    assert.throws(() => selectRelease(first, path.join(temporary, 'not-a-selector')), /non-symlink/);
  } finally { unseal(temporary); fs.rmSync(temporary, { recursive: true, force: true }); }
});

test('changed hydrated bytes cannot be archived', () => {
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'phimacs-tamper-test-'));
  try {
    fixture(path.join(temporary, 'source'));
    fs.appendFileSync(path.join(temporary, 'source/bin/probe'), '// changed\n');
    assert.throws(() => archiveRelease(path.join(temporary, 'source'), path.join(temporary, 'bad.tar.gz')), /integrity/);
  } finally { fs.rmSync(temporary, { recursive: true, force: true }); }
});
