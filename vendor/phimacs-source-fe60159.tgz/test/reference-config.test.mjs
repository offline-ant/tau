import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { parseOptions, inspectEnvironment, childEnvironment } from '../scripts/emacs-environment.mjs';
import { ensureDaemon } from '../scripts/emacs-launch.mjs';
import { initializeAgent, packageOnlyConfiguration } from '../scripts/emacs-setup.mjs';

const root = path.resolve(import.meta.dirname, '..');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');

async function fixture(action) {
  const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'phimacs-reference-'));
  try {
    const release = path.join(temp, 'release');
    const assets = path.join(temp, 'assets');
    const pilish = path.join(temp, 'pilish');
    const state = path.join(temp, 'state');
    const write = async (file, value, mode = 0o600) => {
      await fs.mkdir(path.dirname(file), { recursive: true });
      await fs.writeFile(file, typeof value === 'string' ? value : JSON.stringify(value), { mode });
    };
    const host = 'node_modules/@earendil-works/pi-coding-agent';
    const cli = '#!/usr/bin/env node\n';
    const manifest = { version: '0.1.0', runtime: { pimuxProtocol: 2, detachedTargetImplemented: true },
      pi: { version: '1.4.0', executable: `${host}/dist/cli.js`, sha256: sha(cli) },
      externalForks: { pilish: { revision: 'a'.repeat(40), sourceSha256: 'b'.repeat(64) } } };
    await write(path.join(release, 'release-manifest.json'), manifest);
    await write(path.join(release, host, 'package.json'), { version: '1.4.0' });
    await write(path.join(release, host, 'dist/cli.js'), cli, 0o700);
    await write(path.join(release, 'node_modules/@phimacs/pimux/bin/pimux'), cli, 0o700);
    await write(path.join(release, 'node_modules/.bin/phimacs-task-status'), cli, 0o700);
    await write(path.join(assets, 'inputs.json'), '{}');
    await write(path.join(assets, 'ghostel/module.so'), 'synthetic-native');
    await write(path.join(assets, 'provision.json'), { schemaVersion: 1, inputsSha256: sha('{}'), packages: [],
      native: { status: 'verified', path: 'ghostel/module.so', sha256: sha('synthetic-native') },
      grammars: { status: 'verified', artifacts: [] } });
    await write(path.join(pilish, 'pilish.el'), '(provide (quote pilish))');
    await write(path.join(pilish, '.phimacs-source.json'), { revision: 'a'.repeat(40), sha256: 'b'.repeat(64) });
    const options = parseOptions(['--release', release, '--assets', assets, '--pilish', pilish, '--state', state], {});
    const run = (command, args) => {
      if (command === 'git') return { status: 1, stdout: '' };
      if (command === 'emacs') return { status: 0, stdout: args.at(-1).includes('pilish-integration-capabilities') ? '1 2 1 t t' : '31.1 t t' };
      throw new Error(`Unexpected executable: ${command}`);
    };
    await action({ temp, options, manifest, write, run });
  } finally { await fs.rm(temp, { recursive: true, force: true }); }
}

test('doctor verifies immutable host and API without creating state', () => fixture(async ({ options, run }) => {
  const before = await fs.readdir(path.dirname(options.state));
  const report = await inspectEnvironment(options, { run });
  assert.equal(report.ok, true, JSON.stringify(report.issues));
  assert.deepEqual(await fs.readdir(path.dirname(options.state)), before);
  assert.equal(report.optional.privateAdapters, 'not-loaded');
  assert.deepEqual(report.checks.find(item => item.component === 'close-api'), {
    component: 'close-api', version: 'authoritative Close / task cleanup',
    executable: path.join(options.release, 'node_modules/.bin/phimacs-task-status'),
  });
}));

test('retained source identity is independent of an unrelated ancestor Git checkout', () => fixture(async ({ options, run }) => {
  const report = await inspectEnvironment(options, { run: (command, args) => {
    assert.notEqual(command, 'git', 'retained source must not inherit an enclosing repository identity');
    return run(command, args);
  } });
  assert.equal(report.ok, true, JSON.stringify(report.issues));
}));

test('modified host and old primary protocol are refused', () => fixture(async ({ options, manifest, write, run }) => {
  await write(path.join(options.release, manifest.pi.executable), 'modified', 0o700);
  assert.match((await inspectEnvironment(options, { run })).issues.join('\n'), /hash differs/);
  await write(path.join(options.release, manifest.pi.executable), '#!/usr/bin/env node\n', 0o700);
  manifest.runtime.pimuxProtocol = 1;
  await write(path.join(options.release, 'release-manifest.json'), manifest);
  assert.match((await inspectEnvironment(options, { run })).issues.join('\n'), /protocol-2/);
}));

test('doctor checks non-entrypoint host chunks against the complete release inventory', () => fixture(async ({ options, manifest, write, run }) => {
  const relative = 'dist/chunk.js';
  const bytes = 'export const value = 1;\n';
  manifest.pi.directory = 'node_modules/@earendil-works/pi-coding-agent';
  manifest.pi.files = { [relative]: { sha256: sha(bytes), executable: false } };
  await write(path.join(options.release, manifest.pi.directory, relative), bytes);
  await write(path.join(options.release, 'release-manifest.json'), manifest);
  assert.equal((await inspectEnvironment(options, { run })).ok, true);
  await write(path.join(options.release, manifest.pi.directory, relative), 'changed');
  assert.match((await inspectEnvironment(options, { run })).issues.join('\n'), /Modified Pi host file/);
}));

test('matching executable bytes through an outside-release symlink are refused', () => fixture(async ({ temp, options, manifest, write, run }) => {
  const foreign = path.join(temp, 'outside-cli.js');
  await write(foreign, '#!/usr/bin/env node\n', 0o700);
  const executable = path.join(options.release, manifest.pi.executable);
  await fs.unlink(executable);
  await fs.symlink(foreign, executable);
  assert.match((await inspectEnvironment(options, { run })).issues.join('\n'), /Executable escapes/);
}));

test('missing grammars and wrong Pilish contract fail actionably', () => fixture(async ({ options, write, run }) => {
  await write(path.join(options.assets, 'provision.json'), { schemaVersion: 1, inputsSha256: sha('{}'), packages: [],
    native: { status: 'verified', path: 'ghostel/module.so', sha256: sha('synthetic-native') }, grammars: { status: 'not-provisioned' } });
  const report = await inspectEnvironment(options, { run: (command, args) => args.at(-1)?.includes('pilish-integration-capabilities')
    ? { status: 1, stdout: '' } : run(command, args) });
  assert.match(report.issues.join('\n'), /explicit emacs-provision/);
  assert.match(report.issues.join('\n'), /public integration API/);
}));

test('doctor refuses a runtime-capable fork with incomplete deck restoration', () => fixture(async ({ options, run }) => {
  const report = await inspectEnvironment(options, { run: (command, args) => args.at(-1)?.includes('pilish-integration-capabilities')
    ? { status: 0, stdout: '1 2 1 nil t' } : run(command, args) });
  assert.equal(report.ok, false);
  assert.match(report.issues.join('\n'), /Pi-deck lacks verified detached desktop restoration/);
}));

test('doctor requires the exact release task-status executable and owning Close API', () => fixture(async ({ temp, options, write, run }) => {
  const executable = path.join(options.release, 'node_modules/.bin/phimacs-task-status');
  let configured = false;
  const configuredRun = (command, args) => {
    if (args.at(-1)?.includes('pilish-integration-capabilities')) {
      assert.ok(args.at(-1).includes(`:task-status-executable ${JSON.stringify(executable)}`));
      configured = true;
    }
    return run(command, args);
  };
  assert.equal((await inspectEnvironment(options, { run: configuredRun })).ok, true);
  assert.equal(configured, true);
  const oldApi = await inspectEnvironment(options, { run: (command, args) => args.at(-1)?.includes('pilish-integration-capabilities')
    ? { status: 0, stdout: '1 2 1 t nil' } : run(command, args) });
  assert.match(oldApi.issues.join('\n'), /Pilish lacks authoritative Close/);
  await fs.unlink(executable);
  assert.match((await inspectEnvironment(options, { run })).issues.join('\n'), /phimacs-task-status/);
  const foreign = path.join(temp, 'foreign-task-status');
  await write(foreign, '#!/usr/bin/env node\n', 0o700);
  await fs.symlink(foreign, executable);
  assert.match((await inspectEnvironment(options, { run })).issues.join('\n'), /Executable escapes/);
}));

test('launcher environment removes inherited worker/frontend identity', () => fixture(async ({ options }) => {
  const env = childEnvironment(options, { HOME: '/synthetic', PI_ORCHESTRATION_TARGET: 'foreign',
    PIMUX_DISCOVERY: 'foreign', HERDR_SOCKET_PATH: 'foreign', DISPLAY: ':bad', WAYLAND_DISPLAY: 'bad',
    PHIMACS_PARENT_TASK: 'foreign', PHIMACS_PARENT_TASK_FILE: '/foreign-parent-task',
    PHIMACS_PARENT_TASK_TOKEN: 'foreign', PHIMACS_MANAGED_CLAIM: 'foreign',
    PI_CODING_AGENT_DIR: '/explicit-agent', PHIMACS_USER_FILE: '/explicit-user.el' });
  for (const name of ['PHIMACS_PARENT_TASK', 'PHIMACS_PARENT_TASK_FILE', 'PHIMACS_PARENT_TASK_TOKEN', 'PHIMACS_MANAGED_CLAIM']) {
    assert.equal(env[name], undefined, `${name} must not grant authority to an independent frontend`);
  }
  assert.equal(env.PI_ORCHESTRATION_TARGET, undefined);
  assert.equal(env.PIMUX_DISCOVERY, undefined);
  assert.equal(env.DISPLAY, undefined);
  assert.equal(env.PI_CODING_AGENT_DIR, options.agent);
  assert.notEqual(env.PI_CODING_AGENT_DIR, '/explicit-agent');
  assert.equal(env.PHIMACS_USER_FILE, '/explicit-user.el');
  assert.equal(env.PHIMACS_RELEASE_DIR, options.release);
}));

test('failed supervised replacement never launches an unmanaged daemon', () => fixture(async ({ options }) => {
  options.mode = 'supervised';
  options.supervisor = '/synthetic/supervisor';
  let spawns = 0;
  await assert.rejects(ensureDaemon(options, { inspect: async () => ({ ok: true }),
    run: command => command === options.client ? { status: 1 } : { status: 42 },
    spawnProcess: () => { spawns++; throw new Error('must not spawn'); } }), /supervisor start command failed/);
  assert.equal(spawns, 0);
  assert.deepEqual(await fs.readdir(options.state), ['emacs-start.lock', 'sockets']);
}));

test('unresponsive existing daemon never triggers a replacement', () => fixture(async ({ options }) => {
  await assert.rejects(ensureDaemon(options, { inspect: async () => ({ ok: true }),
    run: () => ({ error: { code: 'ETIMEDOUT' } }),
    spawnProcess: () => { throw new Error('must not spawn'); } }), /unresponsive/);
}));

test('successful supervised start delegates exactly once', () => fixture(async ({ options }) => {
  options.mode = 'supervised';
  options.supervisor = '/synthetic/supervisor';
  let started = false;
  let delegated = 0;
  const result = await ensureDaemon(options, { inspect: async () => ({ ok: true }),
    run: command => {
      if (command === options.client) return { status: started ? 0 : 1 };
      assert.equal(command, options.supervisor);
      started = true; delegated++; return { status: 0 };
    }, spawnProcess: () => { throw new Error('must not spawn'); } });
  assert.equal(result.outcome, 'supervisor-started');
  assert.equal(delegated, 1);
}));

test('manual daemon launch commits an owned detached child and does not stop it', () => fixture(async ({ options }) => {
  let started = false;
  let child;
  try {
    const result = await ensureDaemon(options, { inspect: async () => ({ ok: true }),
      run: () => ({ status: started ? 0 : 1 }),
      spawnProcess: () => {
        child = spawn(process.execPath, ['-e', 'setInterval(() => {}, 1000)'], { detached: true, stdio: 'ignore' });
        child.once('spawn', () => { started = true; });
        return child;
      } });
    assert.equal(result.outcome, 'started');
    assert.equal(child.exitCode, null);
  } finally {
    if (child?.pid && child.exitCode === null) {
      child.ref();
      const exited = new Promise(resolve => child.once('exit', resolve));
      process.kill(-child.pid, 'SIGTERM');
      await exited;
    }
  }
}));

test('missing manual executable fails without leaving a startup lock', () => fixture(async ({ options }) => {
  options.emacs = '/nonexistent-phimacs-emacs';
  await assert.rejects(ensureDaemon(options, { inspect: async () => ({ ok: true }), run: () => ({ status: 1 }) }), /Cannot launch Emacs/);
  assert.equal((await fs.readdir(options.state)).includes('emacs-start.lock'), false);
}));

test('explicit setup selects only intended packages and never replaces user settings', () => fixture(async ({ options }) => {
  await initializeAgent(options, { inspect: async () => ({ ok: true }) });
  const file = path.join(options.agent, 'settings.json');
  const settings = JSON.parse(await fs.readFile(file));
  assert.equal(settings.packages.length, 2);
  assert.deepEqual(settings.packages[1].extensions, ['+dist/extensions/tools.js', '+dist/extensions/error-prompt.js']);
  assert.equal((await fs.stat(file)).mode & 0o777, 0o600);
  await fs.writeFile(file, '{"custom":"preserve"}');
  await assert.rejects(initializeAgent(options, { inspect: async () => ({ ok: true }) }), /never overwrites/);
  assert.equal(await fs.readFile(file, 'utf8'), '{"custom":"preserve"}');
}));

test('package-only setup emits explicit paths without settings, modes or sessions', () => fixture(async ({ options, run }) => {
  const result = await packageOnlyConfiguration(options, { inspect: selected => inspectEnvironment(selected, { run }) });
  assert.equal(result.mode, 'package-only');
  assert.match(result.lisp, /pilish-configure-runtime/);
  assert.ok(result.lisp.includes(options.pi));
  assert.ok(result.lisp.includes(options.piSha256));
  assert.ok(result.lisp.includes(`:task-status-executable ${JSON.stringify(options.taskStatus)}`));
  assert.match(result.lisp, /:authoritative-close/);
  assert.doesNotMatch(result.lisp, /\(pi-deck-mode|pilish-start-session|pi-orchestration|pi-sound/);
  await assert.rejects(fs.stat(options.agent), { code: 'ENOENT' });
}));

test('package-only form configures the owning task reader without activating a frontend', () => fixture(async ({ options, run, write }) => {
  const result = await packageOnlyConfiguration(options, { inspect: selected => inspectEnvironment(selected, { run }) });
  await write(path.join(options.pilish, 'pilish.el'), `(require 'cl-lib)
(defun pilish-integration-capabilities () '(:api-version 1 :pimux-protocol 2 :authoritative-close t))
(cl-defun pilish-configure-runtime (&key pi-executable pimux-executable task-status-executable protocol pi-version pi-sha256)
  (unless (and (equal task-status-executable ${JSON.stringify(options.taskStatus)})
               (equal pi-executable ${JSON.stringify(options.pi)})
               (equal pimux-executable ${JSON.stringify(options.pimux)}) (= protocol 2))
    (error "Wrong release runtime configuration"))
  (princ "release-task-reader-configured"))
(provide 'pilish)
`);
  const form = path.join(options.pilish, 'package-only.el');
  await write(form, `(provide 'pi-deck)\n${result.lisp}`);
  const probe = spawnSync('emacs', ['-Q', '--batch', '-l', form], {
    env: { ...process.env, HOME: options.state, EMACSLOADPATH: '' }, encoding: 'utf8', timeout: 10_000,
  });
  assert.equal(probe.status, 0, probe.stdout + probe.stderr);
  assert.equal(probe.stdout, 'release-task-reader-configured');
  await assert.rejects(fs.stat(options.agent), { code: 'ENOENT' });
}));

test('doctor checks locked source bytes even when retained-source metadata agrees', () => fixture(async ({ options, write, run }) => {
  const source = await fs.readFile(path.join(options.pilish, 'pilish.el'));
  const lock = { grammars: { pilishRevision: 'a'.repeat(40), pilishSourceFiles: { 'pilish.el': sha(source) } } };
  const bytes = JSON.stringify(lock);
  await write(path.join(options.assets, 'inputs.json'), bytes);
  const receipt = JSON.parse(await fs.readFile(path.join(options.assets, 'provision.json')));
  receipt.inputsSha256 = sha(bytes);
  await write(path.join(options.assets, 'provision.json'), receipt);
  await write(path.join(options.pilish, 'scripts/pilish-storage.mjs'), '// retained runtime helper');
  assert.equal((await inspectEnvironment(options, { run })).ok, true);
  await write(path.join(options.pilish, 'pilish.el'), 'changed');
  assert.match((await inspectEnvironment(options, { run })).issues.join('\n'), /Pinned Pilish source bytes changed/);
}));

test('Lisp environment validates release paths without loading user configuration', () => fixture(async ({ options }) => {
  const expression = `(progn (load ${JSON.stringify(path.join(root, 'emacs/config/early-init.el'))} nil t) (require (quote phimacs-environment)) (phimacs-load-environment) (princ (if (and phimacs--environment-loaded (not phimacs-enable-sound) (equal phimacs-task-status-executable ${JSON.stringify(path.join(options.release, 'node_modules/.bin/phimacs-task-status'))})) "environment-ready" "bad")))`;
  const result = spawnSync('emacs', ['-Q', '--batch', '--eval', expression], {
    env: { ...process.env, HOME: options.state, PHIMACS_RELEASE_DIR: options.release,
      PHIMACS_EMACS_ASSETS: options.assets, PHIMACS_PILISH_DIR: options.pilish,
      PHIMACS_STATE_DIR: options.state, EMACSLOADPATH: '' }, encoding: 'utf8', timeout: 10_000,
  });
  assert.equal(result.status, 0, result.stdout + result.stderr);
  assert.equal(result.stdout, 'environment-ready');
}));

test('reference environment refuses an escaping task reader without running it', () => fixture(async ({ temp, options, write }) => {
  const executable = path.join(options.release, 'node_modules/.bin/phimacs-task-status');
  const foreign = path.join(temp, 'outside-task-status');
  const marker = path.join(temp, 'must-not-run');
  await write(foreign, `#!/bin/sh\ntouch ${JSON.stringify(marker)}\n`, 0o700);
  await fs.unlink(executable);
  await fs.symlink(foreign, executable);
  const expression = `(progn (load ${JSON.stringify(path.join(root, 'emacs/config/early-init.el'))} nil t) (require 'phimacs-environment) (phimacs-load-environment))`;
  const result = spawnSync('emacs', ['-Q', '--batch', '--eval', expression], {
    env: { ...process.env, HOME: options.state, PHIMACS_RELEASE_DIR: options.release,
      PHIMACS_EMACS_ASSETS: options.assets, PHIMACS_PILISH_DIR: options.pilish,
      PHIMACS_STATE_DIR: options.state, EMACSLOADPATH: '' }, encoding: 'utf8', timeout: 10_000,
  });
  assert.notEqual(result.status, 0);
  assert.match(result.stdout + result.stderr, /Missing or escaping release executable/);
  await assert.rejects(fs.stat(marker), { code: 'ENOENT' });
}));

test('reference source has no startup installation or personal infrastructure', async () => {
  const files = ['init.el', 'early-init.el', 'lisp/phimacs-environment.el', 'lisp/phimacs-ui.el', 'lisp/phimacs-pi.el'];
  for (const file of files) {
    const source = await fs.readFile(path.join(root, 'emacs/config', file), 'utf8');
    assert.doesNotMatch(source, /package-install|package-refresh-contents|git clone|\/home\/(claude|devops)|code\.roelof|wprsd|runit\/|claudeAccessToken/);
  }
  const expression = `(progn (dolist (file (list ${files.map(file => JSON.stringify(path.join(root, 'emacs/config', file))).join(' ')})) (with-temp-buffer (insert-file-contents file) (emacs-lisp-mode) (check-parens))) (princ "syntax-valid"))`;
  const result = spawnSync('emacs', ['-Q', '--batch', '--eval', expression], { encoding: 'utf8', timeout: 10_000 });
  assert.equal(result.status, 0, result.stdout + result.stderr);
  assert.equal(result.stdout, 'syntax-valid');
});

test('reference UI loads fresh locked sources with isolated state', { skip: !process.env.PHIMACS_TEST_ASSETS }, async () => {
  const home = await fs.mkdtemp(path.join(os.tmpdir(), 'phimacs-reference-ert-'));
  try {
    const result = spawnSync('emacs', ['-Q', '--batch', '-l', path.join(root, 'test/reference-ui.el')], {
      env: { ...process.env, HOME: home, PHIMACS_STATE_DIR: path.join(home, 'state'), EMACSLOADPATH: '' },
      encoding: 'utf8', timeout: 60_000,
    });
    assert.equal(result.status, 0, result.stdout + result.stderr);
  } finally { await fs.rm(home, { recursive: true, force: true }); }
});
